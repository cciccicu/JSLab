export default function(global, globalThis, window, $app_exports$, $app_evaluate$) {
    var org_app_require = $app_require$;
    (function(global, globalThis, window, $app_exports$, $app_evaluate$) {
        var setTimeout = global.setTimeout;
        var setInterval = global.setInterval;
        var clearTimeout = global.clearTimeout;
        var clearInterval = global.clearInterval;
        var $app_require$1 = global.$app_require$ || org_app_require;
        var createPageHandler = function() {
            return (()=>{
                var __webpack_modules__ = {
                    "./src/utils/core/routeManager.js": function(__unused_webpack_module, exports) {
                        "use strict";
                        Object.defineProperty(exports, "__esModule", {
                            value: true
                        });
                        exports.back = back;
                        exports["default"] = void 0;
                        exports.push = push;
                        exports.replace = replace;
                        exports.resolveRoute = resolveRoute;
                        var _system = _interopRequireDefault($app_require$1("@app-module/system.router"));
                        function _interopRequireDefault(e) {
                            return e && e.__esModule ? e : {
                                default: e
                            };
                        }
                        const ROUTES = {
                            index: '/',
                            editor: '/workspace/editor',
                            aiGenerate: '/workspace/ai-generate',
                            run: '/workspace/run',
                            newFile: '/workspace/new',
                            settings: '/settings',
                            settingsEditor: '/settings/editor',
                            settingsFonts: '/settings/editor/fonts',
                            settingsHighlight: '/settings/editor/highlight',
                            settingsAbout: '/settings/about',
                            settingsHelp: '/settings/help',
                            settingsCloud: '/settings/cloud',
                            settingsCloudFiles: '/settings/cloud/files',
                            toolsMarket: '/tools/market',
                            toolsMarketUpload: '/tools/market/upload',
                            toolsMarketView: '/tools/market/view',
                            toolsMoney: '/tools/money',
                            overlayConfirm: '/overlay/confirm',
                            overlaySelect: '/overlay/select',
                            overlayNumberInput: '/overlay/number-input',
                            overlayTextInput: '/overlay/text-input'
                        };
                        function normalizePath(route) {
                            const value = route.trim().replace(/\\/g, '/');
                            if (!value || '/' === value) return '/';
                            if (-1 !== value.indexOf('://')) return value;
                            const path = ('/' === value.charAt(0) ? value : '/' + value).replace(/\/+/g, '/').replace(/\/+$/, '') || '/';
                            if ('/' === path) return ROUTES.index;
                            if (path.split('/').some((segment)=>'..' === segment || '.' === segment)) throw new Error('非法页面路径：' + route);
                            if (!/^\/[A-Za-z0-9_-]+(?:\/[A-Za-z0-9_-]+)*$/.test(path)) throw new Error('页面 slug 只能包含字母、数字、下划线和连字符：' + route);
                            return path;
                        }
                        function resolveRoute(route) {
                            if ('string' != typeof route) return ROUTES.index;
                            const key = route.trim();
                            if (Object.prototype.hasOwnProperty.call(ROUTES, key)) return ROUTES[key];
                            return normalizePath(key);
                        }
                        function push(route, params) {
                            const options = {
                                uri: resolveRoute(route)
                            };
                            if (params) options.params = params;
                            _system.default.push(options);
                        }
                        function back() {
                            _system.default.back();
                        }
                        function replace(route, params) {
                            const options = {
                                uri: resolveRoute(route)
                            };
                            if (params) options.params = params;
                            _system.default.replace(options);
                        }
                        var _default = exports["default"] = {
                            resolveRoute,
                            push,
                            replace,
                            back
                        };
                    },
                    "./src/utils/core/time.js": function(__unused_webpack_module, exports) {
                        "use strict";
                        Object.defineProperty(exports, "__esModule", {
                            value: true
                        });
                        exports.formatClock = formatClock;
                        exports.getCurrentClock = getCurrentClock;
                        exports.startPageClock = startPageClock;
                        exports.stopPageClock = stopPageClock;
                        function formatClock(date) {
                            const hours = date.getHours();
                            const minutes = date.getMinutes();
                            const hourText = hours < 10 ? '0' + hours : String(hours);
                            const minuteText = minutes < 10 ? '0' + minutes : String(minutes);
                            return hourText + ':' + minuteText;
                        }
                        function getCurrentClock() {
                            return formatClock(new Date());
                        }
                        const pageClocks = new WeakMap();
                        function stopPageClock(page) {
                            if (!pageClocks.has(page)) return;
                            clearTimeout(pageClocks.get(page));
                            pageClocks.delete(page);
                        }
                        function startPageClock(page) {
                            stopPageClock(page);
                            const tick = ()=>{
                                const date = new Date();
                                const value = formatClock(date);
                                if (page.nowTime !== value) page.nowTime = value;
                                pageClocks.set(page, setTimeout(tick, 60000 - (1000 * date.getSeconds() + date.getMilliseconds())));
                            };
                            tick();
                        }
                    },
                    "./src/utils/core/uiFeedback.js": function(__unused_webpack_module, exports) {
                        "use strict";
                        Object.defineProperty(exports, "__esModule", {
                            value: true
                        });
                        exports.showToast = showToast;
                        exports.vibrate = vibrate;
                        var _system = _interopRequireDefault($app_require$1("@app-module/system.prompt"));
                        var _system2 = _interopRequireDefault($app_require$1("@app-module/system.vibrator"));
                        function _interopRequireDefault(e) {
                            return e && e.__esModule ? e : {
                                default: e
                            };
                        }
                        function vibrate(mode) {
                            if (mode) _system2.default.vibrate({
                                mode
                            });
                        }
                        function showToast(message, duration) {
                            const milliseconds = Number(duration);
                            _system.default.showToast({
                                message: String(null == message ? '' : message),
                                duration: isFinite(milliseconds) ? Math.min(10000, Math.max(1500, milliseconds)) : 1500
                            });
                        }
                    }
                };
                var __webpack_module_cache__ = {};
                function __webpack_require__(moduleId) {
                    var cachedModule = __webpack_module_cache__[moduleId];
                    if (void 0 !== cachedModule) return cachedModule.exports;
                    var module = __webpack_module_cache__[moduleId] = {
                        exports: {}
                    };
                    __webpack_modules__[moduleId](module, module.exports, __webpack_require__);
                    return module.exports;
                }
                (()=>{
                    __webpack_require__.rv = ()=>"1.4.11";
                })();
                (()=>{
                    __webpack_require__.ruid = "bundler=rspack@1.4.11";
                })();
                var __webpack_exports__ = {};
                (()=>{
                    var $app_style$ = [
                        [
                            [
                                [
                                    0,
                                    "page"
                                ]
                            ],
                            {
                                width: "432px",
                                height: "514px",
                                backgroundColor: "#000000",
                                overflow: "hidden",
                                flexDirection: "column"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "topbar-bg"
                                ]
                            ],
                            {
                                position: "absolute",
                                left: "0px",
                                top: "0px",
                                width: "432px",
                                height: "112px"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "btn"
                                ]
                            ],
                            {
                                position: "absolute",
                                top: "30px",
                                width: "72px",
                                height: "72px"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "btn-back"
                                ]
                            ],
                            {
                                left: "30px"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "btn-confirm"
                                ]
                            ],
                            {
                                left: "330px"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "time-text"
                                ]
                            ],
                            {
                                position: "absolute",
                                left: "108px",
                                top: "16px",
                                width: "216px",
                                lineHeight: "32px",
                                color: "#999999",
                                fontSize: "24px",
                                fontWeight: "bold",
                                textAlign: "center"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "title-text"
                                ]
                            ],
                            {
                                position: "absolute",
                                left: "108px",
                                top: "48px",
                                width: "216px",
                                lineHeight: "42px",
                                color: "#ffffff",
                                fontSize: "32px",
                                fontWeight: "bold",
                                textAlign: "center",
                                lines: 1,
                                textOverflow: "ellipsis"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "body"
                                ]
                            ],
                            {
                                position: "absolute",
                                left: "18px",
                                top: "112px",
                                width: "396px",
                                height: "402px",
                                paddingTop: "12px",
                                paddingRight: "16px",
                                paddingBottom: "0px",
                                paddingLeft: "16px",
                                flexDirection: "column"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "footer-spacer"
                                ]
                            ],
                            {
                                width: "100%",
                                height: "102px",
                                flexShrink: 0
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "message"
                                ]
                            ],
                            {
                                width: "364px",
                                fontSize: "28px",
                                lineHeight: "38px",
                                color: "#ffffff",
                                flexShrink: 0
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "note"
                                ]
                            ],
                            {
                                width: "364px",
                                fontSize: "18px",
                                lineHeight: "24px",
                                color: "#999999",
                                fontWeight: "bold",
                                flexShrink: 0,
                                lines: 1,
                                textOverflow: "ellipsis"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "actions"
                                ]
                            ],
                            {
                                position: "absolute",
                                left: "0px",
                                bottom: "30px",
                                width: "432px",
                                paddingTop: "0px",
                                paddingRight: "30px",
                                paddingBottom: "0px",
                                paddingLeft: "30px",
                                flexDirection: "row",
                                justifyContent: "space-between"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "actions-three"
                                ]
                            ],
                            {
                                paddingTop: "0px",
                                paddingRight: "30px",
                                paddingBottom: "0px",
                                paddingLeft: "30px"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "actions-single"
                                ]
                            ],
                            {
                                justifyContent: "center"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "action"
                                ]
                            ],
                            {
                                width: "160px",
                                height: "60px",
                                backgroundColor: "#262626",
                                borderRadius: "30px",
                                justifyContent: "center",
                                alignItems: "center"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "action-compact"
                                ]
                            ],
                            {
                                width: "116px"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "primary"
                                ]
                            ],
                            {
                                backgroundColor: "#0d6eff"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "action-text"
                                ]
                            ],
                            {
                                width: "144px",
                                fontSize: "24px",
                                lineHeight: "32px",
                                color: "#ffffff",
                                fontWeight: "bold",
                                textAlign: "center",
                                lines: 1,
                                textOverflow: "ellipsis"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "action-text-compact"
                                ]
                            ],
                            {
                                width: "100px",
                                fontSize: "20px"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "input-card"
                                ]
                            ],
                            {
                                position: "absolute",
                                left: "18px",
                                top: "112px",
                                width: "396px",
                                height: "123px",
                                paddingTop: "6px",
                                paddingRight: "16px",
                                paddingBottom: "6px",
                                paddingLeft: "16px",
                                flexDirection: "column",
                                backgroundColor: "#262626",
                                borderRadius: "36px",
                                flexShrink: 0
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "input-field"
                                ]
                            ],
                            {
                                width: "364px",
                                height: "40px",
                                paddingTop: "0px",
                                paddingRight: "12px",
                                paddingBottom: "0px",
                                paddingLeft: "12px",
                                borderRadius: "20px",
                                backgroundColor: "#141414",
                                alignItems: "center",
                                flexShrink: 0
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "input-value"
                                ]
                            ],
                            {
                                width: "340px",
                                height: "40px",
                                fontSize: "22px",
                                lineHeight: "36px",
                                color: "#ffffff",
                                lines: 1,
                                textOverflow: "ellipsis",
                                flexShrink: 0
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "number-value"
                                ]
                            ],
                            {
                                width: "364px",
                                fontSize: "36px",
                                fontWeight: "bold",
                                textAlign: "center"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "edit-actions"
                                ]
                            ],
                            {
                                width: "364px",
                                height: "40px",
                                flexDirection: "row",
                                alignItems: "center",
                                justifyContent: "space-between"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "edit-key"
                                ]
                            ],
                            {
                                width: "48px",
                                height: "40px",
                                color: "#ffffff",
                                textAlign: "center",
                                fontSize: "22px",
                                backgroundColor: "#141414",
                                borderRadius: "20px"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "count"
                                ]
                            ],
                            {
                                fontSize: "18px",
                                color: "#999999",
                                width: "130px",
                                textAlign: "center"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "keys"
                                ]
                            ],
                            {
                                position: "absolute",
                                left: "30px",
                                top: "224px",
                                width: "372px",
                                flexDirection: "column"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "key-row"
                                ]
                            ],
                            {
                                width: "372px",
                                height: "46px",
                                marginBottom: "3px",
                                flexDirection: "row",
                                justifyContent: "space-between"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "key"
                                ]
                            ],
                            {
                                width: "120px",
                                height: "46px",
                                fontSize: "32px",
                                lineHeight: "44px",
                                fontWeight: "bold",
                                textAlign: "center",
                                color: "#ffffff",
                                backgroundColor: "#262626",
                                borderRadius: "25px"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "choices"
                                ]
                            ],
                            {
                                position: "absolute",
                                left: "18px",
                                top: "112px",
                                width: "396px",
                                height: "366px",
                                flexDirection: "column"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "choices-note"
                                ]
                            ],
                            {
                                width: "396px",
                                paddingTop: "4px",
                                paddingRight: "16px",
                                paddingBottom: "12px",
                                paddingLeft: "16px",
                                flexDirection: "column",
                                flexShrink: 0
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "choice-message"
                                ]
                            ],
                            {
                                width: "364px",
                                fontSize: "20px",
                                lineHeight: "28px",
                                color: "#999999",
                                textAlign: "center",
                                flexShrink: 0,
                                lines: 4,
                                textOverflow: "ellipsis"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "selected-count"
                                ]
                            ],
                            {
                                width: "364px",
                                fontSize: "18px",
                                lineHeight: "26px",
                                color: "#999999",
                                textAlign: "center",
                                flexShrink: 0
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "item"
                                ]
                            ],
                            {
                                width: "396px",
                                height: "112px",
                                paddingTop: "14px",
                                paddingRight: "20px",
                                paddingBottom: "14px",
                                paddingLeft: "20px",
                                marginBottom: "8px",
                                backgroundColor: "#262626",
                                borderRadius: "36px",
                                flexShrink: 0,
                                flexDirection: "row",
                                alignItems: "center",
                                justifyContent: "space-between"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "item-described"
                                ]
                            ],
                            {
                                height: "168px"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "item-selected"
                                ]
                            ],
                            {
                                backgroundColor: "#0d6eff"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "item-disabled"
                                ]
                            ],
                            {
                                backgroundColor: "#303030"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "item-copy"
                                ]
                            ],
                            {
                                width: "316px",
                                flexDirection: "column"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "label"
                                ]
                            ],
                            {
                                width: "316px",
                                fontSize: "32px",
                                lineHeight: "40px",
                                fontWeight: "bold",
                                color: "#ffffff",
                                lines: 2,
                                textOverflow: "ellipsis"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "description"
                                ]
                            ],
                            {
                                width: "316px",
                                fontSize: "20px",
                                lineHeight: "26px",
                                color: "#ffffff",
                                lines: 2,
                                textOverflow: "ellipsis"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "check-icon"
                                ]
                            ],
                            {
                                width: "40px",
                                height: "40px",
                                flexShrink: 0
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "disabled"
                                ]
                            ],
                            {
                                color: "#8c8c8c"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "error"
                                ]
                            ],
                            {
                                color: "#f48771"
                            }
                        ]
                    ];
                    var $app_script$ = function __scriptModule__(module, exports, $app_require$1) {
                        "use strict";
                        Object.defineProperty(exports, "__esModule", {
                            value: true
                        });
                        exports.default = void 0;
                        var _routeManager = __webpack_require__("./src/utils/core/routeManager.js");
                        var _uiFeedback = __webpack_require__("./src/utils/core/uiFeedback.js");
                        var _time = __webpack_require__("./src/utils/core/time.js");
                        const buffers = new WeakMap();
                        var _default = exports.default = {
                            protected: {
                                dialogId: ''
                            },
                            private: {
                                dialog: {
                                    id: '',
                                    type: '',
                                    title: '',
                                    message: '',
                                    confirmText: '确认',
                                    cancelText: '取消',
                                    secondaryText: ''
                                },
                                nowTime: '00:00',
                                error: '',
                                closing: false,
                                invalid: false,
                                rows: [],
                                selectedCount: 0
                            },
                            onInit () {
                                const data = this.$app.$def.getDialog('select', this.dialogId);
                                if (!data) {
                                    this.invalid = true;
                                    return;
                                }
                                const display = Object.assign({}, data);
                                delete display.value;
                                delete display.items;
                                this.dialog = display;
                                const selected = data.multiple ? data.value.slice() : void 0 === data.value ? [] : [
                                    data.value
                                ];
                                buffers.set(this, {
                                    items: data.items,
                                    selected
                                });
                                this.rows = data.items.map((item, index)=>({
                                        id: item.id,
                                        index,
                                        label: item.label,
                                        description: item.description,
                                        disabled: item.disabled,
                                        selected: selected.indexOf(item.value) >= 0
                                    }));
                                this.selectedCount = selected.length;
                                if (data.items.filter((item)=>!item.disabled).length < data.minSelected) this.error = '没有足够的可用选项';
                                this.nowTime = (0, _time.getCurrentClock)();
                            },
                            onReady () {
                                if (this.invalid) {
                                    this.$app.$def.dialogDestroyed({
                                        id: this.dialogId
                                    });
                                    this.closing = true;
                                    (0, _routeManager.back)();
                                }
                            },
                            onShow () {
                                (0, _time.startPageClock)(this);
                            },
                            onHide () {
                                (0, _time.stopPageClock)(this);
                            },
                            onDestroy () {
                                (0, _time.stopPageClock)(this);
                                this.$app.$def.dialogDestroyed(this.dialog);
                                buffers.delete(this);
                            },
                            close (action, value) {
                                if (this.closing || this.invalid) return;
                                this.closing = true;
                                (0, _uiFeedback.vibrate)('short');
                                this.$app.$def.settleDialog(this.dialog, action, value);
                                (0, _routeManager.back)();
                            },
                            onCancel () {
                                this.close('cancel', null);
                            },
                            onBackPress () {
                                this.onCancel();
                                return true;
                            },
                            onSelect (index) {
                                if (this.closing || this.invalid) return;
                                const item = buffers.get(this).items[index];
                                if (!item || item.disabled) return;
                                const b = buffers.get(this), found = b.selected.indexOf(item.value);
                                (0, _uiFeedback.vibrate)('short');
                                this.error = '';
                                if (this.dialog.multiple) if (found >= 0) {
                                    b.selected.splice(found, 1);
                                    this.rows[index].selected = false;
                                } else {
                                    if (b.selected.length >= this.dialog.maxSelected) {
                                        this.error = '最多选择 ' + this.dialog.maxSelected + ' 项';
                                        return;
                                    }
                                    b.selected.push(item.value);
                                    this.rows[index].selected = true;
                                }
                                else {
                                    if (found >= 0) return;
                                    const previous = b.items.findIndex((item)=>item.value === b.selected[0]);
                                    if (previous >= 0) this.rows[previous].selected = false;
                                    b.selected = [
                                        item.value
                                    ];
                                    this.rows[index].selected = true;
                                }
                                this.selectedCount = b.selected.length;
                            },
                            onConfirm () {
                                if (this.closing || this.invalid) return;
                                const selected = buffers.get(this).selected;
                                if (selected.length < this.dialog.minSelected) {
                                    this.error = '至少选择 ' + this.dialog.minSelected + ' 项';
                                    return;
                                }
                                if (selected.length > this.dialog.maxSelected) {
                                    this.error = '最多选择 ' + this.dialog.maxSelected + ' 项';
                                    return;
                                }
                                this.close('confirm', this.dialog.multiple ? buffers.get(this).items.filter((item)=>selected.indexOf(item.value) >= 0).map((item)=>item.value) : selected[0]);
                            }
                        };
                        const moduleOwn = exports.default || module.exports;
                        const accessors = [
                            'public',
                            'protected',
                            'private'
                        ];
                        if (moduleOwn.data && accessors.some(function(acc) {
                            return moduleOwn[acc];
                        })) throw new Error('页面VM对象中的属性data不可与"' + accessors.join(',') + '"同时存在，请使用private替换data名称');
                        if (!moduleOwn.data) {
                            moduleOwn.data = {};
                            moduleOwn._descriptor = {};
                            accessors.forEach(function(acc) {
                                const accType = typeof moduleOwn[acc];
                                if ('object' === accType) {
                                    moduleOwn.data = Object.assign(moduleOwn.data, moduleOwn[acc]);
                                    for(const name in moduleOwn[acc])moduleOwn._descriptor[name] = {
                                        access: acc
                                    };
                                } else if ('function' === accType) console.warn('页面VM对象中的属性' + acc + '的值不能是函数，请使用对象');
                            });
                        }
                    };
                    var $app_template$ = function(vm) {
                        const _vm_ = vm || this;
                        return aiot.__ce__("div", {
                            __vm__: _vm_,
                            __opts__: {
                                classList: [
                                    "page"
                                ]
                            }
                        }, [
                            aiot.__ce__("list", {
                                __vm__: _vm_,
                                __opts__: {
                                    classList: [
                                        "choices"
                                    ],
                                    bounces: "true"
                                }
                            }, [
                                aiot.__ci__({
                                    __vm__: _vm_,
                                    __opts__: {
                                        shown: function() {
                                            return _vm_.error || _vm_.dialog.message || _vm_.dialog.multiple || 0 === _vm_.rows.length;
                                        }
                                    }
                                }, function() {
                                    return [
                                        aiot.__ce__("list-item", {
                                            __vm__: _vm_,
                                            __opts__: {
                                                type: "note",
                                                classList: [
                                                    "choices-note"
                                                ]
                                            }
                                        }, [
                                            aiot.__ce__("text", {
                                                __vm__: _vm_,
                                                __opts__: {
                                                    show: function() {
                                                        return _vm_.error || _vm_.dialog.message || 0 === _vm_.rows.length;
                                                    },
                                                    classList: function() {
                                                        const $classValue$ = "choice-message " + (_vm_.error ? "error" : "");
                                                        if ('string' == typeof $classValue$) return $classValue$.split(' ').map((item)=>item.trim()).filter(Boolean);
                                                        return $classValue$;
                                                    },
                                                    value: function() {
                                                        return _vm_.error || _vm_.dialog.message || "\u6682\u65E0\u53EF\u9009\u9879";
                                                    }
                                                }
                                            }, []),
                                            aiot.__ce__("text", {
                                                __vm__: _vm_,
                                                __opts__: {
                                                    show: function() {
                                                        return _vm_.dialog.multiple;
                                                    },
                                                    classList: [
                                                        "selected-count"
                                                    ],
                                                    value: function() {
                                                        return "已选 " + _vm_.selectedCount + " 项";
                                                    }
                                                }
                                            }, [])
                                        ])
                                    ];
                                }),
                                aiot.__cf__({
                                    __vm__: _vm_,
                                    __opts__: {
                                        exp: function() {
                                            return {
                                                __list__: _vm_.rows,
                                                __tid__: "id"
                                            };
                                        },
                                        key: "$idx",
                                        value: "item"
                                    }
                                }, function($idx, item) {
                                    return [
                                        aiot.__ce__("list-item", {
                                            __vm__: _vm_,
                                            __opts__: {
                                                type: "choice",
                                                classList: function() {
                                                    const $classValue$ = "item " + (item.description ? "item-described" : "") + " " + (item.selected ? "item-selected" : "") + " " + (item.disabled ? "item-disabled" : "");
                                                    if ('string' == typeof $classValue$) return $classValue$.split(' ').map((item)=>item.trim()).filter(Boolean);
                                                    return $classValue$;
                                                },
                                                events: {
                                                    click: function(evt) {
                                                        return _vm_.onSelect(item.index, evt);
                                                    }
                                                }
                                            }
                                        }, [
                                            aiot.__ce__("div", {
                                                __vm__: _vm_,
                                                __opts__: {
                                                    classList: [
                                                        "item-copy"
                                                    ]
                                                }
                                            }, [
                                                aiot.__ce__("text", {
                                                    __vm__: _vm_,
                                                    __opts__: {
                                                        classList: function() {
                                                            const $classValue$ = "label " + (item.disabled ? "disabled" : "");
                                                            if ('string' == typeof $classValue$) return $classValue$.split(' ').map((item)=>item.trim()).filter(Boolean);
                                                            return $classValue$;
                                                        },
                                                        value: function() {
                                                            return item.label;
                                                        }
                                                    }
                                                }, []),
                                                aiot.__ce__("text", {
                                                    __vm__: _vm_,
                                                    __opts__: {
                                                        show: function() {
                                                            return item.description;
                                                        },
                                                        classList: function() {
                                                            const $classValue$ = "description " + (item.disabled ? "disabled" : "");
                                                            if ('string' == typeof $classValue$) return $classValue$.split(' ').map((item)=>item.trim()).filter(Boolean);
                                                            return $classValue$;
                                                        },
                                                        value: function() {
                                                            return item.description;
                                                        }
                                                    }
                                                }, [])
                                            ]),
                                            aiot.__ce__("image", {
                                                __vm__: _vm_,
                                                __opts__: {
                                                    show: function() {
                                                        return item.selected;
                                                    },
                                                    src: "/common/images/check.png",
                                                    classList: [
                                                        "check-icon"
                                                    ]
                                                }
                                            }, [])
                                        ])
                                    ];
                                })
                            ]),
                            aiot.__ce__("image", {
                                __vm__: _vm_,
                                __opts__: {
                                    src: "/common/images/hd.png",
                                    classList: [
                                        "topbar-bg"
                                    ]
                                }
                            }, []),
                            aiot.__ce__("text", {
                                __vm__: _vm_,
                                __opts__: {
                                    classList: [
                                        "time-text"
                                    ],
                                    value: function() {
                                        return _vm_.nowTime;
                                    }
                                }
                            }, []),
                            aiot.__ci__({
                                __vm__: _vm_,
                                __opts__: {
                                    shown: function() {
                                        return _vm_.dialog.title.length <= 5;
                                    }
                                }
                            }, function() {
                                return [
                                    aiot.__ce__("text", {
                                        __vm__: _vm_,
                                        __opts__: {
                                            classList: [
                                                "title-text"
                                            ],
                                            value: function() {
                                                return _vm_.dialog.title;
                                            }
                                        }
                                    }, [])
                                ];
                            }),
                            aiot.__ci__({
                                __vm__: _vm_,
                                __opts__: {
                                    shown: function() {
                                        return _vm_.dialog.title.length > 5;
                                    }
                                }
                            }, function() {
                                return [
                                    aiot.__ce__("marquee", {
                                        __vm__: _vm_,
                                        __opts__: {
                                            classList: [
                                                "title-text"
                                            ],
                                            scrollamount: "4",
                                            loop: "-1",
                                            value: function() {
                                                return _vm_.dialog.title;
                                            }
                                        }
                                    }, [])
                                ];
                            }),
                            aiot.__ce__("image", {
                                __vm__: _vm_,
                                __opts__: {
                                    src: "/common/images/back.png",
                                    classList: [
                                        "btn",
                                        "btn-back"
                                    ],
                                    events: {
                                        click: function(evt) {
                                            return _vm_.onCancel(evt);
                                        }
                                    }
                                }
                            }, []),
                            aiot.__ce__("image", {
                                __vm__: _vm_,
                                __opts__: {
                                    src: "/common/images/conform.png",
                                    classList: [
                                        "btn",
                                        "btn-confirm"
                                    ],
                                    events: {
                                        click: function(evt) {
                                            return _vm_.onConfirm(evt);
                                        }
                                    }
                                }
                            }, [])
                        ]);
                    };
                    $app_exports$['entry'] = function($app_exports$) {
                        $app_script$({}, $app_exports$, $app_require$1);
                        $app_exports$.default.template = $app_template$;
                        $app_exports$.default.style = $app_style$;
                    };
                })();
            })();
        };
        return createPageHandler();
    })(global, globalThis, window, $app_exports$, $app_evaluate$);
}
