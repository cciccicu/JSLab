export default function(global, globalThis, window, $app_exports$, $app_evaluate$) {
    var org_app_require = $app_require$;
    (function(global, globalThis, window, $app_exports$, $app_evaluate$) {
        var setTimeout = global.setTimeout;
        var setInterval = global.setInterval;
        var clearTimeout = global.clearTimeout;
        var clearInterval = global.clearInterval;
        var $app_require$1 = global.$app_require$ || org_app_require;
        var createAppHandler = function() {
            return (()=>{
                var __webpack_modules__ = {
                    "./src/utils/core/dialogState.js": function(__unused_webpack_module, exports, __webpack_require__) {
                        "use strict";
                        Object.defineProperty(exports, "__esModule", {
                            value: true
                        });
                        exports.cancelOwnedDialog = cancelOwnedDialog;
                        exports.closeOwnedDialog = closeOwnedDialog;
                        exports.deliverDialog = deliverDialog;
                        exports.dialogDestroyed = dialogDestroyed;
                        exports.getDialog = getDialog;
                        exports.openDialog = openDialog;
                        exports.settleDialog = settleDialog;
                        var _routeManager = __webpack_require__("./src/utils/core/routeManager.js");
                        var _runtimeContract = __webpack_require__("./src/utils/runtime/runtimeContract.js");
                        let current = null;
                        let sequence = 0;
                        const routes = {
                            alert: 'overlayConfirm',
                            confirm: 'overlayConfirm',
                            text: 'overlayTextInput',
                            number: 'overlayNumberInput',
                            select: 'overlaySelect'
                        };
                        function failure(code, message) {
                            const error = new Error(message);
                            error.code = code;
                            return error;
                        }
                        function validValue(value) {
                            return 'string' == typeof value || 'boolean' == typeof value || 'number' == typeof value && isFinite(value);
                        }
                        function integer(value, fallback, max) {
                            if (void 0 === value) return fallback;
                            if ('number' != typeof value || !isFinite(value) || value < 0 || value > max || Math.floor(value) !== value) throw failure('DIALOG_INVALID', '数量参数无效');
                            return value;
                        }
                        function normalize(type, source) {
                            if (!routes[type] || null != source && ('object' != typeof source || Array.isArray(source))) throw failure('DIALOG_INVALID', '对话框参数无效');
                            const o = source || {};
                            const data = {
                                id: 'dialog-' + ++sequence,
                                type,
                                title: String(o.title || ({
                                    alert: '提示',
                                    confirm: '确认',
                                    text: '文本输入',
                                    number: '数字输入',
                                    select: '选择'
                                })[type]).slice(0, 80),
                                message: String(o.message || '').slice(0, 4000),
                                confirmText: String(o.confirmText || '确认').slice(0, 16),
                                cancelText: String(o.cancelText || '取消').slice(0, 16),
                                secondaryText: 'confirm' === type ? String(o.secondaryText || '').slice(0, 16) : '',
                                required: true === o.required
                            };
                            if ('text' === type) {
                                data.value = null == o.value ? '' : String(o.value);
                                data.placeholder = String(o.placeholder || '请输入内容').slice(0, 80);
                                data.language = 'cn' === o.language ? 'cn' : 'en';
                                data.maxLength = integer(o.maxLength, 64, _runtimeContract.DIALOG_LIMITS.textCharacters);
                                data.minLength = integer(o.minLength, data.required ? 1 : 0, data.maxLength);
                                if (data.minLength > data.maxLength) throw failure('DIALOG_INVALID', '最小长度超过最大长度');
                                if (data.value.length > data.maxLength) throw failure('DIALOG_INVALID', '初始文本超过最大长度');
                            }
                            if ('number' === type) {
                                [
                                    'min',
                                    'max'
                                ].forEach((key)=>{
                                    if (void 0 !== o[key]) {
                                        if ('number' != typeof o[key] || !isFinite(o[key])) throw failure('DIALOG_INVALID', '数值范围无效');
                                        data[key] = o[key];
                                    }
                                });
                                if (void 0 !== data.min && void 0 !== data.max && data.min > data.max) throw failure('DIALOG_INVALID', '数值范围无效');
                                data.decimals = integer(o.decimals, 6, 10);
                                if (null != o.value && ('number' != typeof o.value || !isFinite(o.value) || Math.abs(o.value) >= 1e15)) throw failure('DIALOG_INVALID', '初始数字无效');
                                data.value = null == o.value ? '' : String(o.value);
                                if (data.value && /e/i.test(data.value)) {
                                    const parts = data.value.toLowerCase().split('e');
                                    const negative = '-' === parts[0].charAt(0);
                                    const mantissa = parts[0].replace('-', '');
                                    const digits = mantissa.replace('.', '');
                                    const point = (mantissa.indexOf('.') < 0 ? mantissa.length : mantissa.indexOf('.')) + Number(parts[1]);
                                    if (point <= -10 || point > 15) throw failure('DIALOG_INVALID', '初始数字超过精度限制');
                                    data.value = (negative ? '-' : '') + (point <= 0 ? '0.' + new Array(1 - point).join('0') + digits : point >= digits.length ? digits + new Array(point - digits.length + 1).join('0') : digits.slice(0, point) + '.' + digits.slice(point));
                                }
                                if ((data.value.split('.')[1] || '').length > data.decimals || null != o.value && (void 0 !== data.min && o.value < data.min || void 0 !== data.max && o.value > data.max)) throw failure('DIALOG_INVALID', '初始数字超出范围或精度');
                            }
                            if ('select' === type) {
                                if (!Array.isArray(o.items) || o.items.length > _runtimeContract.DIALOG_LIMITS.items) throw failure('DIALOG_INVALID', '选项必须是数组，最多 100 项');
                                const values = [];
                                data.items = o.items.map((item, index)=>{
                                    if (!item || 'object' != typeof item || !validValue(item.value) || values.indexOf(item.value) >= 0 || 'string' != typeof item.label || !item.label) throw failure('DIALOG_INVALID', '选项需要唯一有效值和标签');
                                    values.push(item.value);
                                    return {
                                        id: 'item-' + index,
                                        label: item.label.slice(0, 80),
                                        value: item.value,
                                        description: String(item.description || '').slice(0, 240),
                                        disabled: true === item.disabled
                                    };
                                });
                                data.multiple = true === o.multiple;
                                data.minSelected = integer(o.minSelected, data.multiple ? 0 : 1, _runtimeContract.DIALOG_LIMITS.items);
                                data.maxSelected = integer(o.maxSelected, data.multiple ? _runtimeContract.DIALOG_LIMITS.items : 1, _runtimeContract.DIALOG_LIMITS.items);
                                if (data.minSelected > data.maxSelected || !data.multiple && (1 !== data.minSelected || 1 !== data.maxSelected)) throw failure('DIALOG_INVALID', '选择数量范围无效');
                                data.value = data.multiple ? void 0 === o.value ? [] : o.value : o.value;
                                const selected = data.multiple ? data.value : void 0 === data.value ? [] : [
                                    data.value
                                ];
                                if (!Array.isArray(selected) || selected.some((v, i)=>selected.indexOf(v) !== i || !data.items.some((item)=>item.value === v && !item.disabled))) throw failure('DIALOG_INVALID', '初始选择无效');
                                if (selected.length > data.maxSelected) throw failure('DIALOG_INVALID', '初始选择数量超过上限');
                            }
                            return data;
                        }
                        function openDialog(type, options, owner) {
                            return new Promise((resolve, reject)=>{
                                if (current) return void reject(failure('DIALOG_BUSY', '已有对话框正在显示'));
                                let data;
                                try {
                                    data = normalize(type, options);
                                } catch (error) {
                                    reject(error);
                                    return;
                                }
                                current = {
                                    data,
                                    owner,
                                    resolve,
                                    result: null
                                };
                                try {
                                    (0, _routeManager.push)(routes[type], {
                                        dialogId: data.id
                                    });
                                } catch (_) {
                                    current = null;
                                    reject(failure('DIALOG_OPEN_FAILED', '无法打开对话框'));
                                }
                            });
                        }
                        function getDialog(type, id) {
                            return current && current.data.id === id && (current.data.type === type || 'confirm' === type && 'alert' === current.data.type) ? current.data : null;
                        }
                        function settleDialog(data, action, value) {
                            if (!current || current.data.id !== data.id || current.result) return false;
                            current.result = {
                                action,
                                value: 'confirm' !== action || 'confirm' === data.type || 'alert' === data.type ? null : value
                            };
                            return true;
                        }
                        function deliverDialog(owner) {
                            if (!current || current.owner !== owner || !current.result) return false;
                            const request = current;
                            current = null;
                            request.resolve(request.result);
                            return true;
                        }
                        function cancelOwnedDialog(owner) {
                            if (!current || current.owner !== owner) return;
                            const request = current;
                            current = null;
                            request.resolve({
                                action: 'cancel',
                                value: null
                            });
                        }
                        function closeOwnedDialog(owner) {
                            if (!current || current.owner !== owner) return false;
                            if (!current.result) {
                                current.result = {
                                    action: 'cancel',
                                    value: null
                                };
                                try {
                                    (0, _routeManager.back)();
                                } catch (error) {
                                    current.result = null;
                                    throw error;
                                }
                            }
                            return true;
                        }
                        function dialogDestroyed(data) {
                            if (current && current.data.id === data.id && !current.result) current.result = {
                                action: 'cancel',
                                value: null
                            };
                        }
                    },
                    "./src/utils/core/routeManager.js": function(__unused_webpack_module, exports) {
                        "use strict";
                        Object.defineProperty(exports, "__esModule", {
                            value: true
                        });
                        exports.back = back;
                        exports["default"] = void 0;
                        exports.push = push;
                        exports.replace = replace;
                        exports.resolveRoute = resolveRoute;
                        var _system = _interopRequireDefault($app_require$1("@app-module/system.router"));
                        function _interopRequireDefault(e) {
                            return e && e.__esModule ? e : {
                                default: e
                            };
                        }
                        const ROUTES = {
                            index: '/',
                            editor: '/workspace/editor',
                            aiGenerate: '/workspace/ai-generate',
                            run: '/workspace/run',
                            newFile: '/workspace/new',
                            settings: '/settings',
                            settingsEditor: '/settings/editor',
                            settingsFonts: '/settings/editor/fonts',
                            settingsHighlight: '/settings/editor/highlight',
                            settingsAbout: '/settings/about',
                            settingsHelp: '/settings/help',
                            settingsCloud: '/settings/cloud',
                            settingsCloudFiles: '/settings/cloud/files',
                            toolsMarket: '/tools/market',
                            toolsMarketUpload: '/tools/market/upload',
                            toolsMarketView: '/tools/market/view',
                            toolsMoney: '/tools/money',
                            overlayConfirm: '/overlay/confirm',
                            overlaySelect: '/overlay/select',
                            overlayNumberInput: '/overlay/number-input',
                            overlayTextInput: '/overlay/text-input'
                        };
                        function normalizePath(route) {
                            const value = route.trim().replace(/\\/g, '/');
                            if (!value || '/' === value) return '/';
                            if (-1 !== value.indexOf('://')) return value;
                            const path = ('/' === value.charAt(0) ? value : '/' + value).replace(/\/+/g, '/').replace(/\/+$/, '') || '/';
                            if ('/' === path) return ROUTES.index;
                            if (path.split('/').some((segment)=>'..' === segment || '.' === segment)) throw new Error('非法页面路径：' + route);
                            if (!/^\/[A-Za-z0-9_-]+(?:\/[A-Za-z0-9_-]+)*$/.test(path)) throw new Error('页面 slug 只能包含字母、数字、下划线和连字符：' + route);
                            return path;
                        }
                        function resolveRoute(route) {
                            if ('string' != typeof route) return ROUTES.index;
                            const key = route.trim();
                            if (Object.prototype.hasOwnProperty.call(ROUTES, key)) return ROUTES[key];
                            return normalizePath(key);
                        }
                        function push(route, params) {
                            const options = {
                                uri: resolveRoute(route)
                            };
                            if (params) options.params = params;
                            _system.default.push(options);
                        }
                        function back() {
                            _system.default.back();
                        }
                        function replace(route, params) {
                            const options = {
                                uri: resolveRoute(route)
                            };
                            if (params) options.params = params;
                            _system.default.replace(options);
                        }
                        var _default = exports["default"] = {
                            resolveRoute,
                            push,
                            replace,
                            back
                        };
                    },
                    "./src/utils/files/scriptData.js": function(__unused_webpack_module, exports) {
                        "use strict";
                        Object.defineProperty(exports, "__esModule", {
                            value: true
                        });
                        exports.createScriptStorage = createScriptStorage;
                        exports["default"] = void 0;
                        exports.readScriptStorageContent = readScriptStorageContent;
                        exports.removeScriptStorage = removeScriptStorage;
                        exports.renameScriptStorage = renameScriptStorage;
                        exports.replaceScriptStorageContent = replaceScriptStorageContent;
                        var _system = _interopRequireDefault($app_require$1("@app-module/system.file"));
                        function _interopRequireDefault(e) {
                            return e && e.__esModule ? e : {
                                default: e
                            };
                        }
                        const DATA_URI = "internal://files/jslab-script-data.json";
                        let cache = null;
                        let loadPromise = null;
                        let writeQueue = Promise.resolve();
                        function clone(value) {
                            if (void 0 === value) return;
                            return JSON.parse(JSON.stringify(value));
                        }
                        function readFile() {
                            return new Promise((resolve, reject)=>{
                                _system.default.readText({
                                    uri: DATA_URI,
                                    success (data) {
                                        try {
                                            const parsed = JSON.parse(data && data.text ? data.text : '{}');
                                            resolve(parsed && 'object' == typeof parsed ? parsed : {});
                                        } catch (error) {
                                            resolve({});
                                        }
                                    },
                                    fail (data, code) {
                                        if (301 === Number(code)) resolve({});
                                        else reject(new Error("scriptData read failed: " + code));
                                    }
                                });
                            });
                        }
                        function load() {
                            if (cache) return Promise.resolve(cache);
                            if (!loadPromise) loadPromise = readFile().then((value)=>{
                                cache = value;
                                loadPromise = null;
                                return cache;
                            }).catch((error)=>{
                                loadPromise = null;
                                throw error;
                            });
                            return loadPromise;
                        }
                        function persist(next) {
                            return new Promise((resolve, reject)=>{
                                _system.default.writeText({
                                    uri: DATA_URI,
                                    text: JSON.stringify(next),
                                    success: ()=>{
                                        cache = next;
                                        resolve(true);
                                    },
                                    fail (data, code) {
                                        reject(new Error("scriptData write failed: " + code));
                                    }
                                });
                            });
                        }
                        function mutate(update) {
                            writeQueue = writeQueue.catch(()=>{}).then(()=>load()).then((root)=>{
                                const next = clone(root);
                                if (false === update(next)) return false;
                                return persist(next);
                            });
                            return writeQueue;
                        }
                        function namespaceName(name) {
                            const value = String(name || 'untitled.js');
                            let hash = 2166136261;
                            for(let i = 0; i < value.length; i += 1){
                                hash ^= value.charCodeAt(i);
                                hash = Math.imul(hash, 16777619) >>> 0;
                            }
                            const readable = value.replace(/[^a-zA-Z0-9._-]/g, '_').slice(0, 48);
                            return 'n_' + hash.toString(16).padStart(8, '0') + '_' + readable;
                        }
                        function createScriptStorage(scriptName) {
                            const namespace = namespaceName(scriptName);
                            function getNamespace(root, create) {
                                if (!root[namespace] && create) root[namespace] = {
                                    data: {},
                                    config: {}
                                };
                                if (!root[namespace]) return {
                                    data: {},
                                    config: {}
                                };
                                root[namespace].data = root[namespace].data && 'object' == typeof root[namespace].data ? root[namespace].data : {};
                                root[namespace].config = root[namespace].config && 'object' == typeof root[namespace].config ? root[namespace].config : {};
                                return root[namespace];
                            }
                            function get(area, key, fallback) {
                                return load().then((root)=>{
                                    const values = getNamespace(root, false)[area];
                                    const name = String(key);
                                    const value = Object.prototype.hasOwnProperty.call(values, name) ? values[name] : void 0;
                                    return clone(void 0 === value ? fallback : value);
                                });
                            }
                            function set(area, key, value) {
                                return mutate((next)=>{
                                    const item = getNamespace(next, true);
                                    const name = String(key);
                                    const saved = clone(value);
                                    if ('__proto__' === name) Object.defineProperty(item[area], name, {
                                        value: saved,
                                        enumerable: true,
                                        writable: true,
                                        configurable: true
                                    });
                                    else item[area][name] = saved;
                                });
                            }
                            function remove(area, key) {
                                return mutate((next)=>{
                                    delete getNamespace(next, false)[area][String(key)];
                                });
                            }
                            function clear(area) {
                                return mutate((next)=>{
                                    next[namespace] = next[namespace] || {
                                        data: {},
                                        config: {}
                                    };
                                    next[namespace][area] = {};
                                });
                            }
                            function all(area) {
                                return load().then((root)=>clone(getNamespace(root, false)[area]));
                            }
                            return {
                                data: {
                                    get: (key, fallback)=>get('data', key, fallback),
                                    set: (key, value)=>set('data', key, value),
                                    delete: (key)=>remove('data', key),
                                    clear: ()=>clear('data'),
                                    all: ()=>all('data')
                                },
                                config: {
                                    get: (key, fallback)=>get('config', key, fallback),
                                    set: (key, value)=>set('config', key, value),
                                    delete: (key)=>remove('config', key),
                                    clear: ()=>clear('config'),
                                    all: ()=>all('config')
                                }
                            };
                        }
                        function removeScriptStorage(scriptName) {
                            const namespace = namespaceName(scriptName);
                            return mutate((next)=>{
                                if (!Object.prototype.hasOwnProperty.call(next, namespace)) return false;
                                delete next[namespace];
                            });
                        }
                        function renameScriptStorage(oldName, newName) {
                            const from = namespaceName(oldName);
                            const to = namespaceName(newName);
                            if (from === to) return Promise.resolve(false);
                            return mutate((next)=>{
                                const hasOld = Object.prototype.hasOwnProperty.call(next, from);
                                const hasNew = Object.prototype.hasOwnProperty.call(next, to);
                                if (!hasOld && !hasNew) return false;
                                if (hasOld) next[to] = next[from];
                                else delete next[to];
                                delete next[from];
                            });
                        }
                        function storageDocument(value) {
                            if (!value || 'object' != typeof value || Array.isArray(value) || Object.keys(value).some((key)=>'data' !== key && 'config' !== key) || !Object.prototype.hasOwnProperty.call(value, 'data') || !Object.prototype.hasOwnProperty.call(value, 'config') || !value.data || 'object' != typeof value.data || Array.isArray(value.data) || !value.config || 'object' != typeof value.config || Array.isArray(value.config)) throw new Error('脚本数据必须是包含 data 和 config 两个对象的 JSON');
                            return {
                                data: value.data,
                                config: value.config
                            };
                        }
                        function storageContent(root, scriptName) {
                            const item = root[namespaceName(scriptName)] || {};
                            return JSON.stringify({
                                data: item.data || {},
                                config: item.config || {}
                            });
                        }
                        function readScriptStorageContent(scriptName) {
                            return writeQueue.catch(()=>{}).then(()=>load()).then((root)=>storageContent(root, scriptName));
                        }
                        function replaceScriptStorageContent(scriptName, base, content) {
                            let expected;
                            let replacement;
                            try {
                                expected = JSON.stringify(storageDocument(JSON.parse(base)));
                                replacement = storageDocument(JSON.parse(content));
                            } catch (error) {
                                return Promise.reject(new Error(error.message || '脚本数据 JSON 无效'));
                            }
                            return mutate((next)=>{
                                if (storageContent(next, scriptName) !== expected) throw new Error('脚本数据已变更，请重新读取后再保存；当前修改尚未覆盖设备数据');
                                const namespace = namespaceName(scriptName);
                                next[namespace] = next[namespace] || {};
                                next[namespace].data = replacement.data;
                                next[namespace].config = replacement.config;
                            });
                        }
                        var _default = exports["default"] = {
                            createScriptStorage,
                            removeScriptStorage,
                            renameScriptStorage
                        };
                    },
                    "./src/utils/runtime/runtimeContract.js": function(__unused_webpack_module, exports) {
                        "use strict";
                        Object.defineProperty(exports, "__esModule", {
                            value: true
                        });
                        exports.RUNTIME_CONTRACT = exports.LOG_LIMITS = exports.DIALOG_LIMITS = void 0;
                        const RUNTIME_CONTRACT = exports.RUNTIME_CONTRACT = "jslab-unified-open-ui";
                        const LOG_LIMITS = exports.LOG_LIMITS = {
                            entries: 64,
                            characters: 6144,
                            entryCharacters: 1024
                        };
                        const DIALOG_LIMITS = exports.DIALOG_LIMITS = {
                            textCharacters: 8000,
                            items: 100
                        };
                    },
                    "./src/utils/runtime/uiMediaCache.js": function(__unused_webpack_module, exports) {
                        "use strict";
                        Object.defineProperty(exports, "__esModule", {
                            value: true
                        });
                        exports.clearUiMediaCache = clearUiMediaCache;
                        const CACHE_ROOT = 'internal://cache/';
                        const OWNED_IMAGE = /^jslab-ui-[a-z0-9]+-[a-z0-9]*-\d+\.(png|jpg)$/;
                        async function clearUiMediaCache(files) {
                            function call(method, options) {
                                return new Promise((resolve, reject)=>{
                                    files[method](Object.assign({}, options, {
                                        success: resolve,
                                        fail: (message, code)=>reject(new Error('清理图片缓存失败（' + code + '）：' + message))
                                    }));
                                });
                            }
                            const result = await call('list', {
                                uri: CACHE_ROOT
                            });
                            let failure = null;
                            for (const entry of result.fileList){
                                const name = 0 === entry.uri.indexOf(CACHE_ROOT) ? entry.uri.slice(CACHE_ROOT.length) : entry.uri;
                                if (OWNED_IMAGE.test(name)) try {
                                    await call('delete', {
                                        uri: CACHE_ROOT + name
                                    });
                                } catch (error) {
                                    if (!failure) failure = error;
                                }
                            }
                            if (failure) throw failure;
                        }
                    },
                    "./src/manifest.json": function(module) {
                        "use strict";
                        module.exports = JSON.parse("__JSLAB_MANIFEST_JSON__");
                    }
                };
                var __webpack_module_cache__ = {};
                function __webpack_require__(moduleId) {
                    var cachedModule = __webpack_module_cache__[moduleId];
                    if (void 0 !== cachedModule) return cachedModule.exports;
                    var module = __webpack_module_cache__[moduleId] = {
                        exports: {}
                    };
                    __webpack_modules__[moduleId](module, module.exports, __webpack_require__);
                    return module.exports;
                }
                (()=>{
                    __webpack_require__.g = (()=>{
                        if ('object' == typeof globalThis) return globalThis;
                        try {
                            return this || new Function('return this')();
                        } catch (e) {
                            if ('object' == typeof window) return window;
                        }
                    })();
                })();
                (()=>{
                    __webpack_require__.rv = ()=>"1.4.11";
                })();
                (()=>{
                    __webpack_require__.ruid = "bundler=rspack@1.4.11";
                })();
                var __webpack_exports__ = {};
                (()=>{
                    var $app_style$ = [];
                    var $app_script$ = function __scriptModule__(module, exports, $app_require$1) {
                        "use strict";
                        Object.defineProperty(exports, "__esModule", {
                            value: true
                        });
                        exports.default = void 0;
                        var _system = _interopRequireDefault($app_require$1("@app-module/system.file"));
                        var _uiMediaCache = __webpack_require__("./src/utils/runtime/uiMediaCache.js");
                        var _scriptData = __webpack_require__("./src/utils/files/scriptData.js");
                        var _dialogState = __webpack_require__("./src/utils/core/dialogState.js");
                        function _interopRequireDefault(e) {
                            return e && e.__esModule ? e : {
                                default: e
                            };
                        }
                        let payload = null;
                        var _default = exports.default = {
                            uiMediaReady: null,
                            onCreate () {
                                this.uiMediaReady = (0, _uiMediaCache.clearUiMediaCache)(_system.default).catch((error)=>console.warn(error.message));
                            },
                            onDestroy () {
                                payload = null;
                            },
                            loadPayload () {
                                return Promise.resolve().then(()=>{
                                    if (!payload) payload = JSON.parse("__JSLAB_PAYLOAD_JSON__");
                                    return payload;
                                });
                            },
                            getScriptStorage (name) {
                                return (0, _scriptData.createScriptStorage)(name);
                            },
                            openDialog (type, options, owner) {
                                return (0, _dialogState.openDialog)(type, options, owner);
                            },
                            getDialog (type, id) {
                                return (0, _dialogState.getDialog)(type, id);
                            },
                            settleDialog (data, action, value) {
                                return (0, _dialogState.settleDialog)(data, action, value);
                            },
                            deliverDialog (owner) {
                                return (0, _dialogState.deliverDialog)(owner);
                            },
                            cancelOwnedDialog (owner) {
                                return (0, _dialogState.cancelOwnedDialog)(owner);
                            },
                            closeOwnedDialog (owner) {
                                return (0, _dialogState.closeOwnedDialog)(owner);
                            },
                            dialogDestroyed (data) {
                                return (0, _dialogState.dialogDestroyed)(data);
                            }
                        };
                    };
                    $app_script$({}, $app_exports$, $app_require$1);
                    $app_exports$.default.style = $app_style$;
                    $app_exports$.default.manifest = __webpack_require__("./src/manifest.json");
                    var $translateStyle$ = function(value) {
                        if ('string' == typeof value) return Object.fromEntries(value.split(';').filter((item)=>Boolean(item && item.trim())).map((item)=>{
                            const matchs = item.match(/([^:]+):(.*)/);
                            if (matchs && matchs.length > 2) return [
                                matchs[1].trim().replace(/-([a-z])/g, (_, match)=>match.toUpperCase()),
                                matchs[2].trim()
                            ];
                            return [];
                        }));
                        return value;
                    };
                    __webpack_require__.g.$translateStyle$ = $translateStyle$;
                })();
            })();
        };
        return createAppHandler();
    })(global, globalThis, window, $app_exports$, $app_evaluate$);
}
