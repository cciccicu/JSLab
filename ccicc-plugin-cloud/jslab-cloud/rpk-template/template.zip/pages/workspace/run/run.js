export default function(global, globalThis, window, $app_exports$, $app_evaluate$) {
    var org_app_require = $app_require$;
    (function(global, globalThis, window, $app_exports$, $app_evaluate$) {
        var setTimeout = global.setTimeout;
        var setInterval = global.setInterval;
        var clearTimeout = global.clearTimeout;
        var clearInterval = global.clearInterval;
        var $app_require$1 = global.$app_require$ || org_app_require;
        var createPageHandler = function() {
            return (()=>{
                var __webpack_modules__ = {
                    "./src/utils/core/routeManager.js": function(__unused_webpack_module, exports) {
                        "use strict";
                        Object.defineProperty(exports, "__esModule", {
                            value: true
                        });
                        exports.back = back;
                        exports["default"] = void 0;
                        exports.push = push;
                        exports.replace = replace;
                        exports.resolveRoute = resolveRoute;
                        var _system = _interopRequireDefault($app_require$1("@app-module/system.router"));
                        function _interopRequireDefault(e) {
                            return e && e.__esModule ? e : {
                                default: e
                            };
                        }
                        const ROUTES = {
                            index: '/',
                            editor: '/workspace/editor',
                            aiGenerate: '/workspace/ai-generate',
                            run: '/workspace/run',
                            newFile: '/workspace/new',
                            settings: '/settings',
                            settingsEditor: '/settings/editor',
                            settingsFonts: '/settings/editor/fonts',
                            settingsHighlight: '/settings/editor/highlight',
                            settingsAbout: '/settings/about',
                            settingsHelp: '/settings/help',
                            settingsCloud: '/settings/cloud',
                            settingsCloudFiles: '/settings/cloud/files',
                            toolsMarket: '/tools/market',
                            toolsMarketUpload: '/tools/market/upload',
                            toolsMarketView: '/tools/market/view',
                            toolsMoney: '/tools/money',
                            overlayConfirm: '/overlay/confirm',
                            overlaySelect: '/overlay/select',
                            overlayNumberInput: '/overlay/number-input',
                            overlayTextInput: '/overlay/text-input'
                        };
                        function normalizePath(route) {
                            const value = route.trim().replace(/\\/g, '/');
                            if (!value || '/' === value) return '/';
                            if (-1 !== value.indexOf('://')) return value;
                            const path = ('/' === value.charAt(0) ? value : '/' + value).replace(/\/+/g, '/').replace(/\/+$/, '') || '/';
                            if ('/' === path) return ROUTES.index;
                            if (path.split('/').some((segment)=>'..' === segment || '.' === segment)) throw new Error('非法页面路径：' + route);
                            if (!/^\/[A-Za-z0-9_-]+(?:\/[A-Za-z0-9_-]+)*$/.test(path)) throw new Error('页面 slug 只能包含字母、数字、下划线和连字符：' + route);
                            return path;
                        }
                        function resolveRoute(route) {
                            if ('string' != typeof route) return ROUTES.index;
                            const key = route.trim();
                            if (Object.prototype.hasOwnProperty.call(ROUTES, key)) return ROUTES[key];
                            return normalizePath(key);
                        }
                        function push(route, params) {
                            const options = {
                                uri: resolveRoute(route)
                            };
                            if (params) options.params = params;
                            _system.default.push(options);
                        }
                        function back() {
                            _system.default.back();
                        }
                        function replace(route, params) {
                            const options = {
                                uri: resolveRoute(route)
                            };
                            if (params) options.params = params;
                            _system.default.replace(options);
                        }
                        var _default = exports["default"] = {
                            resolveRoute,
                            push,
                            replace,
                            back
                        };
                    },
                    "./src/utils/core/runtimeCompat.js": function(__unused_webpack_module, exports) {
                        "use strict";
                        Object.defineProperty(exports, "__esModule", {
                            value: true
                        });
                        exports.getPageElement = getPageElement;
                        exports.loadOptionalSystemModule = loadOptionalSystemModule;
                        exports.scheduleNextTick = scheduleNextTick;
                        function unavailableError(featureName) {
                            const error = new Error(featureName + ' 在当前设备上不可用');
                            error.code = 203;
                            return error;
                        }
                        function createUnavailableModule(featureName, methodNames) {
                            const module = {
                                __available: false
                            };
                            methodNames.forEach((methodName)=>{
                                module[methodName] = (options)=>{
                                    const error = unavailableError(featureName);
                                    if (options && ('function' == typeof options.fail || 'function' == typeof options.complete)) return void setTimeout(()=>{
                                        try {
                                            if ('function' == typeof options.fail) options.fail(error.message, 203);
                                        } finally{
                                            if ('function' == typeof options.complete) options.complete();
                                        }
                                    }, 0);
                                    throw error;
                                };
                            });
                            return module;
                        }
                        function loadOptionalSystemModule(app, featureName, methodNames, loader) {
                            try {
                                const capabilityName = '@' + featureName;
                                if (app && 'function' == typeof app.canIUse && !app.canIUse(capabilityName)) return createUnavailableModule(featureName, methodNames);
                                return loader();
                            } catch (error) {
                                return createUnavailableModule(featureName, methodNames);
                            }
                        }
                        function scheduleNextTick(context, callback) {
                            if (context && 'function' == typeof context.$nextTick) return void context.$nextTick(callback);
                            setTimeout(callback, 0);
                        }
                        function getPageElement(context, id) {
                            if (!context || 'function' != typeof context.$element) return null;
                            return context.$element(id);
                        }
                    },
                    "./src/utils/core/time.js": function(__unused_webpack_module, exports) {
                        "use strict";
                        Object.defineProperty(exports, "__esModule", {
                            value: true
                        });
                        exports.formatClock = formatClock;
                        exports.getCurrentClock = getCurrentClock;
                        exports.startPageClock = startPageClock;
                        exports.stopPageClock = stopPageClock;
                        function formatClock(date) {
                            const hours = date.getHours();
                            const minutes = date.getMinutes();
                            const hourText = hours < 10 ? '0' + hours : String(hours);
                            const minuteText = minutes < 10 ? '0' + minutes : String(minutes);
                            return hourText + ':' + minuteText;
                        }
                        function getCurrentClock() {
                            return formatClock(new Date());
                        }
                        const pageClocks = new WeakMap();
                        function stopPageClock(page) {
                            if (!pageClocks.has(page)) return;
                            clearTimeout(pageClocks.get(page));
                            pageClocks.delete(page);
                        }
                        function startPageClock(page) {
                            stopPageClock(page);
                            const tick = ()=>{
                                const date = new Date();
                                const value = formatClock(date);
                                if (page.nowTime !== value) page.nowTime = value;
                                pageClocks.set(page, setTimeout(tick, 60000 - (1000 * date.getSeconds() + date.getMilliseconds())));
                            };
                            tick();
                        }
                    },
                    "./src/utils/core/uiFeedback.js": function(__unused_webpack_module, exports) {
                        "use strict";
                        Object.defineProperty(exports, "__esModule", {
                            value: true
                        });
                        exports.showToast = showToast;
                        exports.vibrate = vibrate;
                        var _system = _interopRequireDefault($app_require$1("@app-module/system.prompt"));
                        var _system2 = _interopRequireDefault($app_require$1("@app-module/system.vibrator"));
                        function _interopRequireDefault(e) {
                            return e && e.__esModule ? e : {
                                default: e
                            };
                        }
                        function vibrate(mode) {
                            if (mode) _system2.default.vibrate({
                                mode
                            });
                        }
                        function showToast(message, duration) {
                            const milliseconds = Number(duration);
                            _system.default.showToast({
                                message: String(null == message ? '' : message),
                                duration: isFinite(milliseconds) ? Math.min(10000, Math.max(1500, milliseconds)) : 1500
                            });
                        }
                    },
                    "./src/utils/runtime/consoleBuffer.js": function(__unused_webpack_module, exports, __webpack_require__) {
                        "use strict";
                        Object.defineProperty(exports, "__esModule", {
                            value: true
                        });
                        exports.createConsoleBuffer = createConsoleBuffer;
                        exports.formatError = formatError;
                        var _runtimeContract = __webpack_require__("./src/utils/runtime/runtimeContract.js");
                        function formatError(error) {
                            try {
                                if (error && void 0 !== error.message) return ((error.name ? String(error.name) + ': ' : '') + String(error.message)).slice(0, 512);
                                return String(error).slice(0, 512);
                            } catch (_) {
                                return '无法显示错误';
                            }
                        }
                        function preview(value, budget, depth, seen) {
                            if (budget.remaining <= 0) return '';
                            let result;
                            try {
                                if (null === value || 'object' != typeof value) result = 'function' == typeof value ? '[Function]' : String(value);
                                else if (value instanceof Error) result = formatError(value);
                                else if (seen.indexOf(value) >= 0) result = '[Circular]';
                                else if (depth >= 2) result = Array.isArray(value) ? '[Array]' : '[Object]';
                                else {
                                    seen.push(value);
                                    const array = Array.isArray(value), parts = [];
                                    let count = 0;
                                    for(const key in value){
                                        if (!Object.prototype.hasOwnProperty.call(value, key)) continue;
                                        if (count >= 8 || budget.remaining < 8) {
                                            parts.push('…');
                                            break;
                                        }
                                        count += 1;
                                        const label = array ? '' : String(key).slice(0, 40) + ': ';
                                        budget.remaining -= label.length + 2;
                                        let item;
                                        try {
                                            item = value[key];
                                        } catch (_) {
                                            item = '[无法读取]';
                                        }
                                        parts.push(label + preview(item, budget, depth + 1, seen));
                                    }
                                    seen.pop();
                                    return (array ? '[' : '{') + parts.join(', ') + (array ? ']' : '}');
                                }
                            } catch (_) {
                                result = '[无法显示]';
                            }
                            const available = Math.max(0, budget.remaining);
                            const clipped = result.length > available ? result.slice(0, Math.max(0, available - 1)) + '…' : result;
                            budget.remaining -= clipped.length;
                            return clipped;
                        }
                        function createConsoleBuffer(changed) {
                            let entries = [], characters = 0, omitted = 0, active = true;
                            function write(level, args) {
                                if (!active) return;
                                const budget = {
                                    remaining: _runtimeContract.LOG_LIMITS.entryCharacters - 16
                                }, parts = [];
                                for(let i = 0; i < args.length && budget.remaining > 0; i += 1){
                                    parts.push(preview(args[i], budget, 0, []));
                                    budget.remaining -= 1;
                                }
                                const entry = ('log' === level ? '' : '[' + level + '] ') + parts.join(' ');
                                entries.push(entry);
                                characters += entry.length + 1;
                                while(entries.length > _runtimeContract.LOG_LIMITS.entries || characters > _runtimeContract.LOG_LIMITS.characters){
                                    characters -= entries.shift().length + 1;
                                    omitted += 1;
                                }
                                changed();
                            }
                            return {
                                console: {
                                    log (...args) {
                                        write('log', args);
                                    },
                                    info (...args) {
                                        write('info', args);
                                    },
                                    warn (...args) {
                                        write('warn', args);
                                    },
                                    error (...args) {
                                        write('error', args);
                                    },
                                    clear () {
                                        if (!active) return;
                                        entries = [];
                                        characters = 0;
                                        omitted = 0;
                                        changed();
                                    }
                                },
                                read () {
                                    return (omitted ? '已省略 ' + omitted + ' 条较早日志\n' : '') + entries.join('\n');
                                },
                                dispose () {
                                    active = false;
                                    entries = [];
                                    characters = 0;
                                    omitted = 0;
                                }
                            };
                        }
                    },
                    "./src/utils/runtime/runtimeContract.js": function(__unused_webpack_module, exports) {
                        "use strict";
                        Object.defineProperty(exports, "__esModule", {
                            value: true
                        });
                        exports.RUNTIME_CONTRACT = exports.LOG_LIMITS = exports.DIALOG_LIMITS = void 0;
                        const RUNTIME_CONTRACT = exports.RUNTIME_CONTRACT = "jslab-unified-open-ui";
                        const LOG_LIMITS = exports.LOG_LIMITS = {
                            entries: 64,
                            characters: 6144,
                            entryCharacters: 1024
                        };
                        const DIALOG_LIMITS = exports.DIALOG_LIMITS = {
                            textCharacters: 8000,
                            items: 100
                        };
                    },
                    "./src/utils/runtime/scriptDialogApi.js": function(__unused_webpack_module, exports) {
                        "use strict";
                        Object.defineProperty(exports, "__esModule", {
                            value: true
                        });
                        exports.createScriptDialogApi = createScriptDialogApi;
                        exports["default"] = void 0;
                        function createScriptDialogApi(appDefinition, isActive, owner) {
                            const api = {};
                            [
                                'alert',
                                'confirm',
                                'text',
                                'number',
                                'select'
                            ].forEach((type)=>{
                                api[type] = (options)=>{
                                    if (!isActive()) {
                                        const error = new Error('运行页已退出');
                                        error.code = 'DIALOG_INACTIVE';
                                        return Promise.reject(error);
                                    }
                                    return appDefinition.openDialog(type, options, owner);
                                };
                            });
                            return api;
                        }
                        var _default = exports["default"] = {
                            createScriptDialogApi
                        };
                    },
                    "./src/utils/runtime/scriptRuntimeApi.js": function(__unused_webpack_module, exports, __webpack_require__) {
                        "use strict";
                        Object.defineProperty(exports, "__esModule", {
                            value: true
                        });
                        exports.createScriptRuntimeApi = createScriptRuntimeApi;
                        exports["default"] = void 0;
                        var _system = _interopRequireDefault($app_require$1("@app-module/system.app"));
                        var _system2 = _interopRequireDefault($app_require$1("@app-module/system.device"));
                        var _system3 = _interopRequireDefault($app_require$1("@app-module/system.configuration"));
                        var _system4 = _interopRequireDefault($app_require$1("@app-module/system.file"));
                        var _system5 = _interopRequireDefault($app_require$1("@app-module/system.network"));
                        var _system6 = _interopRequireDefault($app_require$1("@app-module/system.brightness"));
                        var _system7 = _interopRequireDefault($app_require$1("@app-module/system.geolocation"));
                        var _system8 = _interopRequireDefault($app_require$1("@app-module/system.vibrator"));
                        var _system9 = _interopRequireDefault($app_require$1("@app-module/system.sensor"));
                        var _system0 = _interopRequireDefault($app_require$1("@app-module/system.fetch"));
                        var _system1 = _interopRequireDefault($app_require$1("@app-module/system.interconnect"));
                        var _system10 = _interopRequireDefault($app_require$1("@app-module/system.uploadtask"));
                        var _system11 = _interopRequireDefault($app_require$1("@app-module/system.request"));
                        var _system12 = _interopRequireDefault($app_require$1("@app-module/system.crypto"));
                        var _scriptDialogApi = __webpack_require__("./src/utils/runtime/scriptDialogApi.js");
                        var _runtimeCompat = __webpack_require__("./src/utils/core/runtimeCompat.js");
                        var _uiFeedback = __webpack_require__("./src/utils/core/uiFeedback.js");
                        function _interopRequireDefault(e) {
                            return e && e.__esModule ? e : {
                                default: e
                            };
                        }
                        const battery = (0, _runtimeCompat.loadOptionalSystemModule)(_system.default, 'system.battery', [
                            'getStatus'
                        ], ()=>$app_require$1("@app-module/system.battery"));
                        const event = (0, _runtimeCompat.loadOptionalSystemModule)(_system.default, 'system.event', [
                            'publish',
                            'subscribe',
                            'unsubscribe'
                        ], ()=>$app_require$1("@app-module/system.event"));
                        const record = (0, _runtimeCompat.loadOptionalSystemModule)(_system.default, 'system.record', [
                            'start',
                            'stop'
                        ], ()=>$app_require$1("@app-module/system.record"));
                        const audio = (0, _runtimeCompat.loadOptionalSystemModule)(_system.default, 'system.audio', [
                            'play',
                            'pause',
                            'stop',
                            'getPlayState'
                        ], ()=>$app_require$1("@app-module/system.audio"));
                        function createScriptRuntimeApi(appDefinition, options) {
                            const name = String(options.name || 'untitled.js');
                            const isActive = options.isActive;
                            const storage = appDefinition.getScriptStorage(name);
                            return {
                                script: {
                                    name,
                                    canUse (capability) {
                                        try {
                                            return !!_system.default.canIUse(capability);
                                        } catch (error) {
                                            return false;
                                        }
                                    },
                                    locale () {
                                        try {
                                            return _system3.default.getLocale();
                                        } catch (error) {
                                            return {
                                                language: '',
                                                countryOrRegion: ''
                                            };
                                        }
                                    },
                                    exit () {
                                        if (isActive()) options.exit();
                                    },
                                    reload () {
                                        if (isActive()) options.reload();
                                    },
                                    toast (message, duration) {
                                        if (!isActive()) return;
                                        (0, _uiFeedback.showToast)(message, duration);
                                    },
                                    data: storage.data,
                                    config: storage.config
                                },
                                dialog: (0, _scriptDialogApi.createScriptDialogApi)(appDefinition, isActive, options.owner),
                                system: {
                                    device: _system2.default,
                                    files: _system4.default,
                                    http: {
                                        request: (options)=>_system0.default.fetch(options)
                                    },
                                    download: {
                                        start: (options)=>_system11.default.download(options),
                                        wait: (options)=>_system11.default.onDownloadComplete(options)
                                    },
                                    upload: {
                                        file: (options)=>_system10.default.uploadFile(options)
                                    },
                                    companion: _system1.default,
                                    network: _system5.default,
                                    display: _system6.default,
                                    battery,
                                    location: _system7.default,
                                    vibration: _system8.default,
                                    events: event,
                                    sensors: _system9.default,
                                    recorder: record,
                                    audio,
                                    crypto: _system12.default
                                }
                            };
                        }
                        var _default = exports["default"] = {
                            createScriptRuntimeApi
                        };
                    },
                    "./src/utils/runtime/uiLayout.js": function(__unused_webpack_module, exports) {
                        "use strict";
                        Object.defineProperty(exports, "__esModule", {
                            value: true
                        });
                        exports.UI_PERFORMANCE_GUIDE = void 0;
                        exports.color = color;
                        exports.compileUi = compileUi;
                        exports.number = number;
                        exports.sameNode = sameNode;
                        exports.text = text;
                        const UI_PERFORMANCE_GUIDE = exports.UI_PERFORMANCE_GUIDE = {
                            declarations: 40,
                            paintedNodes: 160,
                            depth: 4,
                            qrcodes: 2
                        };
                        function number(value, min, max, fallback) {
                            if (null == value) return fallback;
                            const result = Number(value);
                            return isFinite(result) ? Math.min(max, Math.max(min, result)) : fallback;
                        }
                        function text(value) {
                            return String(null == value ? '' : value).slice(0, 1024);
                        }
                        function color(value, fallback) {
                            if (null == value) return fallback;
                            const source = String(value).trim();
                            if (/^#[0-9a-f]{6}$/i.test(source)) return source;
                            if (/^#[0-9a-f]{3}$/i.test(source)) return '#' + source.slice(1).split('').map((c)=>c + c).join('');
                            const match = /^rgb\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})\s*\)$/.exec(source);
                            if (match && match.slice(1).every((part)=>Number(part) <= 255)) return source;
                            const rgba = /^rgba\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(0|1|0?\.\d+)\s*\)$/.exec(source);
                            return rgba && rgba.slice(1, 4).every((part)=>Number(part) <= 255) ? source : fallback;
                        }
                        function widthOf(value, available, fallback) {
                            const percent = 'string' == typeof value && /^(\d+(?:\.\d+)?)%$/.exec(value);
                            return Math.round(percent ? number(Number(percent[1]) * available / 100, 1, available, fallback) : number(value, 1, available, fallback));
                        }
                        function list(value) {
                            return Array.isArray(value) ? value : null == value || false === value ? [] : [
                                value
                            ];
                        }
                        function offset(align, spare) {
                            return 'center' === align ? spare / 2 : 'end' === align ? spare : 0;
                        }
                        function background(raw, fallback) {
                            return color(raw.background, fallback);
                        }
                        const GRID_TONES = {
                            primary: '#1769d2',
                            success: '#16845b',
                            warning: '#a55d16',
                            danger: '#b93838'
                        };
                        const BUTTON_TONES = {
                            primary: '#0d6eff',
                            neutral: '#34373d',
                            danger: '#d94343'
                        };
                        function tone(raw, grid) {
                            const colors = grid ? GRID_TONES : BUTTON_TONES;
                            const selected = colors[raw.tone];
                            return background(raw, 'string' == typeof selected ? selected : grid ? '#292c31' : '#0d6eff');
                        }
                        function sameNode(a, b) {
                            if (!a || !b) return false;
                            if (a.text !== b.text || a.background !== b.background) return false;
                            const keys = Object.keys(a);
                            if (keys.length !== Object.keys(b).length) return false;
                            for(let i = 0; i < keys.length; i += 1)if (a[keys[i]] !== b[keys[i]]) return false;
                            return true;
                        }
                        function compileUi(source, top, previous, cache) {
                            const nodes = [];
                            const handlers = Object.create(null);
                            const ids = Object.create(null);
                            let old = null;
                            const nextCache = Object.create(null);
                            let count = 0;
                            function previousNode(id) {
                                if (!old) {
                                    old = Object.create(null);
                                    (previous || []).forEach((node)=>{
                                        old[node.id] = node;
                                    });
                                }
                                return old[id];
                            }
                            function identity(raw, path) {
                                const id = null == raw.id ? '$' + path : String(raw.id);
                                if (null != raw.id && (!id || id.length > 56 || '$' === id.charAt(0))) throw new Error('UI id 需为 1–56 字符，不能以 $ 开头');
                                if (ids[id]) throw new Error('UI id 重复：' + id);
                                ids[id] = true;
                                return id;
                            }
                            function measureGridCell(cell, w, h, id) {
                                if (ids[id]) throw new Error('UI id 重复：' + id);
                                ids[id] = true;
                                const entry = cache && cache[id];
                                const cached = entry && entry.grid ? entry : null;
                                const before = cached && cached.input;
                                const value = cell.text;
                                const sizeInput = cell.size;
                                const lineInput = cell.lineHeight;
                                const colorInput = cell.color;
                                const bgInput = cell.background;
                                const toneInput = cell.tone;
                                if (before && cached.availableWidth === w && cached.height === h && value === before.text && sizeInput === before.size && lineInput === before.lineHeight && colorInput === before.color && bgInput === before.background && toneInput === before.tone) {
                                    nextCache[id] = cached;
                                    return {
                                        id,
                                        kind: 'text',
                                        w,
                                        h,
                                        node: cached.node,
                                        cached
                                    };
                                }
                                const input = {
                                    text: value,
                                    size: sizeInput,
                                    lineHeight: lineInput,
                                    color: colorInput,
                                    background: bgInput,
                                    tone: toneInput
                                };
                                const oldNode = cached && cached.node;
                                const size = before && sizeInput === before.size ? oldNode.size : number(sizeInput, 16, 30, 24);
                                const node = {
                                    id,
                                    kind: 'text',
                                    width: Math.round(w),
                                    background: before && bgInput === before.background && toneInput === before.tone ? oldNode.background : tone(input, true),
                                    radius: 12,
                                    text: before && value === before.text ? oldNode.text : text(value).slice(0, 8),
                                    color: before && colorInput === before.color ? oldNode.color : color(colorInput, '#ffffff'),
                                    size,
                                    align: 'center',
                                    bold: 'bold',
                                    lineHeight: before && lineInput === before.lineHeight && size === oldNode.size ? oldNode.lineHeight : number(lineInput, size, 64, Math.max(size + 4, 32)),
                                    lines: 1,
                                    x: oldNode && oldNode.x,
                                    y: oldNode && oldNode.y,
                                    height: Math.ceil(h)
                                };
                                let cacheable = true;
                                for(const key in input)if (null !== input[key] && ('object' == typeof input[key] || 'function' == typeof input[key])) cacheable = false;
                                const next = {
                                    grid: true,
                                    availableWidth: w,
                                    width: w,
                                    height: h,
                                    input: cacheable ? input : null,
                                    node
                                };
                                nextCache[id] = next;
                                return {
                                    id,
                                    kind: 'text',
                                    w,
                                    h,
                                    node,
                                    cached: next
                                };
                            }
                            function finishLayout(box, layout) {
                                const { raw, kind, padding, inner, gap, columns, cellHeight, horizontal, remaining, weight, children } = layout;
                                let natural = 0;
                                if (horizontal) box.children.forEach((child)=>{
                                    natural = Math.max(natural, child.h);
                                });
                                else if ('grid' === kind) natural = Math.ceil(children.length / columns) * (cellHeight + gap) - (children.length ? gap : 0);
                                else if ('stack' === kind) box.children.forEach((child)=>{
                                    natural = Math.max(natural, child.h + number(child.raw.y, 0, 4096, 0));
                                });
                                else box.children.forEach((child, i)=>{
                                    natural += child.h + (i ? gap : 0);
                                });
                                box.h = Math.max(natural + 2 * padding, number(raw.height, 0, 8192, natural + 2 * padding));
                                const extra = Math.max(0, box.h - 2 * padding - natural);
                                let cursor = padding + (horizontal || 'column' !== kind ? 0 : offset(raw.justify, extra));
                                const freeX = horizontal && !weight ? remaining : 0;
                                if (horizontal) cursor += offset(raw.justify, freeX);
                                const between = 'between' === raw.justify && children.length > 1 ? (horizontal ? freeX : extra) / (children.length - 1) : 0;
                                box.children.forEach((child, i)=>{
                                    child.x = horizontal ? cursor : padding + offset(raw.align, inner - child.w);
                                    child.y = horizontal ? padding + offset(raw.align, box.h - 2 * padding - child.h) : cursor;
                                    if ('grid' === kind) {
                                        child.x = padding + i % columns * (child.w + gap);
                                        child.y = padding + Math.floor(i / columns) * (child.h + gap);
                                    }
                                    if ('stack' === kind) {
                                        child.x = padding + number(child.raw.x, 0, Math.max(0, inner - child.w), 0);
                                        child.y = padding + number(child.raw.y, 0, 4096, 0);
                                    }
                                    cursor += (horizontal ? child.w : child.h) + gap + between;
                                });
                                box.radius = number(raw.radius, 0, 80, 0);
                            }
                            function measure(input, available, path, forcedWidth, generated) {
                                const active = new Set();
                                const frames = [
                                    {
                                        input,
                                        available,
                                        path,
                                        forcedWidth,
                                        generated,
                                        parent: null,
                                        index: 0
                                    }
                                ];
                                let rootBox = null;
                                function attach(frame, box) {
                                    if (frame.parent) frame.parent.children[frame.index] = box;
                                    else rootBox = box;
                                }
                                while(frames.length){
                                    const frame = frames.pop();
                                    if (frame.exit) {
                                        finishLayout(frame.box, frame.layout);
                                        active.delete(frame.raw);
                                        attach(frame, frame.box);
                                        continue;
                                    }
                                    const raw = frame.input && 'object' == typeof frame.input ? frame.input : {
                                        kind: 'text',
                                        text: frame.input
                                    };
                                    if (active.has(raw)) throw new Error('UI 布局不能循环引用');
                                    count += 1;
                                    const id = frame.generated || identity(raw, frame.path);
                                    if (frame.generated) {
                                        if (ids[id]) throw new Error('UI id 重复：' + id);
                                        ids[id] = true;
                                    }
                                    const kind = raw.kind || 'text';
                                    const w = null == frame.forcedWidth ? widthOf(raw.width, frame.available, frame.available) : frame.forcedWidth;
                                    const box = {
                                        id,
                                        kind,
                                        w,
                                        h: 0,
                                        raw
                                    };
                                    if ('row' !== kind && 'column' !== kind && 'stack' !== kind && 'buttonRow' !== kind && 'grid' !== kind) {
                                        attach(frame, measureLeaf(box, raw, id, kind, w));
                                        continue;
                                    }
                                    active.add(raw);
                                    box.background = background(raw, 'transparent');
                                    const padding = number(raw.padding, 0, Math.min(48, (w - 1) / 2), 0);
                                    const inner = w - 2 * padding;
                                    const gap = number(raw.gap, 0, 48, 'grid' === kind || 'buttonRow' === kind ? 6 : 8);
                                    const children = list('buttonRow' === kind ? raw.buttons : 'grid' === kind ? raw.items : raw.children).filter((child)=>null != child && false !== child);
                                    const columns = Math.round(number(raw.columns, 2, 4, 4));
                                    const cellHeight = 'grid' === kind ? number(raw.cellHeight, 44, 72, 52) : 0;
                                    const cellWidth = (inner - gap * (columns - 1)) / columns;
                                    if ('grid' === kind && children.length && cellWidth < 1) throw new Error('grid 宽度不足：减小 columns、padding 或 gap');
                                    const horizontal = 'row' === kind || 'buttonRow' === kind;
                                    let remaining = inner - gap * Math.max(0, ('grid' === kind ? columns : children.length) - 1);
                                    let weight = 0;
                                    const widths = [];
                                    if (horizontal) {
                                        children.forEach((child, i)=>{
                                            const item = child && 'object' == typeof child ? child : {};
                                            if (null != item.width) {
                                                widths[i] = widthOf(item.width, inner, inner);
                                                remaining -= widths[i];
                                            } else {
                                                widths[i] = null;
                                                weight += number(item.flex, 0.1, 100, 1);
                                            }
                                        });
                                        if (remaining < 0 || weight && remaining < children.length) throw new Error('row 宽度不足：减小 width、padding 或 gap');
                                    }
                                    box.children = new Array(children.length);
                                    const layout = {
                                        raw,
                                        kind,
                                        padding,
                                        inner,
                                        gap,
                                        columns,
                                        cellHeight,
                                        horizontal,
                                        remaining,
                                        weight,
                                        children
                                    };
                                    frames.push({
                                        exit: true,
                                        box,
                                        layout,
                                        raw,
                                        parent: frame.parent,
                                        index: frame.index
                                    });
                                    if ('grid' === kind) {
                                        children.forEach((child, i)=>{
                                            const cell = child && 'object' == typeof child ? child : {
                                                text: child
                                            };
                                            box.children[i] = measureGridCell(cell, cellWidth, cellHeight, id + '/cell/' + i);
                                        });
                                        continue;
                                    }
                                    for(let i = children.length - 1; i >= 0; i -= 1){
                                        const child = children[i];
                                        let item = child;
                                        let childWidth;
                                        let generatedId;
                                        if (horizontal) {
                                            childWidth = null == widths[i] ? remaining * number(child && child.flex, 0.1, 100, 1) / weight : widths[i];
                                            if (childWidth < 1) throw new Error('row 子项宽度不足：调整 flex、width、padding 或 gap');
                                        }
                                        if ('buttonRow' === kind) {
                                            const button = child && 'object' == typeof child ? child : {
                                                text: child
                                            };
                                            item = Object.assign({}, button, {
                                                kind: 'button',
                                                text: text(button.text).slice(0, 8),
                                                height: 60
                                            });
                                            if (null == button.id) generatedId = id + '/button/' + i;
                                        }
                                        const childPath = frame.path.length < 48 ? frame.path + '.' + i : '#' + count + '.' + i;
                                        frames.push({
                                            input: item,
                                            available: inner,
                                            path: childPath,
                                            forcedWidth: childWidth,
                                            generated: generatedId,
                                            parent: box,
                                            index: i
                                        });
                                    }
                                }
                                return rootBox;
                            }
                            function measureLeaf(box, raw, id, kind, w) {
                                if ('spacer' === kind) {
                                    box.h = number(raw.size, 0, 480, 12);
                                    return box;
                                }
                                if ('button' === kind && true !== raw.disabled && 'function' == typeof raw.onPress) handlers[id] = raw.onPress;
                                if (('switch' === kind || 'slider' === kind) && 'function' == typeof raw.onChange) handlers[id] = raw.onChange;
                                const cached = cache && cache[id];
                                let matched = !!cached && !cached.grid && null !== cached.input && cached.availableWidth === w;
                                let keyCount = 0;
                                for(const key in raw)if ('onPress' !== key && 'onChange' !== key) {
                                    keyCount += 1;
                                    if (matched && raw[key] !== cached.input[key]) matched = false;
                                }
                                if (matched && keyCount === cached.keyCount) {
                                    nextCache[id] = cached;
                                    box.w = cached.width;
                                    box.h = cached.height;
                                    box.node = cached.node;
                                    box.cached = cached;
                                    return box;
                                }
                                let inputCopy = {};
                                for(const key in raw){
                                    if ('onPress' === key || 'onChange' === key) continue;
                                    const value = raw[key];
                                    if (null !== value && ('object' == typeof value || 'function' == typeof value)) {
                                        inputCopy = null;
                                        break;
                                    }
                                    inputCopy[key] = value;
                                }
                                const node = {
                                    id,
                                    kind,
                                    width: Math.round(w),
                                    background: background(raw, 'transparent'),
                                    radius: number(raw.radius, 0, 80, 0)
                                };
                                box.node = node;
                                box.cached = {
                                    availableWidth: w,
                                    input: inputCopy,
                                    keyCount,
                                    node
                                };
                                nextCache[id] = box.cached;
                                if ('divider' === kind) {
                                    box.h = number(raw.height, 1, 32, 2);
                                    node.background = color(raw.color, '#34373d');
                                    return box;
                                }
                                if ('qrcode' === kind) {
                                    const value = String(null == raw.value ? '' : raw.value);
                                    if (!value || value.length > 256) throw new Error('二维码内容需为 1–256 字符');
                                    if (w < 96) throw new Error('二维码需要至少 96px 宽度');
                                    box.w = Math.min(w, number(raw.size, 96, 288, 160));
                                    box.h = box.w;
                                    node.width = Math.round(box.w);
                                    node.value = value;
                                    node.color = color(raw.color, '#000000');
                                    node.background = background(raw, '#ffffff');
                                    node.qrSize = Math.max(80, Math.round(box.w - 16));
                                    return box;
                                }
                                if (-1 === [
                                    'heading',
                                    'text',
                                    'button',
                                    'switch',
                                    'slider',
                                    'progress'
                                ].indexOf(kind)) throw new Error('不支持的 UI 组件：' + kind);
                                node.text = text(raw.text);
                                node.color = color(raw.color, '#ffffff');
                                node.size = number(raw.size, 16, 36, 'heading' === kind ? 30 : 24);
                                node.align = [
                                    'left',
                                    'center',
                                    'right'
                                ].indexOf(raw.align) < 0 ? 'left' : raw.align;
                                node.bold = 'heading' === kind || 'button' === kind || true === raw.bold ? 'bold' : 'normal';
                                node.lineHeight = number(raw.lineHeight, node.size, 64, Math.max(node.size + 4, 'heading' === kind ? 40 : 32));
                                const before = cached ? cached.node : previousNode(id);
                                node.lines = Math.round(number(raw.lines, 1, 64, 0));
                                if (!node.lines) {
                                    if (before && before.kind === kind && before.text === node.text && before.width === node.width && before.size === node.size) node.lines = before.autoLines;
                                    if (!node.lines) {
                                        const perLine = Math.max(1, Math.floor((node.width - ('button' === kind ? 16 : 0)) / node.size));
                                        node.lines = node.text.split('\n').reduce((sum, line)=>sum + Math.max(1, Math.ceil(line.length / perLine)), 0);
                                    }
                                    node.autoLines = node.lines;
                                }
                                box.h = number(raw.height, 1, 8192, node.lineHeight * node.lines);
                                if ('button' === kind) {
                                    box.h = Math.max(48, number(raw.height, 48, 480, Math.max(64, node.lineHeight * node.lines + 16)));
                                    node.disabled = true === raw.disabled;
                                    node.background = node.disabled ? '#34373d' : tone(raw, false);
                                    if (node.disabled) node.color = '#999999';
                                    node.radius = number(raw.radius, 0, 80, 32);
                                }
                                if ('switch' === kind || 'slider' === kind || 'progress' === kind) {
                                    if (w < 160) throw new Error(kind + ' 需要至少 160px 宽度');
                                    node.background = background(raw, '#24262a');
                                    node.radius = number(raw.radius, 0, 80, 32);
                                    node.accent = color(raw.accent, 'progress' === kind ? color(raw.color, '#0d6eff') : '#0d6eff');
                                    node.trackColor = color(raw.trackColor, '#3b3e44');
                                    node.thumbColor = color(raw.thumbColor, '#ffffff');
                                    node.detail = text(raw.detail);
                                    node.detailColor = color(raw.detailColor, '#999999');
                                    node.copyWidth = Math.max(40, w - 110);
                                    node.checked = !!raw.checked;
                                    node.min = number(raw.min, -100000, 100000, 0);
                                    node.max = Math.max(node.min, number(raw.max, -100000, 100000, 100));
                                    node.step = number(raw.step, 0.01, 100000, 1);
                                    node.value = number(raw.value, node.min, node.max, node.min);
                                    node.percent = Math.round(number(raw.percent, 0, 100, 0));
                                    box.h = number(raw.height, 'switch' === kind && node.detail ? 94 : 80, 480, 'slider' === kind ? 100 : 'progress' === kind ? 90 : node.detail ? 94 : 80);
                                }
                                return box;
                            }
                            function emit(root, left, topPosition) {
                                const frames = [
                                    {
                                        box: root,
                                        left,
                                        topPosition
                                    }
                                ];
                                while(frames.length){
                                    const frame = frames.pop();
                                    const box = frame.box;
                                    const x = Math.round(frame.left);
                                    const y = Math.round(frame.topPosition);
                                    if (box.children) {
                                        if ('transparent' !== box.background) add({
                                            id: box.id,
                                            kind: 'background',
                                            x,
                                            y,
                                            width: Math.round(box.w),
                                            height: Math.ceil(box.h),
                                            background: box.background,
                                            radius: box.radius
                                        });
                                        for(let i = box.children.length - 1; i >= 0; i -= 1){
                                            const child = box.children[i];
                                            frames.push({
                                                box: child,
                                                left: frame.left + child.x,
                                                topPosition: frame.topPosition + child.y
                                            });
                                        }
                                    } else if ('spacer' !== box.kind) {
                                        let node = box.node;
                                        if (node.x !== x || node.y !== y || node.height !== Math.ceil(box.h)) {
                                            if (cache && cache[box.id] && node === cache[box.id].node) node = Object.assign({}, node);
                                            node.x = x;
                                            node.y = y;
                                            node.height = Math.ceil(box.h);
                                        }
                                        const paintedNode = add(node);
                                        if (box.cached && (box.cached.width !== box.w || box.cached.height !== box.h || box.cached.node !== paintedNode)) {
                                            const entry = cache && box.cached === cache[box.id] ? Object.assign({}, box.cached) : box.cached;
                                            entry.width = box.w;
                                            entry.height = box.h;
                                            entry.node = paintedNode;
                                            nextCache[box.id] = entry;
                                        }
                                    }
                                }
                            }
                            function add(node) {
                                const aligned = previous && previous[nodes.length];
                                const before = aligned && aligned.id === node.id ? aligned : previousNode(node.id);
                                const result = before === node || sameNode(before, node) ? before : node;
                                nodes.push(result);
                                return result;
                            }
                            const roots = list(source);
                            let y = top;
                            roots.forEach((raw, i)=>{
                                if (null == raw || false === raw) return;
                                const box = measure(raw, 324, String(i));
                                emit(box, 6, y);
                                y += box.h + 10;
                            });
                            return {
                                nodes,
                                handlers,
                                height: Math.max(480, Math.ceil(y + 14)),
                                end: y,
                                count,
                                cache: nextCache
                            };
                        }
                    },
                    "./src/utils/runtime/uiPublisher.js": function(__unused_webpack_module, exports) {
                        "use strict";
                        Object.defineProperty(exports, "__esModule", {
                            value: true
                        });
                        exports.createUiPublisher = createUiPublisher;
                        function copyNode(node) {
                            const copy = {};
                            for(const key in node)if ('autoLines' !== key) copy[key] = node[key];
                            return copy;
                        }
                        function patchNode(target, next, before) {
                            if (next === before) return;
                            for(const key in next)if ('autoLines' !== key && next[key] !== before[key]) target[key] = next[key];
                        }
                        function createUiPublisher() {
                            let previous = [];
                            return {
                                update (nodes, observed) {
                                    if (nodes === previous) return observed;
                                    const aligned = observed.length === previous.length;
                                    let stable = aligned && nodes.length === previous.length;
                                    if (stable) {
                                        for(let i = 0; i < nodes.length; i += 1)if (nodes[i].id !== previous[i].id || nodes[i].kind !== previous[i].kind) {
                                            stable = false;
                                            break;
                                        }
                                    }
                                    let result = observed;
                                    if (stable) {
                                        for(let i = 0; i < nodes.length; i += 1)if (nodes[i] !== previous[i]) patchNode(observed[i], nodes[i], previous[i]);
                                    } else {
                                        const retained = Object.create(null);
                                        if (aligned) {
                                            for(let i = 0; i < previous.length; i += 1)retained[previous[i].id] = i;
                                        }
                                        result = nodes.map((node)=>{
                                            const index = retained[node.id];
                                            if (void 0 !== index && previous[index].kind === node.kind) {
                                                patchNode(observed[index], node, previous[index]);
                                                return observed[index];
                                            }
                                            return copyNode(node);
                                        });
                                    }
                                    previous = nodes;
                                    return result;
                                }
                            };
                        }
                    },
                    "./src/utils/runtime/uiRuntime.js": function(__unused_webpack_module, exports, __webpack_require__) {
                        "use strict";
                        Object.defineProperty(exports, "__esModule", {
                            value: true
                        });
                        exports.createUiSession = createUiSession;
                        var _uiLayout = __webpack_require__("./src/utils/runtime/uiLayout.js");
                        const nextTurn = Promise.resolve();
                        function node(kind, props, options) {
                            return Object.assign({}, props, options || {}, {
                                kind
                            });
                        }
                        function createUiSession(host) {
                            let active = true;
                            let queued = false;
                            let rendering = false;
                            let source = null;
                            let hasSource = false;
                            let nodes = [];
                            let cache = null;
                            let handlers = Object.create(null);
                            let forcePublish = false;
                            let visible = true;
                            let dirty = false;
                            let hasFrame = false;
                            let frameHeight = 480;
                            let frameEnd = 84;
                            function flush() {
                                queued = false;
                                if (!active || !hasSource) return;
                                if (rendering) throw new Error('不要在 UI 渲染函数中更新状态');
                                rendering = true;
                                try {
                                    const view = 'function' == typeof source ? source() : source;
                                    const result = (0, _uiLayout.compileUi)(view, host.top(), nodes, cache);
                                    const changed = forcePublish || nodes.length !== result.nodes.length || result.nodes.some((item, index)=>item !== nodes[index]);
                                    if (visible) host.publish(changed ? result.nodes : nodes, result.height, result.end, changed);
                                    cache = result.cache;
                                    handlers = result.handlers;
                                    if (changed) nodes = result.nodes;
                                    hasFrame = true;
                                    frameHeight = result.height;
                                    frameEnd = result.end;
                                    dirty = false;
                                    forcePublish = !visible;
                                    return true;
                                } catch (error) {
                                    forcePublish = true;
                                    host.error(error);
                                } finally{
                                    rendering = false;
                                }
                            }
                            function refresh() {
                                if (!active) return;
                                if (rendering) throw new Error('不要在 UI 渲染函数中更新状态');
                                dirty = true;
                                if (!visible) return;
                                if (queued) return;
                                queued = true;
                                nextTurn.then(()=>{
                                    if (queued && visible) flush();
                                    else queued = false;
                                });
                            }
                            const ui = {
                                version: 2,
                                render (view) {
                                    if (!active) return false;
                                    if (rendering) throw new Error('不要在 UI 渲染函数中调用 ui.render');
                                    if (host.clearError) host.clearError();
                                    const previous = {
                                        source,
                                        hasSource,
                                        nodes,
                                        cache,
                                        handlers,
                                        hasFrame,
                                        frameHeight,
                                        frameEnd,
                                        dirty,
                                        visible
                                    };
                                    source = view;
                                    hasSource = true;
                                    let success = flush();
                                    if (success && host.show) {
                                        try {
                                            success = false !== host.show();
                                        } catch (error) {
                                            host.error(error);
                                            success = false;
                                        }
                                    }
                                    if (!success) {
                                        source = previous.source;
                                        hasSource = previous.hasSource;
                                        nodes = previous.nodes;
                                        cache = previous.cache;
                                        handlers = previous.handlers;
                                        hasFrame = previous.hasFrame;
                                        frameHeight = previous.frameHeight;
                                        frameEnd = previous.frameEnd;
                                        dirty = previous.dirty;
                                        visible = previous.visible;
                                        forcePublish = true;
                                        if (visible && hasFrame) {
                                            try {
                                                host.publish(nodes, frameHeight, frameEnd, true);
                                                forcePublish = false;
                                            } catch (error) {
                                                host.error(error);
                                            }
                                        }
                                        if (dirty && visible && hasSource) refresh();
                                    }
                                    return !!success;
                                },
                                show () {
                                    if (!active || !hasFrame) return false;
                                    return host.show ? false !== host.show() : true;
                                },
                                hide () {
                                    if (active && host.hide) host.hide();
                                },
                                refresh,
                                setTitle (value) {
                                    if (active) host.title((0, _uiLayout.text)(value).slice(0, 80) || '脚本');
                                },
                                showHeader (visible) {
                                    if (active && host.header(false !== visible)) refresh();
                                },
                                scrollTo (position) {
                                    if (active) host.scroll(position);
                                },
                                scrollTop () {
                                    if (active) host.scroll('top');
                                },
                                scrollBottom () {
                                    if (active) host.scroll('bottom');
                                },
                                signal (initial) {
                                    let value = initial;
                                    const state = {
                                        get () {
                                            return value;
                                        },
                                        set (next) {
                                            if (rendering) throw new Error('不要在 UI 渲染函数中更新 signal');
                                            if (value === next || value !== value && next !== next) return value;
                                            value = next;
                                            refresh();
                                            return value;
                                        },
                                        update (updater) {
                                            return state.set('function' == typeof updater ? updater(value) : updater);
                                        }
                                    };
                                    return state;
                                },
                                heading (value, options) {
                                    return node('heading', {
                                        text: value
                                    }, options);
                                },
                                text (value, options) {
                                    return node('text', {
                                        text: value
                                    }, options);
                                },
                                button (value, onPress, options) {
                                    return node('button', {
                                        text: value,
                                        onPress
                                    }, options);
                                },
                                switch (value, checked, onChange, options) {
                                    return node('switch', {
                                        text: value,
                                        checked,
                                        onChange
                                    }, options);
                                },
                                slider (value, amount, onChange, options) {
                                    return node('slider', {
                                        text: value,
                                        value: amount,
                                        onChange
                                    }, options);
                                },
                                progress (value, percent, options) {
                                    return node('progress', {
                                        text: value,
                                        percent
                                    }, options);
                                },
                                grid (items, options) {
                                    return node('grid', {
                                        items
                                    }, options);
                                },
                                buttonRow (buttons, options) {
                                    return node('buttonRow', {
                                        buttons
                                    }, options);
                                },
                                divider (options) {
                                    return node('divider', {}, options);
                                },
                                spacer (size) {
                                    return node('spacer', {
                                        size
                                    });
                                },
                                row (children, options) {
                                    return node('row', {
                                        children
                                    }, options);
                                },
                                column (children, options) {
                                    return node('column', {
                                        children
                                    }, options);
                                },
                                stack (children, options) {
                                    return node('stack', {
                                        children
                                    }, options);
                                },
                                qrcode (value, options) {
                                    return node('qrcode', {
                                        value
                                    }, options);
                                }
                            };
                            return {
                                ui,
                                refresh,
                                hasFrame () {
                                    return hasFrame;
                                },
                                setVisible (value) {
                                    const next = false !== value;
                                    if (!active) return false;
                                    if (visible === next && !(next && forcePublish)) return true;
                                    visible = next;
                                    if (visible && hasFrame) {
                                        forcePublish = true;
                                        if (dirty) return flush();
                                        try {
                                            host.publish(nodes, frameHeight, frameEnd, true);
                                            forcePublish = false;
                                            return true;
                                        } catch (error) {
                                            host.error(error);
                                            return false;
                                        }
                                    }
                                    return true;
                                },
                                invoke (id, value) {
                                    if (!active || !visible || 'function' != typeof handlers[id]) return false;
                                    try {
                                        if (host.clearError && host.clearError()) refresh();
                                        const result = handlers[id](value);
                                        if (result && 'function' == typeof result.then) result.then(null, (error)=>{
                                            if (active) host.error(error);
                                        });
                                    } catch (error) {
                                        if (active) host.error(error);
                                    }
                                    return true;
                                },
                                dispose () {
                                    active = false;
                                    queued = false;
                                    source = null;
                                    nodes = [];
                                    cache = null;
                                    handlers = Object.create(null);
                                }
                            };
                        }
                    }
                };
                var __webpack_module_cache__ = {};
                function __webpack_require__(moduleId) {
                    var cachedModule = __webpack_module_cache__[moduleId];
                    if (void 0 !== cachedModule) return cachedModule.exports;
                    var module = __webpack_module_cache__[moduleId] = {
                        exports: {}
                    };
                    __webpack_modules__[moduleId](module, module.exports, __webpack_require__);
                    return module.exports;
                }
                (()=>{
                    __webpack_require__.g = (()=>{
                        if ('object' == typeof globalThis) return globalThis;
                        try {
                            return this || new Function('return this')();
                        } catch (e) {
                            if ('object' == typeof window) return window;
                        }
                    })();
                })();
                (()=>{
                    __webpack_require__.rv = ()=>"1.4.11";
                })();
                (()=>{
                    __webpack_require__.ruid = "bundler=rspack@1.4.11";
                })();
                var __webpack_exports__ = {};
                (()=>{
                    var $app_style$ = [
                        [
                            [
                                [
                                    0,
                                    "page"
                                ]
                            ],
                            {
                                width: "336px",
                                height: "480px",
                                overflow: "hidden",
                                backgroundColor: "#000000"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "content"
                                ]
                            ],
                            {
                                width: "336px",
                                height: "480px",
                                flexDirection: "column"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "content-inner"
                                ]
                            ],
                            {
                                width: "336px",
                                flexShrink: 0
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "node-wrap"
                                ]
                            ],
                            {
                                position: "absolute",
                                flexDirection: "column",
                                justifyContent: "center",
                                alignItems: "center",
                                overflow: "hidden"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "ui-text"
                                ]
                            ],
                            {
                                width: "100%",
                                flexShrink: 0,
                                textOverflow: "ellipsis"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "ui-button"
                                ]
                            ],
                            {
                                width: "100%",
                                height: "100%",
                                paddingTop: "0px",
                                paddingRight: "8px",
                                paddingBottom: "0px",
                                paddingLeft: "8px",
                                justifyContent: "center",
                                alignItems: "center"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "control-card"
                                ]
                            ],
                            {
                                width: "100%",
                                height: "100%",
                                paddingTop: "12px",
                                paddingRight: "16px",
                                paddingBottom: "12px",
                                paddingLeft: "16px",
                                flexDirection: "row",
                                alignItems: "center"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "control-copy"
                                ]
                            ],
                            {
                                flexDirection: "column"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "control-label"
                                ]
                            ],
                            {
                                width: "100%",
                                fontSize: "23px",
                                lineHeight: "28px",
                                fontWeight: "bold",
                                lines: 1,
                                textOverflow: "ellipsis"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "control-detail"
                                ]
                            ],
                            {
                                width: "100%",
                                fontSize: "20px",
                                lineHeight: "26px",
                                lines: 2,
                                textOverflow: "ellipsis"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "ui-switch"
                                ]
                            ],
                            {
                                width: "68px",
                                marginLeft: "8px"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "value-card"
                                ]
                            ],
                            {
                                width: "100%",
                                height: "100%",
                                paddingTop: "12px",
                                paddingRight: "16px",
                                paddingBottom: "12px",
                                paddingLeft: "16px",
                                flexDirection: "column",
                                justifyContent: "center"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "value-header"
                                ]
                            ],
                            {
                                width: "100%",
                                flexDirection: "row",
                                alignItems: "center"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "value-label"
                                ]
                            ],
                            {
                                flex: 1,
                                fontSize: "23px",
                                lineHeight: "28px",
                                fontWeight: "bold",
                                lines: 1,
                                textOverflow: "ellipsis"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "value-text"
                                ]
                            ],
                            {
                                fontSize: "21px",
                                lineHeight: "28px",
                                fontWeight: "bold",
                                marginLeft: "6px"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "ui-slider"
                                ]
                            ],
                            {
                                width: "100%",
                                marginTop: "8px",
                                paddingLeft: "0px",
                                paddingRight: "0px"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "ui-progress"
                                ]
                            ],
                            {
                                width: "100%",
                                marginTop: "12px",
                                strokeWidth: "12px"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "empty-card"
                                ]
                            ],
                            {
                                position: "absolute",
                                left: "6px",
                                width: "324px",
                                paddingTop: "16px",
                                paddingRight: "18px",
                                paddingBottom: "16px",
                                paddingLeft: "18px",
                                borderRadius: "32px",
                                backgroundColor: "#24262a",
                                flexDirection: "column"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "error-card"
                                ]
                            ],
                            {
                                position: "absolute",
                                left: "6px",
                                width: "324px",
                                paddingTop: "16px",
                                paddingRight: "18px",
                                paddingBottom: "16px",
                                paddingLeft: "18px",
                                borderRadius: "32px",
                                backgroundColor: "#3a2020",
                                flexDirection: "column"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "empty-title"
                                ]
                            ],
                            {
                                color: "#ffffff",
                                fontSize: "28px",
                                lineHeight: "36px",
                                fontWeight: "bold"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "error-title"
                                ]
                            ],
                            {
                                color: "#f48771",
                                fontSize: "28px",
                                lineHeight: "36px",
                                fontWeight: "bold"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "empty-detail"
                                ]
                            ],
                            {
                                color: "#999999",
                                fontSize: "20px",
                                lineHeight: "28px",
                                marginTop: "6px"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "error-text"
                                ]
                            ],
                            {
                                color: "#f48771",
                                fontSize: "22px",
                                lineHeight: "30px",
                                marginTop: "8px"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "topbar-bg"
                                ]
                            ],
                            {
                                position: "absolute",
                                left: "0px",
                                top: "0px",
                                width: "336px",
                                height: "84px"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "time-text"
                                ]
                            ],
                            {
                                position: "absolute",
                                left: "78px",
                                top: "7px",
                                width: "180px",
                                lineHeight: "32px",
                                color: "#999999",
                                fontSize: "24px",
                                fontWeight: "bold",
                                textAlign: "center"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "title-text"
                                ]
                            ],
                            {
                                position: "absolute",
                                left: "78px",
                                top: "35px",
                                width: "180px",
                                lineHeight: "42px",
                                color: "#ffffff",
                                fontSize: "30px",
                                fontWeight: "bold",
                                textAlign: "center"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "title-marquee"
                                ]
                            ],
                            {
                                position: "absolute",
                                left: "78px",
                                top: "35px",
                                width: "180px",
                                lineHeight: "42px",
                                color: "#ffffff",
                                fontSize: "30px",
                                fontWeight: "bold",
                                textAlign: "center"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "btn"
                                ]
                            ],
                            {
                                position: "absolute",
                                width: "72px",
                                height: "72px"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "btn-left-top"
                                ]
                            ],
                            {
                                left: "6px",
                                top: "6px"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "btn-right-top"
                                ]
                            ],
                            {
                                left: "258px",
                                top: "6px"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "console-content"
                                ]
                            ],
                            {
                                position: "absolute",
                                top: "84px",
                                left: "6px",
                                width: "324px",
                                height: "396px",
                                paddingTop: "12px",
                                paddingRight: "12px",
                                paddingBottom: "24px",
                                paddingLeft: "12px",
                                flexDirection: "column"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "console-log"
                                ]
                            ],
                            {
                                width: "300px",
                                fontSize: "22px",
                                lineHeight: "30px",
                                color: "#0d6eff",
                                flexShrink: 0
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "console-hint"
                                ]
                            ],
                            {
                                width: "300px",
                                fontSize: "20px",
                                lineHeight: "28px",
                                color: "#999999",
                                flexShrink: 0,
                                marginBottom: "12px"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "console-error"
                                ]
                            ],
                            {
                                width: "300px",
                                fontSize: "22px",
                                lineHeight: "30px",
                                color: "#f48771",
                                flexShrink: 0,
                                marginTop: "12px"
                            }
                        ]
                    ];
                    var $app_script$ = function __scriptModule__(module, exports, $app_require$1) {
                        "use strict";
                        Object.defineProperty(exports, "__esModule", {
                            value: true
                        });
                        exports.default = void 0;
                        var _system = _interopRequireDefault($app_require$1("@app-module/system.app"));
                        var _system2 = _interopRequireDefault($app_require$1("@app-module/system.router"));
                        var _routeManager = __webpack_require__("./src/utils/core/routeManager.js");
                        var _uiFeedback = __webpack_require__("./src/utils/core/uiFeedback.js");
                        var _time = __webpack_require__("./src/utils/core/time.js");
                        var _runtimeCompat = __webpack_require__("./src/utils/core/runtimeCompat.js");
                        var _scriptRuntimeApi = __webpack_require__("./src/utils/runtime/scriptRuntimeApi.js");
                        var _uiRuntime = __webpack_require__("./src/utils/runtime/uiRuntime.js");
                        var _uiPublisher = __webpack_require__("./src/utils/runtime/uiPublisher.js");
                        var _consoleBuffer = __webpack_require__("./src/utils/runtime/consoleBuffer.js");
                        function _interopRequireDefault(e) {
                            return e && e.__esModule ? e : {
                                default: e
                            };
                        }
                        const runs = new WeakMap();
                        var _default = exports.default = {
                            private: {
                                nowTime: '00:00',
                                view: 'console',
                                pageTitle: '脚本',
                                showTopBar: true,
                                hasUi: false,
                                contentTopPadding: 84,
                                uiNodes: [],
                                emptyTitle: '空界面',
                                emptyDetail: '脚本未提供显示组件',
                                error: '',
                                logText: '',
                                layoutHeight: 480,
                                contentEnd: 84,
                                errorTop: 84
                            },
                            onInit () {
                                const pending = {
                                    active: true,
                                    visible: true
                                };
                                runs.set(this, pending);
                                this.$app.$def.loadPayload().then((start)=>{
                                    if (pending.active) this.startRun(start, pending.visible);
                                }, (error)=>{
                                    if (pending.active) this.error = (0, _consoleBuffer.formatError)(error);
                                });
                            },
                            startRun (start, visible) {
                                const state = {
                                    active: true,
                                    visible: visible,
                                    start: start || {
                                        name: 'untitled.js',
                                        code: ''
                                    },
                                    header: !start.options.hideTopBar,
                                    uiTitle: start.appName,
                                    publisher: (0, _uiPublisher.createUiPublisher)(),
                                    pending: null,
                                    logTimer: null,
                                    scroll: null
                                };
                                runs.set(this, state);
                                state.logs = (0, _consoleBuffer.createConsoleBuffer)(()=>this.queueLogs());
                                if (start.options.disableConsole) Object.keys(state.logs.console).forEach((key)=>{
                                    state.logs.console[key] = ()=>{};
                                });
                                this.showTopBar = state.header;
                                this.contentTopPadding = state.header ? 84 : 12;
                                state.session = (0, _uiRuntime.createUiSession)({
                                    top: ()=>state.header ? 84 : 12,
                                    title: (value)=>{
                                        state.uiTitle = value;
                                        if ('ui' === this.view) this.pageTitle = value;
                                    },
                                    header: (value)=>{
                                        value = value && !state.start.options.hideTopBar;
                                        if (state.header === value) return false;
                                        state.header = value;
                                        if ('ui' === this.view) {
                                            this.showTopBar = value;
                                            this.contentTopPadding = value ? 84 : 12;
                                        }
                                        return true;
                                    },
                                    show: ()=>this.showUi(),
                                    hide: ()=>this.showConsole(),
                                    scroll: (value)=>this.requestScroll(value),
                                    publish: (nodes, height, end, changed)=>this.publishUi(nodes, height, end, changed),
                                    error: (error)=>this.reportError(error),
                                    clearError: ()=>this.clearRuntimeError()
                                });
                                state.session.setVisible(false);
                                this.updateTime();
                                this.pageTitle = state.start.appName.slice(0, 80);
                                const runtime = (0, _scriptRuntimeApi.createScriptRuntimeApi)(this.$app.$def, {
                                    name: state.start.name,
                                    owner: this,
                                    isActive: ()=>state.active && !state.navigating && !state.pending,
                                    reload: ()=>this.reload(),
                                    exit: ()=>this.navigate('exit')
                                });
                                try {
                                    const execute = new Function('console', 'ui', 'dialog', "script", 'system', state.start.code);
                                    const result = execute(state.logs.console, state.session.ui, runtime.dialog, runtime.script, runtime.system);
                                    if (result && 'function' == typeof result.then) result.then(null, (error)=>this.reportError(error));
                                } catch (error) {
                                    this.reportError(error);
                                }
                                this.flushLogs();
                            },
                            onShow () {
                                (0, _time.startPageClock)(this);
                                const state = runs.get(this);
                                if (!state || !state.active) return;
                                state.visible = true;
                                this.$app.$def.deliverDialog(this);
                                if (state.pending) {
                                    const action = state.pending;
                                    state.pending = null;
                                    this.navigate(action);
                                    return;
                                }
                                if (state.session) state.session.setVisible('ui' === this.view);
                                if (state.logs && 'console' === this.view) this.flushLogs();
                                this.updateTime();
                            },
                            onHide () {
                                (0, _time.stopPageClock)(this);
                                const state = runs.get(this);
                                if (!state) return;
                                state.visible = false;
                                if (state.session) state.session.setVisible(false);
                                if (null !== state.logTimer) clearTimeout(state.logTimer);
                                state.logTimer = null;
                            },
                            onDestroy () {
                                (0, _time.stopPageClock)(this);
                                const state = runs.get(this);
                                if (!state) return;
                                state.active = false;
                                this.$app.$def.cancelOwnedDialog(this);
                                if (state.session) state.session.dispose();
                                if (state.logs) state.logs.dispose();
                                if (null !== state.logTimer) clearTimeout(state.logTimer);
                                runs.delete(this);
                            },
                            updateTime () {
                                this.nowTime = (0, _time.getCurrentClock)();
                            },
                            showUi () {
                                const state = runs.get(this);
                                if (!state || !state.active || state.navigating || state.pending || !state.session.hasFrame()) return false;
                                const previousView = this.view;
                                this.view = 'ui';
                                this.pageTitle = state.uiTitle;
                                this.showTopBar = state.header;
                                this.contentTopPadding = state.header ? 84 : 12;
                                if (null !== state.logTimer) clearTimeout(state.logTimer);
                                state.logTimer = null;
                                if (state.visible && false === state.session.setVisible(true)) {
                                    if ('console' === previousView) this.showConsole();
                                    return false;
                                }
                                this.hasUi = true;
                                return true;
                            },
                            showConsole () {
                                const state = runs.get(this);
                                if (!state || !state.active || state.navigating || state.pending) return;
                                state.session.setVisible(false);
                                this.view = 'console';
                                this.showTopBar = !state.start.options.hideTopBar;
                                this.pageTitle = state.start.appName.slice(0, 80);
                                if (state.visible) this.flushLogs();
                            },
                            restoreUi () {
                                const state = runs.get(this);
                                if (state && state.session) state.session.ui.show();
                            },
                            onBack () {
                                (0, _uiFeedback.vibrate)('short');
                                const state = runs.get(this);
                                if (state && state.session) if ('ui' === this.view) this.showConsole();
                                else this.navigate('exit');
                                else _system.default.terminate();
                            },
                            showAbout () {
                                _system2.default.push({
                                    uri: '/about'
                                });
                            },
                            onBackPress () {
                                this.onBack();
                                return true;
                            },
                            reload () {
                                this.navigate('reload');
                            },
                            navigate (action) {
                                const state = runs.get(this);
                                if (!state || !state.active || state.navigating || state.pending) return;
                                state.pending = action;
                                try {
                                    if (this.$app.$def.closeOwnedDialog(this)) return;
                                } catch (error) {
                                    state.pending = null;
                                    this.reportError(error);
                                    return;
                                }
                                state.pending = null;
                                state.navigating = true;
                                try {
                                    if ('reload' === action) (0, _routeManager.replace)('run');
                                    else _system.default.terminate();
                                } catch (error) {
                                    state.navigating = false;
                                    this.reportError(error);
                                }
                            },
                            queueLogs () {
                                const state = runs.get(this);
                                if (!state || !state.visible || 'console' !== this.view || null !== state.logTimer) return;
                                state.logTimer = setTimeout(()=>{
                                    state.logTimer = null;
                                    this.flushLogs();
                                }, 32);
                            },
                            flushLogs () {
                                const state = runs.get(this);
                                if (state && state.logs && state.active && state.visible && 'console' === this.view) this.logText = state.logs.read();
                            },
                            reportError (error) {
                                const state = runs.get(this);
                                if (!state || !state.active) return;
                                this.error = (0, _consoleBuffer.formatError)(error);
                                state.logs.console.error(this.error);
                                this.errorTop = this.uiNodes.length ? this.contentEnd : this.contentTopPadding + 140;
                                if ('ui' === this.view) this.layoutHeight = Math.max(this.layoutHeight, this.errorTop + 64 + 30 * Math.ceil(this.error.length / 12));
                                else this.flushLogs();
                            },
                            clearRuntimeError () {
                                if (!this.error) return false;
                                this.error = '';
                                return true;
                            },
                            publishUi (nodes, height, end, changed) {
                                const state = runs.get(this);
                                if (!state || !state.active) return;
                                if (changed) {
                                    try {
                                        const next = state.publisher.update(nodes, this.uiNodes);
                                        if (next !== this.uiNodes) this.uiNodes = next;
                                    } catch (error) {
                                        state.publisher = (0, _uiPublisher.createUiPublisher)();
                                        throw error;
                                    }
                                }
                                this.contentEnd = end;
                                if (this.error) {
                                    this.errorTop = nodes.length ? end : this.contentTopPadding + 140;
                                    height = Math.max(height, this.errorTop + 64 + 30 * Math.ceil(this.error.length / 12));
                                }
                                this.layoutHeight = height;
                                if (null !== state.scroll) this.requestScroll(state.scroll);
                            },
                            requestScroll (value) {
                                const state = runs.get(this);
                                if (!state) return;
                                state.scroll = value;
                                if (!state.visible || 'ui' !== this.view) return;
                                (0, _runtimeCompat.scheduleNextTick)(this, ()=>{
                                    if (!state.active || !state.visible || 'ui' !== this.view || null === state.scroll) return;
                                    const element = (0, _runtimeCompat.getPageElement)(this, 'ui-scroll');
                                    if (!element || !element.scrollTo) return;
                                    const target = state.scroll;
                                    state.scroll = null;
                                    element.scrollTo({
                                        top: 'bottom' === target ? this.layoutHeight : 'top' === target ? 0 : Number(target) || 0,
                                        left: 0,
                                        behavior: 'smooth'
                                    });
                                });
                            },
                            onButtonPress (id) {
                                const state = runs.get(this);
                                if (state && state.session.invoke(id)) (0, _uiFeedback.vibrate)('short');
                            },
                            onSwitchChange (id, event) {
                                const data = event && event.detail ? event.detail : event;
                                const state = runs.get(this);
                                if (state) state.session.invoke(id, !!(data && data.checked));
                            },
                            onSliderChange (id, event) {
                                const data = event && event.detail ? event.detail : event;
                                if (data && false === data.isFromUser) return;
                                const state = runs.get(this);
                                if (state) state.session.invoke(id, Number(data && data.progress) || 0);
                            }
                        };
                        const moduleOwn = exports.default || module.exports;
                        const accessors = [
                            'public',
                            'protected',
                            'private'
                        ];
                        if (moduleOwn.data && accessors.some(function(acc) {
                            return moduleOwn[acc];
                        })) throw new Error('页面VM对象中的属性data不可与"' + accessors.join(',') + '"同时存在，请使用private替换data名称');
                        if (!moduleOwn.data) {
                            moduleOwn.data = {};
                            moduleOwn._descriptor = {};
                            accessors.forEach(function(acc) {
                                const accType = typeof moduleOwn[acc];
                                if ('object' === accType) {
                                    moduleOwn.data = Object.assign(moduleOwn.data, moduleOwn[acc]);
                                    for(const name in moduleOwn[acc])moduleOwn._descriptor[name] = {
                                        access: acc
                                    };
                                } else if ('function' === accType) console.warn('页面VM对象中的属性' + acc + '的值不能是函数，请使用对象');
                            });
                        }
                    };
                    var $app_template$ = function(vm) {
                        const _vm_ = vm || this;
                        return aiot.__ce__("div", {
                            __vm__: _vm_,
                            __opts__: {
                                classList: [
                                    "page"
                                ]
                            }
                        }, [
                            aiot.__ci__({
                                __vm__: _vm_,
                                __opts__: {
                                    shown: function() {
                                        return "ui" === _vm_.view;
                                    }
                                }
                            }, function() {
                                return [
                                    aiot.__ce__("scroll", {
                                        __vm__: _vm_,
                                        __opts__: {
                                            id: "ui-scroll",
                                            classList: [
                                                "content"
                                            ],
                                            scrollY: "true",
                                            bounces: "true"
                                        }
                                    }, [
                                        aiot.__ce__("div", {
                                            __vm__: _vm_,
                                            __opts__: {
                                                classList: [
                                                    "content-inner"
                                                ],
                                                style: function() {
                                                    return __webpack_require__.g.$translateStyle$({
                                                        height: "" + _vm_.layoutHeight + "px"
                                                    });
                                                }
                                            }
                                        }, [
                                            aiot.__ci__({
                                                __vm__: _vm_,
                                                __opts__: {
                                                    shown: function() {
                                                        return 0 === _vm_.uiNodes.length;
                                                    }
                                                }
                                            }, function() {
                                                return [
                                                    aiot.__ce__("div", {
                                                        __vm__: _vm_,
                                                        __opts__: {
                                                            classList: [
                                                                "empty-card"
                                                            ],
                                                            style: function() {
                                                                return __webpack_require__.g.$translateStyle$({
                                                                    top: "" + _vm_.contentTopPadding + "px"
                                                                });
                                                            }
                                                        }
                                                    }, [
                                                        aiot.__ce__("text", {
                                                            __vm__: _vm_,
                                                            __opts__: {
                                                                classList: [
                                                                    "empty-title"
                                                                ],
                                                                value: function() {
                                                                    return _vm_.emptyTitle;
                                                                }
                                                            }
                                                        }, []),
                                                        aiot.__ce__("text", {
                                                            __vm__: _vm_,
                                                            __opts__: {
                                                                classList: [
                                                                    "empty-detail"
                                                                ],
                                                                value: function() {
                                                                    return _vm_.emptyDetail;
                                                                }
                                                            }
                                                        }, [])
                                                    ])
                                                ];
                                            }),
                                            aiot.__cf__({
                                                __vm__: _vm_,
                                                __opts__: {
                                                    exp: function() {
                                                        return {
                                                            __list__: _vm_.uiNodes,
                                                            __tid__: "id"
                                                        };
                                                    },
                                                    key: "$idx",
                                                    value: "node"
                                                }
                                            }, function($idx, node) {
                                                return [
                                                    aiot.__ce__("div", {
                                                        __vm__: _vm_,
                                                        __opts__: {
                                                            classList: [
                                                                "node-wrap"
                                                            ],
                                                            style: function() {
                                                                return __webpack_require__.g.$translateStyle$({
                                                                    left: "" + node.x + "px",
                                                                    top: "" + node.y + "px",
                                                                    width: "" + node.width + "px",
                                                                    height: "" + node.height + "px",
                                                                    backgroundColor: "" + node.background,
                                                                    borderRadius: "" + node.radius + "px"
                                                                });
                                                            }
                                                        }
                                                    }, [
                                                        aiot.__ci__({
                                                            __vm__: _vm_,
                                                            __opts__: {
                                                                shown: function() {
                                                                    return "heading" === node.kind || "text" === node.kind;
                                                                }
                                                            }
                                                        }, function() {
                                                            return [
                                                                aiot.__ce__("text", {
                                                                    __vm__: _vm_,
                                                                    __opts__: {
                                                                        classList: [
                                                                            "ui-text"
                                                                        ],
                                                                        style: function() {
                                                                            return __webpack_require__.g.$translateStyle$({
                                                                                color: "" + node.color,
                                                                                fontSize: "" + node.size + "px",
                                                                                lineHeight: "" + node.lineHeight + "px",
                                                                                fontWeight: "" + node.bold,
                                                                                textAlign: "" + node.align,
                                                                                lines: "" + node.lines
                                                                            });
                                                                        },
                                                                        value: function() {
                                                                            return node.text;
                                                                        }
                                                                    }
                                                                }, [])
                                                            ];
                                                        }),
                                                        aiot.__ci__({
                                                            __vm__: _vm_,
                                                            __opts__: {
                                                                shown: function() {
                                                                    return !("heading" === node.kind || "text" === node.kind) && "button" === node.kind;
                                                                }
                                                            }
                                                        }, function() {
                                                            return [
                                                                aiot.__ce__("div", {
                                                                    __vm__: _vm_,
                                                                    __opts__: {
                                                                        classList: [
                                                                            "ui-button"
                                                                        ],
                                                                        events: {
                                                                            click: function(evt) {
                                                                                return _vm_.onButtonPress(node.id, evt);
                                                                            }
                                                                        }
                                                                    }
                                                                }, [
                                                                    aiot.__ce__("text", {
                                                                        __vm__: _vm_,
                                                                        __opts__: {
                                                                            classList: [
                                                                                "ui-text"
                                                                            ],
                                                                            style: function() {
                                                                                return __webpack_require__.g.$translateStyle$({
                                                                                    color: "" + node.color,
                                                                                    fontSize: "" + node.size + "px",
                                                                                    lineHeight: "" + node.lineHeight + "px",
                                                                                    lines: "" + node.lines,
                                                                                    fontWeight: "bold",
                                                                                    textAlign: "center"
                                                                                });
                                                                            },
                                                                            value: function() {
                                                                                return node.text;
                                                                            }
                                                                        }
                                                                    }, [])
                                                                ])
                                                            ];
                                                        }),
                                                        aiot.__ci__({
                                                            __vm__: _vm_,
                                                            __opts__: {
                                                                shown: function() {
                                                                    return "button" !== node.kind && !("heading" === node.kind || "text" === node.kind) && "switch" === node.kind;
                                                                }
                                                            }
                                                        }, function() {
                                                            return [
                                                                aiot.__ce__("div", {
                                                                    __vm__: _vm_,
                                                                    __opts__: {
                                                                        classList: [
                                                                            "control-card"
                                                                        ]
                                                                    }
                                                                }, [
                                                                    aiot.__ce__("div", {
                                                                        __vm__: _vm_,
                                                                        __opts__: {
                                                                            classList: [
                                                                                "control-copy"
                                                                            ],
                                                                            style: function() {
                                                                                return __webpack_require__.g.$translateStyle$({
                                                                                    width: "" + node.copyWidth + "px"
                                                                                });
                                                                            }
                                                                        }
                                                                    }, [
                                                                        aiot.__ce__("text", {
                                                                            __vm__: _vm_,
                                                                            __opts__: {
                                                                                classList: [
                                                                                    "control-label"
                                                                                ],
                                                                                style: function() {
                                                                                    return __webpack_require__.g.$translateStyle$({
                                                                                        color: "" + node.color
                                                                                    });
                                                                                },
                                                                                value: function() {
                                                                                    return node.text;
                                                                                }
                                                                            }
                                                                        }, []),
                                                                        aiot.__ci__({
                                                                            __vm__: _vm_,
                                                                            __opts__: {
                                                                                shown: function() {
                                                                                    return node.detail;
                                                                                }
                                                                            }
                                                                        }, function() {
                                                                            return [
                                                                                aiot.__ce__("text", {
                                                                                    __vm__: _vm_,
                                                                                    __opts__: {
                                                                                        classList: [
                                                                                            "control-detail"
                                                                                        ],
                                                                                        style: function() {
                                                                                            return __webpack_require__.g.$translateStyle$({
                                                                                                color: "" + node.detailColor
                                                                                            });
                                                                                        },
                                                                                        value: function() {
                                                                                            return node.detail;
                                                                                        }
                                                                                    }
                                                                                }, [])
                                                                            ];
                                                                        })
                                                                    ]),
                                                                    aiot.__ce__("switch", {
                                                                        __vm__: _vm_,
                                                                        __opts__: {
                                                                            classList: [
                                                                                "ui-switch"
                                                                            ],
                                                                            checked: function() {
                                                                                return node.checked;
                                                                            },
                                                                            style: function() {
                                                                                return __webpack_require__.g.$translateStyle$({
                                                                                    trackColor: "" + node.accent,
                                                                                    thumbColor: "" + node.thumbColor
                                                                                });
                                                                            },
                                                                            events: {
                                                                                change: function(evt) {
                                                                                    return _vm_.onSwitchChange(node.id, evt);
                                                                                }
                                                                            }
                                                                        }
                                                                    }, [])
                                                                ])
                                                            ];
                                                        }),
                                                        aiot.__ci__({
                                                            __vm__: _vm_,
                                                            __opts__: {
                                                                shown: function() {
                                                                    return "switch" !== node.kind && "button" !== node.kind && !("heading" === node.kind || "text" === node.kind) && "slider" === node.kind;
                                                                }
                                                            }
                                                        }, function() {
                                                            return [
                                                                aiot.__ce__("div", {
                                                                    __vm__: _vm_,
                                                                    __opts__: {
                                                                        classList: [
                                                                            "value-card"
                                                                        ]
                                                                    }
                                                                }, [
                                                                    aiot.__ce__("div", {
                                                                        __vm__: _vm_,
                                                                        __opts__: {
                                                                            classList: [
                                                                                "value-header"
                                                                            ]
                                                                        }
                                                                    }, [
                                                                        aiot.__ce__("text", {
                                                                            __vm__: _vm_,
                                                                            __opts__: {
                                                                                classList: [
                                                                                    "value-label"
                                                                                ],
                                                                                style: function() {
                                                                                    return __webpack_require__.g.$translateStyle$({
                                                                                        color: "" + node.color
                                                                                    });
                                                                                },
                                                                                value: function() {
                                                                                    return node.text;
                                                                                }
                                                                            }
                                                                        }, []),
                                                                        aiot.__ce__("text", {
                                                                            __vm__: _vm_,
                                                                            __opts__: {
                                                                                classList: [
                                                                                    "value-text"
                                                                                ],
                                                                                style: function() {
                                                                                    return __webpack_require__.g.$translateStyle$({
                                                                                        color: "" + node.accent
                                                                                    });
                                                                                },
                                                                                value: function() {
                                                                                    return node.value;
                                                                                }
                                                                            }
                                                                        }, [])
                                                                    ]),
                                                                    aiot.__ce__("slider", {
                                                                        __vm__: _vm_,
                                                                        __opts__: {
                                                                            classList: [
                                                                                "ui-slider"
                                                                            ],
                                                                            min: function() {
                                                                                return node.min;
                                                                            },
                                                                            max: function() {
                                                                                return node.max;
                                                                            },
                                                                            step: function() {
                                                                                return node.step;
                                                                            },
                                                                            value: function() {
                                                                                return node.value;
                                                                            },
                                                                            style: function() {
                                                                                return __webpack_require__.g.$translateStyle$({
                                                                                    color: "" + node.trackColor,
                                                                                    selectedColor: "" + node.accent,
                                                                                    blockColor: "" + node.thumbColor
                                                                                });
                                                                            },
                                                                            events: {
                                                                                change: function(evt) {
                                                                                    return _vm_.onSliderChange(node.id, evt);
                                                                                }
                                                                            }
                                                                        }
                                                                    }, [])
                                                                ])
                                                            ];
                                                        }),
                                                        aiot.__ci__({
                                                            __vm__: _vm_,
                                                            __opts__: {
                                                                shown: function() {
                                                                    return "slider" !== node.kind && "switch" !== node.kind && "button" !== node.kind && !("heading" === node.kind || "text" === node.kind) && "progress" === node.kind;
                                                                }
                                                            }
                                                        }, function() {
                                                            return [
                                                                aiot.__ce__("div", {
                                                                    __vm__: _vm_,
                                                                    __opts__: {
                                                                        classList: [
                                                                            "value-card"
                                                                        ]
                                                                    }
                                                                }, [
                                                                    aiot.__ce__("div", {
                                                                        __vm__: _vm_,
                                                                        __opts__: {
                                                                            classList: [
                                                                                "value-header"
                                                                            ]
                                                                        }
                                                                    }, [
                                                                        aiot.__ce__("text", {
                                                                            __vm__: _vm_,
                                                                            __opts__: {
                                                                                classList: [
                                                                                    "value-label"
                                                                                ],
                                                                                style: function() {
                                                                                    return __webpack_require__.g.$translateStyle$({
                                                                                        color: "" + node.color
                                                                                    });
                                                                                },
                                                                                value: function() {
                                                                                    return node.text;
                                                                                }
                                                                            }
                                                                        }, []),
                                                                        aiot.__ce__("text", {
                                                                            __vm__: _vm_,
                                                                            __opts__: {
                                                                                classList: [
                                                                                    "value-text"
                                                                                ],
                                                                                style: function() {
                                                                                    return __webpack_require__.g.$translateStyle$({
                                                                                        color: "" + node.accent
                                                                                    });
                                                                                },
                                                                                value: function() {
                                                                                    return node.percent + "%";
                                                                                }
                                                                            }
                                                                        }, [])
                                                                    ]),
                                                                    aiot.__ce__("progress", {
                                                                        __vm__: _vm_,
                                                                        __opts__: {
                                                                            classList: [
                                                                                "ui-progress"
                                                                            ],
                                                                            percent: function() {
                                                                                return node.percent;
                                                                            },
                                                                            style: function() {
                                                                                return __webpack_require__.g.$translateStyle$({
                                                                                    color: "" + node.accent,
                                                                                    layerColor: "" + node.trackColor
                                                                                });
                                                                            }
                                                                        }
                                                                    }, [])
                                                                ])
                                                            ];
                                                        }),
                                                        aiot.__ci__({
                                                            __vm__: _vm_,
                                                            __opts__: {
                                                                shown: function() {
                                                                    return "progress" !== node.kind && "slider" !== node.kind && "switch" !== node.kind && "button" !== node.kind && !("heading" === node.kind || "text" === node.kind) && "qrcode" === node.kind;
                                                                }
                                                            }
                                                        }, function() {
                                                            return [
                                                                aiot.__ce__("qrcode", {
                                                                    __vm__: _vm_,
                                                                    __opts__: {
                                                                        value: function() {
                                                                            return node.value;
                                                                        },
                                                                        style: function() {
                                                                            return __webpack_require__.g.$translateStyle$({
                                                                                width: "" + node.qrSize + "px",
                                                                                height: "" + node.qrSize + "px",
                                                                                color: "" + node.color,
                                                                                backgroundColor: "" + node.background
                                                                            });
                                                                        }
                                                                    }
                                                                }, [])
                                                            ];
                                                        })
                                                    ])
                                                ];
                                            }),
                                            aiot.__ci__({
                                                __vm__: _vm_,
                                                __opts__: {
                                                    shown: function() {
                                                        return _vm_.error;
                                                    }
                                                }
                                            }, function() {
                                                return [
                                                    aiot.__ce__("div", {
                                                        __vm__: _vm_,
                                                        __opts__: {
                                                            classList: [
                                                                "error-card"
                                                            ],
                                                            style: function() {
                                                                return __webpack_require__.g.$translateStyle$({
                                                                    top: "" + _vm_.errorTop + "px"
                                                                });
                                                            }
                                                        }
                                                    }, [
                                                        aiot.__ce__("text", {
                                                            __vm__: _vm_,
                                                            __opts__: {
                                                                classList: [
                                                                    "error-title"
                                                                ],
                                                                value: "运行错误"
                                                            }
                                                        }, []),
                                                        aiot.__ce__("text", {
                                                            __vm__: _vm_,
                                                            __opts__: {
                                                                classList: [
                                                                    "error-text"
                                                                ],
                                                                value: function() {
                                                                    return _vm_.error;
                                                                }
                                                            }
                                                        }, [])
                                                    ])
                                                ];
                                            })
                                        ])
                                    ])
                                ];
                            }),
                            aiot.__ci__({
                                __vm__: _vm_,
                                __opts__: {
                                    shown: function() {
                                        return "console" === _vm_.view;
                                    }
                                }
                            }, function() {
                                return [
                                    aiot.__ce__("scroll", {
                                        __vm__: _vm_,
                                        __opts__: {
                                            classList: [
                                                "console-content"
                                            ],
                                            style: function() {
                                                return __webpack_require__.g.$translateStyle$({
                                                    top: _vm_.showTopBar ? "84px" : "12px",
                                                    height: _vm_.showTopBar ? "396px" : "468px"
                                                });
                                            },
                                            scrollY: "true",
                                            events: {
                                                click: function(evt) {
                                                    return _vm_.restoreUi(evt);
                                                }
                                            }
                                        }
                                    }, [
                                        aiot.__ci__({
                                            __vm__: _vm_,
                                            __opts__: {
                                                shown: function() {
                                                    return _vm_.hasUi;
                                                }
                                            }
                                        }, function() {
                                            return [
                                                aiot.__ce__("text", {
                                                    __vm__: _vm_,
                                                    __opts__: {
                                                        classList: [
                                                            "console-hint"
                                                        ],
                                                        value: "轻点日志返回界面"
                                                    }
                                                }, [])
                                            ];
                                        }),
                                        aiot.__ci__({
                                            __vm__: _vm_,
                                            __opts__: {
                                                shown: function() {
                                                    return !_vm_.logText && !_vm_.error;
                                                }
                                            }
                                        }, function() {
                                            return [
                                                aiot.__ce__("text", {
                                                    __vm__: _vm_,
                                                    __opts__: {
                                                        classList: [
                                                            "console-hint"
                                                        ],
                                                        value: "暂无日志"
                                                    }
                                                }, [])
                                            ];
                                        }),
                                        aiot.__ce__("text", {
                                            __vm__: _vm_,
                                            __opts__: {
                                                classList: [
                                                    "console-log"
                                                ],
                                                value: function() {
                                                    return _vm_.logText;
                                                }
                                            }
                                        }, []),
                                        aiot.__ci__({
                                            __vm__: _vm_,
                                            __opts__: {
                                                shown: function() {
                                                    return _vm_.error;
                                                }
                                            }
                                        }, function() {
                                            return [
                                                aiot.__ce__("text", {
                                                    __vm__: _vm_,
                                                    __opts__: {
                                                        classList: [
                                                            "console-error"
                                                        ],
                                                        value: function() {
                                                            return _vm_.error;
                                                        }
                                                    }
                                                }, [])
                                            ];
                                        })
                                    ])
                                ];
                            }),
                            aiot.__ci__({
                                __vm__: _vm_,
                                __opts__: {
                                    shown: function() {
                                        return _vm_.showTopBar;
                                    }
                                }
                            }, function() {
                                return [
                                    aiot.__ce__("image", {
                                        __vm__: _vm_,
                                        __opts__: {
                                            src: "/common/images/hd.png",
                                            classList: [
                                                "topbar-bg"
                                            ]
                                        }
                                    }, [])
                                ];
                            }),
                            aiot.__ci__({
                                __vm__: _vm_,
                                __opts__: {
                                    shown: function() {
                                        return _vm_.showTopBar;
                                    }
                                }
                            }, function() {
                                return [
                                    aiot.__ce__("text", {
                                        __vm__: _vm_,
                                        __opts__: {
                                            classList: [
                                                "time-text"
                                            ],
                                            value: function() {
                                                return _vm_.nowTime;
                                            }
                                        }
                                    }, [])
                                ];
                            }),
                            aiot.__ci__({
                                __vm__: _vm_,
                                __opts__: {
                                    shown: function() {
                                        return _vm_.showTopBar && _vm_.pageTitle.length <= 5;
                                    }
                                }
                            }, function() {
                                return [
                                    aiot.__ce__("text", {
                                        __vm__: _vm_,
                                        __opts__: {
                                            classList: [
                                                "title-text"
                                            ],
                                            value: function() {
                                                return _vm_.pageTitle;
                                            }
                                        }
                                    }, [])
                                ];
                            }),
                            aiot.__ci__({
                                __vm__: _vm_,
                                __opts__: {
                                    shown: function() {
                                        return _vm_.showTopBar && _vm_.pageTitle.length > 5;
                                    }
                                }
                            }, function() {
                                return [
                                    aiot.__ce__("marquee", {
                                        __vm__: _vm_,
                                        __opts__: {
                                            classList: [
                                                "title-marquee"
                                            ],
                                            scrollamount: "4",
                                            loop: "-1",
                                            value: function() {
                                                return _vm_.pageTitle;
                                            }
                                        }
                                    }, [])
                                ];
                            }),
                            aiot.__ci__({
                                __vm__: _vm_,
                                __opts__: {
                                    shown: function() {
                                        return _vm_.showTopBar;
                                    }
                                }
                            }, function() {
                                return [
                                    aiot.__ce__("image", {
                                        __vm__: _vm_,
                                        __opts__: {
                                            src: "/common/images/back.png",
                                            classList: [
                                                "btn",
                                                "btn-left-top"
                                            ],
                                            events: {
                                                click: function(evt) {
                                                    return _vm_.onBack(evt);
                                                }
                                            }
                                        }
                                    }, [])
                                ];
                            }),
                            aiot.__ci__({
                                __vm__: _vm_,
                                __opts__: {
                                    shown: function() {
                                        return _vm_.showTopBar;
                                    }
                                }
                            }, function() {
                                return [
                                    aiot.__ce__("image", {
                                        __vm__: _vm_,
                                        __opts__: {
                                            src: "/common/images/info.png",
                                            classList: [
                                                "btn",
                                                "btn-right-top"
                                            ],
                                            events: {
                                                click: function(evt) {
                                                    return _vm_.showAbout(evt);
                                                }
                                            }
                                        }
                                    }, [])
                                ];
                            })
                        ]);
                    };
                    $app_exports$['entry'] = function($app_exports$) {
                        $app_script$({}, $app_exports$, $app_require$1);
                        $app_exports$.default.template = $app_template$;
                        $app_exports$.default.style = $app_style$;
                    };
                })();
            })();
        };
        return createPageHandler();
    })(global, globalThis, window, $app_exports$, $app_evaluate$);
}
