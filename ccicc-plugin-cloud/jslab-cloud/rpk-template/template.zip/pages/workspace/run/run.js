export default function(global, globalThis, window, $app_exports$, $app_evaluate$) {
    var org_app_require = $app_require$;
    (function(global, globalThis, window, $app_exports$, $app_evaluate$) {
        var setTimeout = global.setTimeout;
        var setInterval = global.setInterval;
        var clearTimeout = global.clearTimeout;
        var clearInterval = global.clearInterval;
        var $app_require$1 = global.$app_require$ || org_app_require;
        var createPageHandler = function() {
            return (()=>{
                var __webpack_modules__ = {
                    "./src/utils/core/routeManager.js": function(__unused_webpack_module, exports) {
                        "use strict";
                        Object.defineProperty(exports, "__esModule", {
                            value: true
                        });
                        exports.back = back;
                        exports["default"] = void 0;
                        exports.push = push;
                        exports.replace = replace;
                        exports.resolveRoute = resolveRoute;
                        var _system = _interopRequireDefault($app_require$1("@app-module/system.router"));
                        function _interopRequireDefault(e) {
                            return e && e.__esModule ? e : {
                                default: e
                            };
                        }
                        const ROUTES = {
                            index: '/',
                            editor: '/workspace/editor',
                            aiGenerate: '/workspace/ai-generate',
                            run: '/workspace/run',
                            newFile: '/workspace/new',
                            settings: '/settings',
                            settingsEditor: '/settings/editor',
                            settingsFonts: '/settings/editor/fonts',
                            settingsHighlight: '/settings/editor/highlight',
                            settingsAbout: '/settings/about',
                            settingsHelp: '/settings/help',
                            settingsCloud: '/settings/cloud',
                            settingsCloudFiles: '/settings/cloud/files',
                            toolsMarket: '/tools/market',
                            toolsMarketUpload: '/tools/market/upload',
                            toolsMarketView: '/tools/market/view',
                            toolsMoney: '/tools/money',
                            overlayConfirm: '/overlay/confirm',
                            overlaySelect: '/overlay/select',
                            overlayNumberInput: '/overlay/number-input',
                            overlayTextInput: '/overlay/text-input'
                        };
                        function normalizePath(route) {
                            const value = route.trim().replace(/\\/g, '/');
                            if (!value || '/' === value) return '/';
                            if (-1 !== value.indexOf('://')) return value;
                            const path = ('/' === value.charAt(0) ? value : '/' + value).replace(/\/+/g, '/').replace(/\/+$/, '') || '/';
                            if ('/' === path) return ROUTES.index;
                            if (path.split('/').some((segment)=>'..' === segment || '.' === segment)) throw new Error('非法页面路径：' + route);
                            if (!/^\/[A-Za-z0-9_-]+(?:\/[A-Za-z0-9_-]+)*$/.test(path)) throw new Error('页面 slug 只能包含字母、数字、下划线和连字符：' + route);
                            return path;
                        }
                        function resolveRoute(route) {
                            if ('string' != typeof route) return ROUTES.index;
                            const key = route.trim();
                            if (Object.prototype.hasOwnProperty.call(ROUTES, key)) return ROUTES[key];
                            return normalizePath(key);
                        }
                        function push(route, params) {
                            const options = {
                                uri: resolveRoute(route)
                            };
                            if (params) options.params = params;
                            _system.default.push(options);
                        }
                        function back() {
                            _system.default.back();
                        }
                        function replace(route, params) {
                            const options = {
                                uri: resolveRoute(route)
                            };
                            if (params) options.params = params;
                            _system.default.replace(options);
                        }
                        var _default = exports["default"] = {
                            resolveRoute,
                            push,
                            replace,
                            back
                        };
                    },
                    "./src/utils/core/runtimeCompat.js": function(__unused_webpack_module, exports) {
                        "use strict";
                        Object.defineProperty(exports, "__esModule", {
                            value: true
                        });
                        exports.getPageElement = getPageElement;
                        exports.loadOptionalSystemModule = loadOptionalSystemModule;
                        exports.scheduleNextTick = scheduleNextTick;
                        function unavailableError(featureName) {
                            const error = new Error(featureName + ' 在当前设备上不可用');
                            error.code = 203;
                            return error;
                        }
                        function createUnavailableModule(featureName, methodNames) {
                            const module = {
                                __available: false
                            };
                            methodNames.forEach((methodName)=>{
                                module[methodName] = (options)=>{
                                    const error = unavailableError(featureName);
                                    if (options && ('function' == typeof options.fail || 'function' == typeof options.complete)) return void setTimeout(()=>{
                                        try {
                                            if ('function' == typeof options.fail) options.fail(error.message, 203);
                                        } finally{
                                            if ('function' == typeof options.complete) options.complete();
                                        }
                                    }, 0);
                                    throw error;
                                };
                            });
                            return module;
                        }
                        function loadOptionalSystemModule(app, featureName, methodNames, loader) {
                            try {
                                const capabilityName = '@' + featureName;
                                if (app && 'function' == typeof app.canIUse && !app.canIUse(capabilityName)) return createUnavailableModule(featureName, methodNames);
                                return loader();
                            } catch (error) {
                                return createUnavailableModule(featureName, methodNames);
                            }
                        }
                        function scheduleNextTick(context, callback) {
                            if (context && 'function' == typeof context.$nextTick) return void context.$nextTick(callback);
                            setTimeout(callback, 0);
                        }
                        function getPageElement(context, id) {
                            if (!context || 'function' != typeof context.$element) return null;
                            return context.$element(id);
                        }
                    },
                    "./src/utils/core/screen.js": function(__unused_webpack_module, exports) {
                        "use strict";
                        Object.defineProperty(exports, "__esModule", {
                            value: true
                        });
                        exports.SCREEN = void 0;
                        const SCREEN = exports.SCREEN = {
                            id: 'bandpro',
                            width: 336,
                            height: 480,
                            side: 6,
                            contentWidth: 324,
                            header: 84,
                            topInset: 12,
                            bottom: 14,
                            footer: 78,
                            keyboard: 255,
                            codeViewport: 300,
                            codePadding: 12,
                            caretWidth: 280,
                            caretTail: 70
                        };
                    },
                    "./src/utils/core/time.js": function(__unused_webpack_module, exports) {
                        "use strict";
                        Object.defineProperty(exports, "__esModule", {
                            value: true
                        });
                        exports.formatClock = formatClock;
                        exports.getCurrentClock = getCurrentClock;
                        exports.startPageClock = startPageClock;
                        exports.stopPageClock = stopPageClock;
                        function formatClock(date) {
                            const hours = date.getHours();
                            const minutes = date.getMinutes();
                            const hourText = hours < 10 ? '0' + hours : String(hours);
                            const minuteText = minutes < 10 ? '0' + minutes : String(minutes);
                            return hourText + ':' + minuteText;
                        }
                        function getCurrentClock() {
                            return formatClock(new Date());
                        }
                        const pageClocks = new WeakMap();
                        function stopPageClock(page) {
                            if (!pageClocks.has(page)) return;
                            clearTimeout(pageClocks.get(page));
                            pageClocks.delete(page);
                        }
                        function startPageClock(page) {
                            stopPageClock(page);
                            const tick = ()=>{
                                const date = new Date();
                                const value = formatClock(date);
                                if (page.nowTime !== value) page.nowTime = value;
                                pageClocks.set(page, setTimeout(tick, 60000 - (1000 * date.getSeconds() + date.getMilliseconds())));
                            };
                            tick();
                        }
                    },
                    "./src/utils/core/uiFeedback.js": function(__unused_webpack_module, exports) {
                        "use strict";
                        Object.defineProperty(exports, "__esModule", {
                            value: true
                        });
                        exports.showToast = showToast;
                        exports.vibrate = vibrate;
                        var _system = _interopRequireDefault($app_require$1("@app-module/system.prompt"));
                        var _system2 = _interopRequireDefault($app_require$1("@app-module/system.vibrator"));
                        function _interopRequireDefault(e) {
                            return e && e.__esModule ? e : {
                                default: e
                            };
                        }
                        function vibrate(mode) {
                            if (mode) _system2.default.vibrate({
                                mode
                            });
                        }
                        function showToast(message, duration) {
                            const milliseconds = Number(duration);
                            _system.default.showToast({
                                message: String(null == message ? '' : message),
                                duration: isFinite(milliseconds) ? Math.min(10000, Math.max(1500, milliseconds)) : 1500
                            });
                        }
                    },
                    "./src/utils/files/textEncoding.js": function(__unused_webpack_module, exports) {
                        "use strict";
                        Object.defineProperty(exports, "__esModule", {
                            value: true
                        });
                        exports.decodeBase64 = decodeBase64;
                        exports.sliceUtf8Chunk = sliceUtf8Chunk;
                        exports.utf8ByteLength = utf8ByteLength;
                        function utf8Unit(value, index) {
                            const code = value.charCodeAt(index);
                            if (code < 0x80) return {
                                bytes: 1,
                                units: 1
                            };
                            if (code < 0x800) return {
                                bytes: 2,
                                units: 1
                            };
                            if (code >= 0xd800 && code <= 0xdbff && index + 1 < value.length) {
                                const next = value.charCodeAt(index + 1);
                                if (next >= 0xdc00 && next <= 0xdfff) return {
                                    bytes: 4,
                                    units: 2
                                };
                            }
                            return {
                                bytes: 3,
                                units: 1
                            };
                        }
                        function utf8ByteLength(value) {
                            const text = String(null == value ? '' : value);
                            let bytes = 0;
                            for(let index = 0; index < text.length;){
                                const unit = utf8Unit(text, index);
                                bytes += unit.bytes;
                                index += unit.units;
                            }
                            return bytes;
                        }
                        function sliceUtf8Chunk(value, offset, maximumBytes) {
                            const text = String(null == value ? '' : value);
                            const requestedOffset = Number(offset);
                            if (!isFinite(requestedOffset) || requestedOffset < 0 || Math.floor(requestedOffset) !== requestedOffset) throw new Error('读取偏移必须是非负整数字节数');
                            const startOffset = requestedOffset;
                            const requestedLimit = Number(maximumBytes);
                            if (!isFinite(requestedLimit) || Math.floor(requestedLimit) < 1) throw new Error('读取分块大小必须至少为 1 字节');
                            const limit = Math.floor(requestedLimit);
                            const total = utf8ByteLength(text);
                            if (startOffset > total) throw new Error('读取偏移超过文件大小');
                            let index = 0;
                            let bytes = 0;
                            while(index < text.length && bytes < startOffset){
                                const unit = utf8Unit(text, index);
                                if (bytes + unit.bytes > startOffset) throw new Error('读取偏移不是有效的 UTF-8 字符边界');
                                bytes += unit.bytes;
                                index += unit.units;
                            }
                            if (bytes !== startOffset) throw new Error('读取偏移不是有效的 UTF-8 字符边界');
                            const startIndex = index;
                            while(index < text.length){
                                const unit = utf8Unit(text, index);
                                if (bytes - startOffset + unit.bytes > limit) break;
                                bytes += unit.bytes;
                                index += unit.units;
                            }
                            if (index === startIndex && startOffset < total) throw new Error('读取分块大小不足以容纳下一个 UTF-8 字符');
                            return {
                                content: text.slice(startIndex, index),
                                nextOffset: bytes,
                                size: total,
                                done: bytes >= total
                            };
                        }
                        function decodeBase64(value) {
                            const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
                            if ('string' != typeof value || value.length % 4 !== 0) throw new Error('Base64 编码无效');
                            let output = '';
                            for(let index = 0; index < value.length; index += 4){
                                const a = chars.indexOf(value.charAt(index));
                                const b = chars.indexOf(value.charAt(index + 1));
                                const cChar = value.charAt(index + 2);
                                const dChar = value.charAt(index + 3);
                                const c = '=' === cChar ? 0 : chars.indexOf(cChar);
                                const d = '=' === dChar ? 0 : chars.indexOf(dChar);
                                if (a < 0 || b < 0 || c < 0 || d < 0 || '=' === cChar && '=' !== dChar || ('=' === cChar || '=' === dChar) && index + 4 !== value.length || '=' === cChar && (15 & b) !== 0 || '=' === dChar && '=' !== cChar && (3 & c) !== 0) throw new Error('Base64 编码无效');
                                output += String.fromCharCode(a << 2 | b >> 4);
                                if ('=' !== cChar) output += String.fromCharCode((15 & b) << 4 | c >> 2);
                                if ('=' !== dChar) output += String.fromCharCode((3 & c) << 6 | d);
                            }
                            return output;
                        }
                    },
                    "./src/utils/runtime/bitmapCodec.js": function(__unused_webpack_module, exports, __webpack_require__) {
                        "use strict";
                        Object.defineProperty(exports, "__esModule", {
                            value: true
                        });
                        exports.decodeImage = decodeImage;
                        exports.encodePng = encodePng;
                        exports.imageFormat = imageFormat;
                        var _textEncoding = __webpack_require__("./src/utils/files/textEncoding.js");
                        const crcTable = new Uint32Array(256);
                        for(let n = 0; n < 256; n += 1){
                            let value = n;
                            for(let bit = 0; bit < 8; bit += 1)value = 1 & value ? 0xedb88320 ^ value >>> 1 : value >>> 1;
                            crcTable[n] = value >>> 0;
                        }
                        function imageFormat(value) {
                            const format = String(value || '').toLowerCase();
                            if ('png' === format) return 'png';
                            if ('jpg' === format || 'jpeg' === format) return 'jpg';
                            throw new Error('图片 format 目前支持 png、jpg；其他格式可能需要更新 JSLab');
                        }
                        function decodeImage(source, format) {
                            const binary = (0, _textEncoding.decodeBase64)(source);
                            const bytes = new Uint8Array(binary.length);
                            for(let i = 0; i < binary.length; i += 1)bytes[i] = binary.charCodeAt(i);
                            const png = bytes.length >= 24 && 137 === bytes[0] && 80 === bytes[1] && 78 === bytes[2] && 71 === bytes[3] && 13 === bytes[4] && 10 === bytes[5] && 26 === bytes[6] && 10 === bytes[7];
                            const jpg = bytes.length >= 4 && 255 === bytes[0] && 216 === bytes[1] && 255 === bytes[2];
                            if (!('png' === format ? png : jpg)) throw new Error('图片内容与声明的 ' + format + ' 格式不符');
                            return bytes;
                        }
                        function encodePng(width, height, pixels) {
                            const stride = 4 * width + 1;
                            const length = stride * height;
                            const compressedLength = 2 + length + 5 * Math.ceil(length / 65535) + 4;
                            const output = new Uint8Array(57 + compressedLength);
                            output.set([
                                137,
                                80,
                                78,
                                71,
                                13,
                                10,
                                26,
                                10
                            ]);
                            let offset = 8;
                            function u32(value) {
                                output[offset++] = value >>> 24;
                                output[offset++] = value >>> 16;
                                output[offset++] = value >>> 8;
                                output[offset++] = value;
                            }
                            function checksum(crc, start, end) {
                                for(let i = start; i < end; i += 1)crc = crcTable[(crc ^ output[i]) & 255] ^ crc >>> 8;
                                return crc;
                            }
                            function chunk(type, size, write) {
                                u32(size);
                                const start = offset;
                                for(let i = 0; i < 4; i += 1)output[offset++] = type.charCodeAt(i);
                                const crc = write(checksum(0xffffffff, start, offset));
                                u32((0xffffffff ^ crc) >>> 0);
                            }
                            chunk('IHDR', 13, (crc)=>{
                                const start = offset;
                                u32(width);
                                u32(height);
                                output.set([
                                    8,
                                    6,
                                    0,
                                    0,
                                    0
                                ], offset);
                                offset += 5;
                                return checksum(crc, start, offset);
                            });
                            chunk('IDAT', compressedLength, (crc)=>{
                                const start = offset;
                                output[offset++] = 0x78;
                                output[offset++] = 0x01;
                                crc = checksum(crc, start, offset);
                                let position = 0, pixel = 0, rowRemaining = 0, a = 1, b = 0;
                                while(position < length){
                                    const size = Math.min(65535, length - position);
                                    const header = offset;
                                    output[offset++] = position + size === length ? 1 : 0;
                                    output[offset++] = size;
                                    output[offset++] = size >>> 8;
                                    output[offset++] = ~size;
                                    output[offset++] = ~size >>> 8;
                                    crc = checksum(crc, header, offset);
                                    let remaining = size;
                                    while(remaining){
                                        if (!rowRemaining) {
                                            output[offset++] = 0;
                                            crc = crcTable[255 & crc] ^ crc >>> 8;
                                            b += a;
                                            rowRemaining = 4 * width;
                                            position += 1;
                                            remaining -= 1;
                                        }
                                        const count = Math.min(rowRemaining, remaining), end = pixel + count;
                                        for(; pixel < end; pixel += 1){
                                            const value = pixels[pixel];
                                            output[offset++] = value;
                                            a += value;
                                            b += a;
                                            crc = crcTable[(crc ^ value) & 255] ^ crc >>> 8;
                                        }
                                        rowRemaining -= count;
                                        position += count;
                                        remaining -= count;
                                        a %= 65521;
                                        b %= 65521;
                                    }
                                }
                                const tail = offset;
                                u32((b << 16 | a) >>> 0);
                                return checksum(crc, tail, offset);
                            });
                            chunk('IEND', 0, (crc)=>crc);
                            return output;
                        }
                    },
                    "./src/utils/runtime/canvasSurface.js": function(__unused_webpack_module, exports) {
                        "use strict";
                        Object.defineProperty(exports, "__esModule", {
                            value: true
                        });
                        exports.createCanvasSurface = createCanvasSurface;
                        function coordinate(value, name) {
                            if ('number' != typeof value || !isFinite(value)) throw new Error('Canvas ' + name + ' 必须是有限数值');
                            return Math.round(value);
                        }
                        function createCanvasSurface(options, services) {
                            const separate = void 0 !== options.pixelWidth || void 0 !== options.pixelHeight;
                            const widthKey = separate ? 'pixelWidth' : 'width', heightKey = separate ? 'pixelHeight' : 'height';
                            const width = coordinate(options[widthKey], widthKey), height = coordinate(options[heightKey], heightKey);
                            if (width < 1 || height < 1 || width !== options[widthKey] || height !== options[heightKey]) throw new Error('Canvas ' + widthKey + '、' + heightKey + ' 必须是正整数');
                            const state = {
                                width,
                                height,
                                pixels: new Uint8Array(width * height * 4),
                                revision: 0,
                                submitted: -1,
                                src: '',
                                pending: new Map(),
                                sequence: 0,
                                committed: 0
                            };
                            const canvas = Object.assign({}, options, {
                                kind: 'canvas',
                                pixelWidth: width,
                                pixelHeight: height
                            });
                            let uniformColor = 0, uniformRevision = 0;
                            function check(readOnly) {
                                services.check(readOnly);
                            }
                            function rgba(value) {
                                const normalized = services.color(value, '');
                                if (!normalized) throw new Error('Canvas 颜色无效：' + value);
                                if ('#' === normalized[0]) return [
                                    parseInt(normalized.slice(1, 3), 16),
                                    parseInt(normalized.slice(3, 5), 16),
                                    parseInt(normalized.slice(5, 7), 16),
                                    255
                                ];
                                const parts = normalized.slice(normalized.indexOf('(') + 1, -1).split(',').map(Number);
                                return [
                                    parts[0],
                                    parts[1],
                                    parts[2],
                                    4 === parts.length ? Math.round(255 * parts[3]) : 255
                                ];
                            }
                            function pixelColor(value) {
                                if (!Array.isArray(value)) return rgba(value);
                                if (4 !== value.length) throw new Error('Canvas RGBA 数组必须包含 4 个通道');
                                for(let i = 0; i < 4; i += 1)if (!Number.isInteger(value[i]) || value[i] < 0 || value[i] > 255) throw new Error('Canvas RGBA 通道必须是 0–255 的整数');
                                return value;
                            }
                            function paint(x, y, value, blend) {
                                if (x < 0 || y < 0 || x >= width || y >= height) return;
                                const index = (y * width + x) * 4, pixels = state.pixels;
                                let red = value[0], green = value[1], blue = value[2], alpha = value[3];
                                if (blend && alpha < 255) {
                                    const sourceAlpha = alpha / 255, targetAlpha = pixels[index + 3] / 255;
                                    const total = sourceAlpha + targetAlpha * (1 - sourceAlpha);
                                    if (!total) return;
                                    const weight = targetAlpha * (1 - sourceAlpha);
                                    red = Math.round((red * sourceAlpha + pixels[index] * weight) / total);
                                    green = Math.round((green * sourceAlpha + pixels[index + 1] * weight) / total);
                                    blue = Math.round((blue * sourceAlpha + pixels[index + 2] * weight) / total);
                                    alpha = Math.round(255 * total);
                                }
                                if (pixels[index] === red && pixels[index + 1] === green && pixels[index + 2] === blue && pixels[index + 3] === alpha) return;
                                pixels[index] = red;
                                pixels[index + 1] = green;
                                pixels[index + 2] = blue;
                                pixels[index + 3] = alpha;
                                state.revision += 1;
                            }
                            function style(value) {
                                const opts = value || {};
                                const lineWidth = void 0 === opts.lineWidth ? 1 : coordinate(opts.lineWidth, 'lineWidth');
                                if (lineWidth < 1) throw new Error('Canvas lineWidth 必须大于 0');
                                return {
                                    color: rgba(void 0 === opts.color ? '#ffffff' : opts.color),
                                    fill: false !== opts.fill,
                                    lineWidth
                                };
                            }
                            function region(left, top, right, bottom, color, contains) {
                                for(let y = Math.max(0, Math.ceil(top)); y <= Math.min(height - 1, Math.floor(bottom)); y += 1){
                                    for(let x = Math.max(0, Math.ceil(left)); x <= Math.min(width - 1, Math.floor(right)); x += 1)if (!contains || contains(x, y)) paint(x, y, color, true);
                                }
                            }
                            const methods = {
                                clear (value) {
                                    check();
                                    const color = void 0 === value ? [
                                        0,
                                        0,
                                        0,
                                        0
                                    ] : rgba(value);
                                    const packed = new Uint32Array(new Uint8Array(color).buffer)[0];
                                    if (uniformRevision === state.revision && uniformColor === packed) return;
                                    const pixels = new Uint32Array(state.pixels.buffer);
                                    for(let i = 0; i < pixels.length; i += 1)if (pixels[i] !== packed) {
                                        pixels.fill(packed);
                                        state.revision += 1;
                                        break;
                                    }
                                    uniformColor = packed;
                                    uniformRevision = state.revision;
                                },
                                setPixel (x, y, value) {
                                    check();
                                    paint(coordinate(x, 'x'), coordinate(y, 'y'), pixelColor(value), false);
                                },
                                getPixel (x, y) {
                                    check(true);
                                    x = coordinate(x, 'x');
                                    y = coordinate(y, 'y');
                                    if (x < 0 || y < 0 || x >= width || y >= height) throw new Error('Canvas 读取像素坐标超出画布');
                                    const index = (y * width + x) * 4;
                                    return [
                                        state.pixels[index],
                                        state.pixels[index + 1],
                                        state.pixels[index + 2],
                                        state.pixels[index + 3]
                                    ];
                                },
                                line (x1, y1, x2, y2, options) {
                                    check();
                                    x1 = coordinate(x1, 'x1');
                                    y1 = coordinate(y1, 'y1');
                                    x2 = coordinate(x2, 'x2');
                                    y2 = coordinate(y2, 'y2');
                                    const settings = style(options), radius = settings.lineWidth / 2;
                                    if (settings.lineWidth % 2 === 0) {
                                        x1 += 0.5;
                                        y1 += 0.5;
                                        x2 += 0.5;
                                        y2 += 0.5;
                                    }
                                    const dx = x2 - x1, dy = y2 - y1, length = dx * dx + dy * dy;
                                    const horizontal = Math.abs(dx) >= Math.abs(dy);
                                    const major1 = horizontal ? x1 : y1, major2 = horizontal ? x2 : y2;
                                    const minor1 = horizontal ? y1 : x1, minor2 = horizontal ? y2 : x2;
                                    const majorDelta = horizontal ? dx : dy, minorDelta = horizontal ? dy : dx;
                                    const start = Math.max(0, Math.ceil(Math.min(major1, major2) - radius));
                                    const end = Math.min((horizontal ? width : height) - 1, Math.floor(Math.max(major1, major2) + radius));
                                    const low = Math.max(0, Math.ceil(Math.min(minor1, minor2) - radius));
                                    const high = Math.min((horizontal ? height : width) - 1, Math.floor(Math.max(minor1, minor2) + radius));
                                    const spread = length ? radius * Math.sqrt(length) / Math.abs(majorDelta) : radius;
                                    for(let major = start; major <= end; major += 1){
                                        const center = length ? minor1 + (major - major1) * minorDelta / majorDelta : minor1;
                                        const first = Math.max(low, Math.ceil(center - spread) - 1);
                                        const last = Math.min(high, Math.floor(center + spread) + 1);
                                        for(let minor = first; minor <= last; minor += 1){
                                            const x = horizontal ? major : minor, y = horizontal ? minor : major;
                                            const t = length ? Math.max(0, Math.min(1, ((x - x1) * dx + (y - y1) * dy) / length)) : 0;
                                            if (Math.pow(x - x1 - t * dx, 2) + Math.pow(y - y1 - t * dy, 2) <= radius * radius) paint(x, y, settings.color, true);
                                        }
                                    }
                                },
                                rect (x, y, w, h, options) {
                                    check();
                                    x = coordinate(x, 'x');
                                    y = coordinate(y, 'y');
                                    w = coordinate(w, 'width');
                                    h = coordinate(h, 'height');
                                    if (w < 0 || h < 0) throw new Error('Canvas 矩形尺寸不能为负数');
                                    const settings = style(options), edge = settings.lineWidth;
                                    region(x, y, x + w - 1, y + h - 1, settings.color, settings.fill ? null : (px, py)=>px < x + edge || px >= x + w - edge || py < y + edge || py >= y + h - edge);
                                },
                                circle (x, y, radius, options) {
                                    check();
                                    x = coordinate(x, 'x');
                                    y = coordinate(y, 'y');
                                    radius = coordinate(radius, 'radius');
                                    if (radius < 0) throw new Error('Canvas radius 不能为负数');
                                    const settings = style(options), inner = Math.max(0, radius - settings.lineWidth);
                                    region(x - radius, y - radius, x + radius, y + radius, settings.color, (px, py)=>{
                                        const distance = (px - x) * (px - x) + (py - y) * (py - y);
                                        return distance <= radius * radius && (settings.fill || 0 === inner || distance > inner * inner);
                                    });
                                },
                                submit () {
                                    try {
                                        check();
                                        return services.submit(state);
                                    } catch (error) {
                                        return Promise.reject(error);
                                    }
                                }
                            };
                            Object.keys(methods).forEach((key)=>Object.defineProperty(canvas, key, {
                                    value: methods[key],
                                    enumerable: false,
                                    writable: false,
                                    configurable: false
                                }));
                            const fixed = separate ? [
                                'kind',
                                'pixelWidth',
                                'pixelHeight'
                            ] : [
                                'kind',
                                'pixelWidth',
                                'pixelHeight',
                                'width',
                                'height'
                            ];
                            fixed.forEach((key)=>Object.defineProperty(canvas, key, {
                                    value: canvas[key],
                                    enumerable: true,
                                    writable: false,
                                    configurable: false
                                }));
                            return {
                                canvas,
                                state
                            };
                        }
                    },
                    "./src/utils/runtime/consoleBuffer.js": function(__unused_webpack_module, exports, __webpack_require__) {
                        "use strict";
                        Object.defineProperty(exports, "__esModule", {
                            value: true
                        });
                        exports.createConsoleBuffer = createConsoleBuffer;
                        exports.formatError = formatError;
                        var _runtimeContract = __webpack_require__("./src/utils/runtime/runtimeContract.js");
                        function formatError(error) {
                            try {
                                if (error && void 0 !== error.message) {
                                    const message = String(error.message);
                                    const missingUi = /\bui\.([A-Za-z_$][\w$]*)/.exec(message);
                                    const hint = 'TypeError' === error.name && missingUi && /not a function|not callable|undefined/i.test(message) ? 'JSLab 版本可能过老，无法调用 ui.' + missingUi[1] + '。请更新客户端或重新导出独立应用；若已是最新版，请检查接口名称。\n' : '';
                                    return (hint + (error.name ? String(error.name) + ': ' : '') + message).slice(0, 512);
                                }
                                return String(error).slice(0, 512);
                            } catch (_) {
                                return '无法显示错误';
                            }
                        }
                        function preview(value, budget, depth, seen) {
                            if (budget.remaining <= 0) return '';
                            let result;
                            try {
                                if (null === value || 'object' != typeof value) result = 'function' == typeof value ? '[Function]' : String(value);
                                else if (value instanceof Error) result = formatError(value);
                                else if (seen.indexOf(value) >= 0) result = '[Circular]';
                                else if (depth >= 2) result = Array.isArray(value) ? '[Array]' : '[Object]';
                                else {
                                    seen.push(value);
                                    const array = Array.isArray(value), parts = [];
                                    let count = 0;
                                    for(const key in value){
                                        if (!Object.prototype.hasOwnProperty.call(value, key)) continue;
                                        if (count >= 8 || budget.remaining < 8) {
                                            parts.push('…');
                                            break;
                                        }
                                        count += 1;
                                        const label = array ? '' : String(key).slice(0, 40) + ': ';
                                        budget.remaining -= label.length + 2;
                                        let item;
                                        try {
                                            item = value[key];
                                        } catch (_) {
                                            item = '[无法读取]';
                                        }
                                        parts.push(label + preview(item, budget, depth + 1, seen));
                                    }
                                    seen.pop();
                                    return (array ? '[' : '{') + parts.join(', ') + (array ? ']' : '}');
                                }
                            } catch (_) {
                                result = '[无法显示]';
                            }
                            const available = Math.max(0, budget.remaining);
                            const clipped = result.length > available ? result.slice(0, Math.max(0, available - 1)) + '…' : result;
                            budget.remaining -= clipped.length;
                            return clipped;
                        }
                        function createConsoleBuffer(changed) {
                            let entries = [], characters = 0, omitted = 0, active = true;
                            function write(level, args) {
                                if (!active) return;
                                const budget = {
                                    remaining: _runtimeContract.LOG_LIMITS.entryCharacters - 16
                                }, parts = [];
                                for(let i = 0; i < args.length && budget.remaining > 0; i += 1){
                                    parts.push(preview(args[i], budget, 0, []));
                                    budget.remaining -= 1;
                                }
                                const entry = ('log' === level ? '' : '[' + level + '] ') + parts.join(' ');
                                entries.push(entry);
                                characters += entry.length + 1;
                                while(entries.length > _runtimeContract.LOG_LIMITS.entries || characters > _runtimeContract.LOG_LIMITS.characters){
                                    characters -= entries.shift().length + 1;
                                    omitted += 1;
                                }
                                changed();
                            }
                            return {
                                console: {
                                    log (...args) {
                                        write('log', args);
                                    },
                                    info (...args) {
                                        write('info', args);
                                    },
                                    warn (...args) {
                                        write('warn', args);
                                    },
                                    error (...args) {
                                        write('error', args);
                                    },
                                    clear () {
                                        if (!active) return;
                                        entries = [];
                                        characters = 0;
                                        omitted = 0;
                                        changed();
                                    }
                                },
                                read () {
                                    return (omitted ? '已省略 ' + omitted + ' 条较早日志\n' : '') + entries.join('\n');
                                },
                                dispose () {
                                    active = false;
                                    entries = [];
                                    characters = 0;
                                    omitted = 0;
                                }
                            };
                        }
                    },
                    "./src/utils/runtime/runtimeContract.js": function(__unused_webpack_module, exports) {
                        "use strict";
                        Object.defineProperty(exports, "__esModule", {
                            value: true
                        });
                        exports.RUNTIME_CONTRACT = exports.LOG_LIMITS = exports.DIALOG_LIMITS = void 0;
                        const RUNTIME_CONTRACT = exports.RUNTIME_CONTRACT = "jslab-unified-open-ui";
                        const LOG_LIMITS = exports.LOG_LIMITS = {
                            entries: 64,
                            characters: 6144,
                            entryCharacters: 1024
                        };
                        const DIALOG_LIMITS = exports.DIALOG_LIMITS = {
                            textCharacters: 8000,
                            items: 100
                        };
                    },
                    "./src/utils/runtime/scriptDialogApi.js": function(__unused_webpack_module, exports) {
                        "use strict";
                        Object.defineProperty(exports, "__esModule", {
                            value: true
                        });
                        exports.createScriptDialogApi = createScriptDialogApi;
                        exports["default"] = void 0;
                        function createScriptDialogApi(appDefinition, isActive, owner) {
                            const api = {};
                            [
                                'alert',
                                'confirm',
                                'text',
                                'number',
                                'select'
                            ].forEach((type)=>{
                                api[type] = (options)=>{
                                    if (!isActive()) {
                                        const error = new Error('运行页已退出');
                                        error.code = 'DIALOG_INACTIVE';
                                        return Promise.reject(error);
                                    }
                                    return appDefinition.openDialog(type, options, owner);
                                };
                            });
                            return api;
                        }
                        var _default = exports["default"] = {
                            createScriptDialogApi
                        };
                    },
                    "./src/utils/runtime/scriptRuntimeApi.js": function(__unused_webpack_module, exports, __webpack_require__) {
                        "use strict";
                        Object.defineProperty(exports, "__esModule", {
                            value: true
                        });
                        exports.createScriptRuntimeApi = createScriptRuntimeApi;
                        exports["default"] = void 0;
                        var _system = _interopRequireDefault($app_require$1("@app-module/system.app"));
                        var _system2 = _interopRequireDefault($app_require$1("@app-module/system.device"));
                        var _system3 = _interopRequireDefault($app_require$1("@app-module/system.configuration"));
                        var _system4 = _interopRequireDefault($app_require$1("@app-module/system.file"));
                        var _system5 = _interopRequireDefault($app_require$1("@app-module/system.network"));
                        var _system6 = _interopRequireDefault($app_require$1("@app-module/system.brightness"));
                        var _system7 = _interopRequireDefault($app_require$1("@app-module/system.geolocation"));
                        var _system8 = _interopRequireDefault($app_require$1("@app-module/system.vibrator"));
                        var _system9 = _interopRequireDefault($app_require$1("@app-module/system.sensor"));
                        var _system0 = _interopRequireDefault($app_require$1("@app-module/system.fetch"));
                        var _system1 = _interopRequireDefault($app_require$1("@app-module/system.interconnect"));
                        var _system10 = _interopRequireDefault($app_require$1("@app-module/system.uploadtask"));
                        var _system11 = _interopRequireDefault($app_require$1("@app-module/system.request"));
                        var _system12 = _interopRequireDefault($app_require$1("@app-module/system.crypto"));
                        var _scriptDialogApi = __webpack_require__("./src/utils/runtime/scriptDialogApi.js");
                        var _runtimeCompat = __webpack_require__("./src/utils/core/runtimeCompat.js");
                        var _uiFeedback = __webpack_require__("./src/utils/core/uiFeedback.js");
                        function _interopRequireDefault(e) {
                            return e && e.__esModule ? e : {
                                default: e
                            };
                        }
                        const battery = (0, _runtimeCompat.loadOptionalSystemModule)(_system.default, 'system.battery', [
                            'getStatus'
                        ], ()=>$app_require$1("@app-module/system.battery"));
                        const event = (0, _runtimeCompat.loadOptionalSystemModule)(_system.default, 'system.event', [
                            'publish',
                            'subscribe',
                            'unsubscribe'
                        ], ()=>$app_require$1("@app-module/system.event"));
                        const record = (0, _runtimeCompat.loadOptionalSystemModule)(_system.default, 'system.record', [
                            'start',
                            'stop'
                        ], ()=>$app_require$1("@app-module/system.record"));
                        const audio = (0, _runtimeCompat.loadOptionalSystemModule)(_system.default, 'system.audio', [
                            'play',
                            'pause',
                            'stop',
                            'getPlayState'
                        ], ()=>$app_require$1("@app-module/system.audio"));
                        function createScriptRuntimeApi(appDefinition, options) {
                            const name = String(options.name || 'untitled.js');
                            const isActive = options.isActive;
                            const storage = appDefinition.getScriptStorage(name);
                            return {
                                script: {
                                    name,
                                    canUse (capability) {
                                        try {
                                            return !!_system.default.canIUse(capability);
                                        } catch (error) {
                                            return false;
                                        }
                                    },
                                    locale () {
                                        try {
                                            return _system3.default.getLocale();
                                        } catch (error) {
                                            return {
                                                language: '',
                                                countryOrRegion: ''
                                            };
                                        }
                                    },
                                    exit () {
                                        if (isActive()) options.exit();
                                    },
                                    reload () {
                                        if (isActive()) options.reload();
                                    },
                                    toast (message, duration) {
                                        if (!isActive()) return;
                                        (0, _uiFeedback.showToast)(message, duration);
                                    },
                                    data: storage.data,
                                    config: storage.config
                                },
                                dialog: (0, _scriptDialogApi.createScriptDialogApi)(appDefinition, isActive, options.owner),
                                system: {
                                    device: _system2.default,
                                    files: _system4.default,
                                    http: {
                                        request: (options)=>_system0.default.fetch(options)
                                    },
                                    download: {
                                        start: (options)=>_system11.default.download(options),
                                        wait: (options)=>_system11.default.onDownloadComplete(options)
                                    },
                                    upload: {
                                        file: (options)=>_system10.default.uploadFile(options)
                                    },
                                    companion: _system1.default,
                                    network: _system5.default,
                                    display: _system6.default,
                                    battery,
                                    location: _system7.default,
                                    vibration: _system8.default,
                                    events: event,
                                    sensors: _system9.default,
                                    recorder: record,
                                    audio,
                                    crypto: _system12.default
                                }
                            };
                        }
                        var _default = exports["default"] = {
                            createScriptRuntimeApi
                        };
                    },
                    "./src/utils/runtime/uiLayout.js": function(__unused_webpack_module, exports, __webpack_require__) {
                        "use strict";
                        Object.defineProperty(exports, "__esModule", {
                            value: true
                        });
                        exports.UI_PERFORMANCE_GUIDE = void 0;
                        exports.color = color;
                        exports.compileUi = compileUi;
                        exports.getUiWidth = getUiWidth;
                        exports.number = number;
                        exports.sameNode = sameNode;
                        exports.text = text;
                        var _screen = __webpack_require__("./src/utils/core/screen.js");
                        const UI_PERFORMANCE_GUIDE = exports.UI_PERFORMANCE_GUIDE = {
                            declarations: 40,
                            paintedNodes: 160,
                            depth: 4,
                            qrcodes: 2
                        };
                        function getUiWidth() {
                            return _screen.SCREEN.contentWidth;
                        }
                        function number(value, min, max, fallback) {
                            if (null == value) return fallback;
                            const result = Number(value);
                            return isFinite(result) ? Math.min(max, Math.max(min, result)) : fallback;
                        }
                        function text(value) {
                            return String(null == value ? '' : value);
                        }
                        function color(value, fallback) {
                            if (null == value) return fallback;
                            const source = String(value).trim();
                            if (/^#[0-9a-f]{6}$/i.test(source)) return source;
                            if (/^#[0-9a-f]{3}$/i.test(source)) return '#' + source.slice(1).split('').map((c)=>c + c).join('');
                            const match = /^rgb\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})\s*\)$/.exec(source);
                            if (match && match.slice(1).every((part)=>Number(part) <= 255)) return source;
                            const rgba = /^rgba\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(0|1|0?\.\d+)\s*\)$/.exec(source);
                            return rgba && rgba.slice(1, 4).every((part)=>Number(part) <= 255) ? source : fallback;
                        }
                        function widthOf(value, available, fallback) {
                            const percent = 'string' == typeof value && /^(\d+(?:\.\d+)?)%$/.exec(value);
                            return Math.round(percent ? number(Number(percent[1]) * available / 100, 1, available, fallback) : number(value, 1, available, fallback));
                        }
                        function list(value) {
                            return Array.isArray(value) ? value : null == value || false === value ? [] : [
                                value
                            ];
                        }
                        function offset(align, spare) {
                            return 'center' === align ? spare / 2 : 'end' === align ? spare : 0;
                        }
                        function background(raw, fallback) {
                            return color(raw.background, fallback);
                        }
                        const GRID_TONES = {
                            primary: '#1769d2',
                            success: '#16845b',
                            warning: '#a55d16',
                            danger: '#b93838'
                        };
                        const BUTTON_TONES = {
                            primary: '#0d6eff',
                            neutral: '#34373d',
                            danger: '#d94343'
                        };
                        const groupCaches = new WeakMap();
                        const GROUP_INPUTS = [
                            'height',
                            'padding',
                            'gap',
                            'columns',
                            'cellHeight',
                            'align',
                            'justify'
                        ];
                        function primitive(value) {
                            return null === value || 'object' != typeof value && 'function' != typeof value;
                        }
                        function tone(raw, grid) {
                            const colors = grid ? GRID_TONES : BUTTON_TONES;
                            const selected = colors[raw.tone];
                            return background(raw, 'string' == typeof selected ? selected : grid ? '#292c31' : '#0d6eff');
                        }
                        function sameNode(a, b) {
                            if (!a || !b) return false;
                            if (a.text !== b.text || a.background !== b.background) return false;
                            const keys = Object.keys(a);
                            if (keys.length !== Object.keys(b).length) return false;
                            for(let i = 0; i < keys.length; i += 1)if (a[keys[i]] !== b[keys[i]]) return false;
                            return true;
                        }
                        function compileUi(source, top, previous, cache, resolveNode) {
                            const nodes = [];
                            const handlers = Object.create(null);
                            const ids = Object.create(null);
                            let old = null;
                            const nextCache = Object.create(null);
                            const groups = cache && groupCaches.get(cache);
                            const nextGroups = Object.create(null);
                            let count = 0;
                            let placed = [], stablePlacement = true;
                            function previousNode(id) {
                                if (!old) {
                                    old = Object.create(null);
                                    (previous || []).forEach((node)=>{
                                        old[node.id] = node;
                                    });
                                }
                                return old[id];
                            }
                            function identity(raw, path) {
                                const id = null == raw.id ? '$' + path : String(raw.id);
                                if (null != raw.id && (!id || id.length > 56 || '$' === id.charAt(0))) throw new Error('UI id 需为 1–56 字符，不能以 $ 开头');
                                if (ids[id]) throw new Error('UI id 重复：' + id);
                                ids[id] = true;
                                return id;
                            }
                            function measureGridCell(cell, w, h, id) {
                                if (ids[id]) throw new Error('UI id 重复：' + id);
                                ids[id] = true;
                                const entry = cache && cache[id];
                                const cached = entry && entry.grid ? entry : null;
                                const before = cached && cached.input;
                                const value = cell.text;
                                const sizeInput = cell.size;
                                const lineInput = cell.lineHeight;
                                const colorInput = cell.color;
                                const bgInput = cell.background;
                                const toneInput = cell.tone;
                                if (before && cached.availableWidth === w && cached.height === h && value === before.text && sizeInput === before.size && lineInput === before.lineHeight && colorInput === before.color && bgInput === before.background && toneInput === before.tone) {
                                    nextCache[id] = cached;
                                    return cached.box;
                                }
                                const input = {
                                    text: value,
                                    size: sizeInput,
                                    lineHeight: lineInput,
                                    color: colorInput,
                                    background: bgInput,
                                    tone: toneInput
                                };
                                const oldNode = cached && cached.node;
                                const size = before && sizeInput === before.size ? oldNode.size : number(sizeInput, 16, 30, 24);
                                const node = {
                                    id,
                                    kind: 'text',
                                    width: Math.round(w),
                                    background: before && bgInput === before.background && toneInput === before.tone ? oldNode.background : tone(input, true),
                                    radius: 12,
                                    text: before && value === before.text ? oldNode.text : text(value),
                                    color: before && colorInput === before.color ? oldNode.color : color(colorInput, '#ffffff'),
                                    size,
                                    align: 'center',
                                    bold: 'bold',
                                    lineHeight: before && lineInput === before.lineHeight && size === oldNode.size ? oldNode.lineHeight : number(lineInput, size, 64, Math.max(size + 4, 32)),
                                    lines: 1,
                                    x: oldNode && oldNode.x,
                                    y: oldNode && oldNode.y,
                                    height: h
                                };
                                let cacheable = true;
                                for(const key in input)if (null !== input[key] && ('object' == typeof input[key] || 'function' == typeof input[key])) cacheable = false;
                                const box = {
                                    id,
                                    kind: 'text',
                                    w,
                                    h,
                                    node
                                };
                                const next = {
                                    grid: true,
                                    availableWidth: w,
                                    width: w,
                                    height: h,
                                    input: cacheable ? input : null,
                                    node,
                                    box
                                };
                                nextCache[id] = next;
                                return box;
                            }
                            function finishLayout(box, layout) {
                                const { padding, cached, stack } = layout;
                                const positions = cached && cached.positions;
                                let matched = !!positions && positions.length === 4 * box.children.length;
                                for(let i = 0; matched && i < box.children.length; i += 1){
                                    const child = box.children[i], index = 4 * i;
                                    matched = child.id === cached.childIds[i] && child.w === positions[index] && child.h === positions[index + 1] && (!stack || stack[2 * i] + padding === positions[index + 2] && stack[2 * i + 1] + padding === positions[index + 3]);
                                }
                                if (matched) {
                                    box.h = cached.height;
                                    box.positions = positions;
                                } else {
                                    stablePlacement = false;
                                    placeChildren(box, layout);
                                }
                                const geometry = layout.geometry;
                                nextGroups[box.id] = matched && cached.allocation === geometry.allocation ? cached : Object.assign({}, geometry, {
                                    height: box.h,
                                    positions: box.positions,
                                    childIds: box.children.map((child)=>child.id)
                                });
                            }
                            function placeChildren(box, layout) {
                                const { raw, kind, padding, inner, gap, columns, cellHeight, horizontal, children, stack } = layout;
                                let natural = 0, usedWidth = gap * Math.max(0, children.length - 1);
                                if (horizontal) box.children.forEach((child)=>{
                                    natural = Math.max(natural, child.h);
                                    usedWidth += child.w;
                                });
                                else if ('grid' === kind) natural = Math.ceil(children.length / columns) * (cellHeight + gap) - (children.length ? gap : 0);
                                else if ('stack' === kind) box.children.forEach((child, i)=>{
                                    natural = Math.max(natural, child.h + stack[2 * i + 1]);
                                });
                                else box.children.forEach((child, i)=>{
                                    natural += child.h + (i ? gap : 0);
                                });
                                box.h = Math.ceil(Math.max(natural + 2 * padding, number(raw.height, 0, 8192, natural + 2 * padding)));
                                const extra = Math.max(0, box.h - 2 * padding - natural);
                                let cursor = padding + (horizontal || 'column' !== kind ? 0 : offset(raw.justify, extra));
                                const freeX = horizontal ? Math.max(0, inner - usedWidth) : 0;
                                if (horizontal) cursor += offset(raw.justify, freeX);
                                const between = 'between' === raw.justify && children.length > 1 ? (horizontal ? freeX : extra) / (children.length - 1) : 0;
                                box.positions = [];
                                box.children.forEach((child, i)=>{
                                    let x = horizontal ? cursor : padding + offset(raw.align, inner - child.w);
                                    let y = horizontal ? padding + offset(raw.align, box.h - 2 * padding - child.h) : cursor;
                                    if ('grid' === kind) {
                                        x = padding + i % columns * (child.w + gap);
                                        y = padding + Math.floor(i / columns) * (child.h + gap);
                                    }
                                    if ('stack' === kind) {
                                        x = padding + stack[2 * i];
                                        y = padding + stack[2 * i + 1];
                                    }
                                    box.positions.push(child.w, child.h, x, y);
                                    cursor += (horizontal ? child.w : child.h) + gap + between;
                                });
                            }
                            function measure(input, available, path, forcedWidth, generated) {
                                const active = new Set();
                                const frames = [
                                    {
                                        input,
                                        available,
                                        path,
                                        forcedWidth,
                                        generated,
                                        parent: null,
                                        index: 0
                                    }
                                ];
                                let rootBox = null;
                                function attach(frame, box, raw) {
                                    if (frame.parent) frame.parent.children[frame.index] = box;
                                    else rootBox = box;
                                    if (frame.stack) {
                                        frame.stack[2 * frame.index] = number(raw.x, 0, Math.max(0, frame.available - box.w), 0);
                                        frame.stack[2 * frame.index + 1] = number(raw.y, 0, 4096, 0);
                                    }
                                }
                                while(frames.length){
                                    const frame = frames.pop();
                                    if (frame.exit) {
                                        finishLayout(frame.box, frame.layout);
                                        active.delete(frame.raw);
                                        attach(frame, frame.box, frame.raw);
                                        continue;
                                    }
                                    let raw = frame.input && 'object' == typeof frame.input ? frame.input : {
                                        kind: 'text',
                                        text: frame.input
                                    };
                                    if (resolveNode) raw = resolveNode(raw);
                                    if (active.has(raw)) throw new Error('UI 布局不能循环引用');
                                    count += 1;
                                    const id = frame.generated || identity(raw, frame.path);
                                    if (frame.generated) {
                                        if (ids[id]) throw new Error('UI id 重复：' + id);
                                        ids[id] = true;
                                    }
                                    const kind = raw.kind || 'text';
                                    const w = null == frame.forcedWidth ? widthOf(raw.width, frame.available, frame.available) : frame.forcedWidth;
                                    if ('row' !== kind && 'column' !== kind && 'stack' !== kind && 'buttonRow' !== kind && 'grid' !== kind) {
                                        const box = measureLeaf(raw, id, kind, w);
                                        if (box.h !== Math.ceil(box.h)) box.h = Math.ceil(box.h);
                                        if ('spacer' !== kind) placed.push(box);
                                        attach(frame, box, raw);
                                        continue;
                                    }
                                    active.add(raw);
                                    const box = {
                                        id,
                                        kind,
                                        w,
                                        h: 0
                                    };
                                    box.background = background(raw, 'transparent');
                                    box.radius = number(raw.radius, 0, 80, 0);
                                    if ('transparent' !== box.background) placed.push(box);
                                    let cached = groups && groups[id];
                                    if (cached && (cached.kind !== kind || cached.w !== w || !cached.input)) cached = null;
                                    for(let i = 0; cached && i < GROUP_INPUTS.length; i += 1)if (raw[GROUP_INPUTS[i]] !== cached.input[i]) cached = null;
                                    let geometry = cached;
                                    if (!geometry) {
                                        const values = GROUP_INPUTS.map((key)=>raw[key]);
                                        const padding = number(raw.padding, 0, Math.min(48, (w - 1) / 2), 0);
                                        geometry = {
                                            kind,
                                            w,
                                            input: values.every(primitive) ? values : null,
                                            padding,
                                            inner: w - 2 * padding,
                                            gap: number(raw.gap, 0, 48, 'grid' === kind || 'buttonRow' === kind ? 6 : 8),
                                            columns: Math.round(number(raw.columns, 2, 4, 4)),
                                            cellHeight: 'grid' === kind ? Math.ceil(number(raw.cellHeight, 44, 72, 52)) : 0
                                        };
                                    }
                                    const { padding, inner, gap, columns, cellHeight } = geometry;
                                    const children = list('buttonRow' === kind ? raw.buttons : 'grid' === kind ? raw.items : raw.children).filter((child)=>null != child && false !== child);
                                    const cellWidth = (inner - gap * (columns - 1)) / columns;
                                    if ('grid' === kind && children.length && cellWidth < 1) throw new Error('grid 宽度不足：减小 columns、padding 或 gap');
                                    const horizontal = 'row' === kind || 'buttonRow' === kind;
                                    let allocation = geometry.allocation;
                                    if (horizontal) {
                                        let matched = !!allocation && !!allocation.input && allocation.widths.length === children.length;
                                        for(let i = 0; matched && i < children.length; i += 1){
                                            const item = children[i] && 'object' == typeof children[i] ? children[i] : {};
                                            matched = item.width === allocation.input[2 * i] && (null == item.width ? item.flex : void 0) === allocation.input[2 * i + 1];
                                        }
                                        if (!matched) {
                                            let remaining = inner - gap * Math.max(0, children.length - 1), weight = 0;
                                            const widths = [], values = [];
                                            children.forEach((child, i)=>{
                                                const item = child && 'object' == typeof child ? child : {};
                                                values.push(item.width, null == item.width ? item.flex : void 0);
                                                if (null != item.width) {
                                                    widths[i] = widthOf(item.width, inner, inner);
                                                    remaining -= widths[i];
                                                } else {
                                                    widths[i] = null;
                                                    weight += number(item.flex, 0.1, 100, 1);
                                                }
                                            });
                                            if (remaining < 0) throw new Error('row 宽度不足：减小 width、padding 或 gap');
                                            children.forEach((child, i)=>{
                                                if (null == widths[i]) widths[i] = remaining * number(child && child.flex, 0.1, 100, 1) / weight;
                                                if (widths[i] < 1) throw new Error('row 子项宽度不足：调整 flex、width、padding 或 gap');
                                            });
                                            allocation = {
                                                widths,
                                                input: values.every(primitive) ? values : null
                                            };
                                            geometry = Object.assign({}, geometry, {
                                                allocation
                                            });
                                        }
                                    }
                                    box.children = new Array(children.length);
                                    const stack = 'stack' === kind ? [] : null;
                                    const layout = {
                                        raw,
                                        kind,
                                        padding,
                                        inner,
                                        gap,
                                        columns,
                                        cellHeight,
                                        horizontal,
                                        children,
                                        cached,
                                        geometry,
                                        stack
                                    };
                                    frames.push({
                                        exit: true,
                                        box,
                                        layout,
                                        raw,
                                        parent: frame.parent,
                                        index: frame.index,
                                        available: frame.available,
                                        stack: frame.stack
                                    });
                                    if ('grid' === kind) {
                                        children.forEach((child, i)=>{
                                            const cell = child && 'object' == typeof child ? child : {
                                                text: child
                                            };
                                            box.children[i] = measureGridCell(cell, cellWidth, cellHeight, id + '/cell/' + i);
                                            placed.push(box.children[i]);
                                        });
                                        continue;
                                    }
                                    for(let i = children.length - 1; i >= 0; i -= 1){
                                        const child = children[i];
                                        let item = child;
                                        let childWidth;
                                        let generatedId;
                                        if (horizontal) childWidth = allocation.widths[i];
                                        if ('buttonRow' === kind) {
                                            const button = child && 'object' == typeof child ? child : {
                                                text: child
                                            };
                                            item = Object.assign({}, button, {
                                                kind: 'button',
                                                text: text(button.text),
                                                height: 60
                                            });
                                            if (null == button.id) generatedId = id + '/button/' + i;
                                        }
                                        const childPath = frame.path.length < 48 ? frame.path + '.' + i : '#' + count + '.' + i;
                                        frames.push({
                                            input: item,
                                            available: inner,
                                            path: childPath,
                                            forcedWidth: childWidth,
                                            generated: generatedId,
                                            parent: box,
                                            index: i,
                                            stack
                                        });
                                    }
                                }
                                return rootBox;
                            }
                            function measureLeaf(raw, id, kind, w) {
                                if ('spacer' === kind) return {
                                    id,
                                    kind,
                                    w,
                                    h: number(raw.size, 0, 480, 12)
                                };
                                if ('button' === kind && true !== raw.disabled && 'function' == typeof raw.onPress) handlers[id] = raw.onPress;
                                if (('switch' === kind || 'slider' === kind) && 'function' == typeof raw.onChange) handlers[id] = raw.onChange;
                                const cached = cache && cache[id];
                                let matched = !!cached && !cached.grid && null !== cached.input && cached.availableWidth === w;
                                let keyCount = 0;
                                for(const key in raw)if ('onPress' !== key && 'onChange' !== key) {
                                    keyCount += 1;
                                    if (matched && raw[key] !== cached.input[key]) matched = false;
                                }
                                if (matched && keyCount === cached.keyCount) {
                                    nextCache[id] = cached;
                                    return cached.box;
                                }
                                let inputCopy = {};
                                for(const key in raw){
                                    if ('onPress' === key || 'onChange' === key) continue;
                                    const value = raw[key];
                                    if (null !== value && ('object' == typeof value || 'function' == typeof value)) {
                                        inputCopy = null;
                                        break;
                                    }
                                    inputCopy[key] = value;
                                }
                                const node = {
                                    id,
                                    kind,
                                    width: Math.round(w),
                                    background: background(raw, 'transparent'),
                                    radius: number(raw.radius, 0, 80, 0)
                                };
                                const box = {
                                    id,
                                    kind,
                                    w,
                                    h: 0,
                                    node
                                };
                                nextCache[id] = {
                                    availableWidth: w,
                                    input: inputCopy,
                                    keyCount,
                                    node,
                                    box
                                };
                                if ('divider' === kind) {
                                    box.h = number(raw.height, 1, 32, 2);
                                    node.background = color(raw.color, '#34373d');
                                    return box;
                                }
                                if ('image' === kind || 'canvas' === kind) {
                                    node.src = text(raw.src);
                                    node.fit = void 0 === raw.fit ? 'contain' : raw.fit;
                                    if ([
                                        'contain',
                                        'cover',
                                        'none',
                                        'scale-down'
                                    ].indexOf(node.fit) < 0) throw new Error('图片 fit 无效：' + node.fit);
                                    const naturalHeight = 'canvas' === kind ? w * raw.pixelHeight / raw.pixelWidth : w;
                                    box.h = number(raw.height, 1, 8192, naturalHeight);
                                    return box;
                                }
                                if ('qrcode' === kind) {
                                    const value = String(null == raw.value ? '' : raw.value);
                                    if (!value) throw new Error('二维码内容不能为空');
                                    if (w < 96) throw new Error('二维码需要至少 96px 宽度');
                                    box.w = Math.min(w, number(raw.size, 96, 288, 160));
                                    box.h = box.w;
                                    node.width = Math.round(box.w);
                                    node.value = value;
                                    node.color = color(raw.color, '#000000');
                                    node.background = background(raw, '#ffffff');
                                    node.qrSize = Math.max(80, Math.round(box.w - 16));
                                    return box;
                                }
                                if (-1 === [
                                    'heading',
                                    'text',
                                    'button',
                                    'switch',
                                    'slider',
                                    'progress'
                                ].indexOf(kind)) throw new Error('JSLab 版本可能过老，无法识别 UI 组件：' + kind + '。请更新客户端或重新导出独立应用；若已是最新版，请检查组件名称。');
                                node.text = text(raw.text);
                                node.color = color(raw.color, '#ffffff');
                                node.size = number(raw.size, 16, 36, 'heading' === kind ? 30 : 24);
                                node.align = [
                                    'left',
                                    'center',
                                    'right'
                                ].indexOf(raw.align) < 0 ? 'left' : raw.align;
                                node.bold = 'heading' === kind || 'button' === kind || true === raw.bold ? 'bold' : 'normal';
                                node.lineHeight = number(raw.lineHeight, node.size, 64, Math.max(node.size + 4, 'heading' === kind ? 40 : 32));
                                const before = cached ? cached.node : previousNode(id);
                                node.lines = Math.round(number(raw.lines, 1, 64, 0));
                                if (!node.lines) {
                                    if (before && before.kind === kind && before.text === node.text && before.width === node.width && before.size === node.size) node.lines = before.autoLines;
                                    if (!node.lines) {
                                        const perLine = Math.max(1, Math.floor((node.width - ('button' === kind ? 16 : 0)) / node.size));
                                        node.lines = node.text.split('\n').reduce((sum, line)=>sum + Math.max(1, Math.ceil(line.length / perLine)), 0);
                                    }
                                    node.autoLines = node.lines;
                                }
                                box.h = number(raw.height, 1, 8192, node.lineHeight * node.lines);
                                if ('button' === kind) {
                                    box.h = Math.max(48, number(raw.height, 48, 480, Math.max(64, node.lineHeight * node.lines + 16)));
                                    node.disabled = true === raw.disabled;
                                    node.background = node.disabled ? '#34373d' : tone(raw, false);
                                    if (node.disabled) node.color = '#999999';
                                    node.radius = number(raw.radius, 0, 80, 32);
                                }
                                if ('switch' === kind || 'slider' === kind || 'progress' === kind) {
                                    if (w < 160) throw new Error(kind + ' 需要至少 160px 宽度');
                                    node.background = background(raw, '#24262a');
                                    node.radius = number(raw.radius, 0, 80, 32);
                                    node.accent = color(raw.accent, 'progress' === kind ? color(raw.color, '#0d6eff') : '#0d6eff');
                                    node.trackColor = color(raw.trackColor, '#3b3e44');
                                    node.thumbColor = color(raw.thumbColor, '#ffffff');
                                    node.detail = text(raw.detail);
                                    node.detailColor = color(raw.detailColor, '#999999');
                                    node.copyWidth = Math.max(40, w - 110);
                                    node.checked = !!raw.checked;
                                    node.min = number(raw.min, -100000, 100000, 0);
                                    node.max = Math.max(node.min, number(raw.max, -100000, 100000, 100));
                                    node.step = number(raw.step, 0.01, 100000, 1);
                                    node.value = number(raw.value, node.min, node.max, node.min);
                                    node.percent = Math.round(number(raw.percent, 0, 100, 0));
                                    box.h = number(raw.height, 'switch' === kind && node.detail ? 94 : 80, 480, 'slider' === kind ? 100 : 'progress' === kind ? 90 : node.detail ? 94 : 80);
                                }
                                return box;
                            }
                            function emit(root, left, topPosition) {
                                const frames = [
                                    {
                                        box: root,
                                        left,
                                        topPosition
                                    }
                                ];
                                while(frames.length){
                                    const frame = frames.pop();
                                    const box = frame.box;
                                    const x = Math.round(frame.left);
                                    const y = Math.round(frame.topPosition);
                                    if (box.children) {
                                        const geometry = nextGroups[box.id];
                                        if (geometry.left !== frame.left || geometry.top !== frame.topPosition) nextGroups[box.id] = Object.assign({}, geometry, {
                                            left: frame.left,
                                            top: frame.topPosition
                                        });
                                        if ('transparent' !== box.background) paint(box, x, y);
                                        for(let i = box.children.length - 1; i >= 0; i -= 1){
                                            const child = box.children[i];
                                            frames.push({
                                                box: child,
                                                left: frame.left + box.positions[4 * i + 2],
                                                topPosition: frame.topPosition + box.positions[4 * i + 3]
                                            });
                                        }
                                    } else if ('spacer' !== box.kind) paint(box, x, y);
                                }
                            }
                            function paint(box, x, y) {
                                if (box.children) add({
                                    id: box.id,
                                    kind: 'background',
                                    x,
                                    y,
                                    width: Math.round(box.w),
                                    height: box.h,
                                    background: box.background,
                                    radius: box.radius
                                });
                                else {
                                    let node = box.node;
                                    if (node.x !== x || node.y !== y || node.height !== box.h) {
                                        if (cache && cache[box.id] && node === cache[box.id].node) node = Object.assign({}, node);
                                        node.x = x;
                                        node.y = y;
                                        node.height = box.h;
                                    }
                                    const paintedNode = add(node);
                                    const cached = nextCache[box.id];
                                    if (cached && (cached.width !== box.w || cached.height !== box.h || cached.node !== paintedNode)) {
                                        const entry = cache && cached === cache[box.id] ? Object.assign({}, cached) : cached;
                                        entry.width = box.w;
                                        entry.height = box.h;
                                        entry.node = paintedNode;
                                        entry.box = box.node === paintedNode ? box : Object.assign({}, box, {
                                            node: paintedNode
                                        });
                                        nextCache[box.id] = entry;
                                    }
                                }
                            }
                            function add(node) {
                                const aligned = previous && previous[nodes.length];
                                const before = aligned && aligned.id === node.id ? aligned : previousNode(node.id);
                                const result = before === node || sameNode(before, node) ? before : node;
                                nodes.push(result);
                                return result;
                            }
                            const roots = list(source);
                            let y = top;
                            roots.forEach((raw, i)=>{
                                if (null == raw || false === raw) return;
                                placed = [];
                                stablePlacement = true;
                                const box = measure(raw, _screen.SCREEN.contentWidth, String(i));
                                const before = box.children ? groups && groups[box.id] : cache && cache[box.id];
                                const sameOrigin = before && (box.children ? before.left === _screen.SCREEN.side && before.top === y : before.width === box.w && before.height === box.h && before.node.x === _screen.SCREEN.side && before.node.y === Math.round(y));
                                if (stablePlacement && sameOrigin) placed.forEach((item)=>{
                                    const entry = item.children ? groups[item.id] : cache[item.id];
                                    if (!item.children && item.node === entry.node && previous && previous[nodes.length] === item.node) nodes.push(item.node);
                                    else paint(item, item.children ? Math.round(entry.left) : entry.node.x, item.children ? Math.round(entry.top) : entry.node.y);
                                });
                                else emit(box, _screen.SCREEN.side, y);
                                y += box.h + 10;
                            });
                            groupCaches.set(nextCache, nextGroups);
                            return {
                                nodes,
                                handlers,
                                height: Math.max(_screen.SCREEN.height, Math.ceil(y + _screen.SCREEN.bottom)),
                                end: y,
                                count,
                                cache: nextCache
                            };
                        }
                    },
                    "./src/utils/runtime/uiMedia.js": function(__unused_webpack_module, exports, __webpack_require__) {
                        "use strict";
                        Object.defineProperty(exports, "__esModule", {
                            value: true
                        });
                        exports.createUiMedia = createUiMedia;
                        var _bitmapCodec = __webpack_require__("./src/utils/runtime/bitmapCodec.js");
                        var _canvasSurface = __webpack_require__("./src/utils/runtime/canvasSurface.js");
                        function createUiMedia(host) {
                            let active = true, sequence = 0;
                            const prefix = 'internal://cache/jslab-ui-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2) + '-';
                            const owned = new Map(), images = new Map(), canvases = new Map(), frames = new Map();
                            let sources = new Map(), nextSources = new Map();
                            let requested = new Set();
                            function check(readOnly) {
                                if (!active) throw new Error('当前脚本已退出，不能再操作画布');
                                if (!readOnly && host.rendering()) throw new Error('不要在 UI 渲染函数中创建或修改画布，请在渲染函数外操作');
                            }
                            function remove(uri) {
                                const resource = owned.get(uri);
                                if (!resource || resource.deleting) return;
                                resource.deleting = true;
                                const fail = (message, code)=>{
                                    resource.deleting = false;
                                    if (active && 301 !== code && !resource.warned) {
                                        resource.warned = true;
                                        host.error(new Error('清理图片缓存失败（' + code + '）：' + message));
                                    }
                                };
                                try {
                                    host.files.delete({
                                        uri,
                                        success: ()=>owned.delete(uri),
                                        fail
                                    });
                                } catch (error) {
                                    fail(error.message);
                                }
                            }
                            function collect() {
                                const keep = new Set();
                                canvases.forEach((state)=>keep.add(state.src));
                                images.forEach((entry)=>keep.add(entry.src));
                                frames.forEach((frame)=>{
                                    keep.add(frame.src);
                                    keep.add(frame.retired);
                                });
                                owned.forEach((entry, uri)=>{
                                    if (!entry.writing && !keep.has(uri)) remove(uri);
                                });
                            }
                            function ready(uri) {
                                const entry = owned.get(uri);
                                if (entry) entry.writing = false;
                            }
                            function write(buffer, format) {
                                return Promise.resolve(host.mediaReady).then(()=>new Promise((resolve, reject)=>{
                                        if (!active) return void reject(new Error('当前脚本已退出'));
                                        if (!host.files || 'function' != typeof host.files.writeArrayBuffer || 'function' != typeof host.files.delete) return void reject(new Error('当前设备无法写入图片缓存'));
                                        const uri = prefix + ++sequence + '.' + format;
                                        owned.set(uri, {
                                            writing: true,
                                            deleting: false
                                        });
                                        const fail = (message, code)=>{
                                            ready(uri);
                                            remove(uri);
                                            reject(new Error('写入图片失败' + (void 0 === code ? '' : '（' + code + '）') + '：' + message));
                                        };
                                        try {
                                            host.files.writeArrayBuffer({
                                                uri,
                                                buffer,
                                                append: false,
                                                success: ()=>{
                                                    if (active) resolve(uri);
                                                    else {
                                                        ready(uri);
                                                        remove(uri);
                                                        reject(new Error('当前脚本已退出'));
                                                    }
                                                },
                                                fail
                                            });
                                        } catch (error) {
                                            fail(error.message);
                                        }
                                    }));
                            }
                            function submit(state) {
                                const revision = state.revision;
                                if (state.pending.has(revision)) return state.pending.get(revision);
                                if (state.submitted === revision) return Promise.resolve();
                                const bytes = (0, _bitmapCodec.encodePng)(state.width, state.height, state.pixels);
                                const ticket = ++state.sequence;
                                const pending = write(bytes, 'png').then((uri)=>{
                                    if (!active) {
                                        ready(uri);
                                        remove(uri);
                                        state.pending.delete(revision);
                                        throw new Error('当前脚本已退出');
                                    }
                                    if (ticket > state.committed) {
                                        state.src = uri;
                                        state.submitted = revision;
                                        state.committed = ticket;
                                    }
                                    ready(uri);
                                    state.pending.delete(revision);
                                    collect();
                                }, (error)=>{
                                    state.pending.delete(revision);
                                    throw error;
                                });
                                state.pending.set(revision, pending);
                                return pending;
                            }
                            function resolveImage(raw) {
                                const sourceInput = raw.source, formatInput = raw.format;
                                const cacheable = null === formatInput || 'object' != typeof formatInput && 'function' != typeof formatInput;
                                const variants = nextSources.get(sourceInput) || sources.get(sourceInput);
                                let parsed = cacheable && variants && variants.get(formatInput);
                                if (!parsed) {
                                    if ('string' != typeof sourceInput || !sourceInput.trim()) throw new Error('图片 source 必须是非空字符串');
                                    const source = sourceInput.trim();
                                    if (/^data:/i.test(source) || void 0 !== formatInput) {
                                        const data = /^data:image\/(png|jpe?g);base64,([\s\S]+)$/i.exec(source);
                                        if (/^data:/i.test(source) && !data) throw new Error('图片 Data URI 目前支持 PNG/JPG Base64');
                                        const format = (0, _bitmapCodec.imageFormat)(data ? data[1] : formatInput);
                                        const encoded = (data ? data[2] : source).replace(/\s/g, '');
                                        const key = format + ':' + encoded;
                                        let entry = images.get(key);
                                        if (!entry) {
                                            entry = {
                                                key,
                                                encoded,
                                                format,
                                                src: '',
                                                started: false
                                            };
                                            images.set(key, entry);
                                        }
                                        parsed = {
                                            entry
                                        };
                                    } else parsed = {
                                        src: source
                                    };
                                }
                                if (cacheable) {
                                    let next = nextSources.get(sourceInput);
                                    if (!next) {
                                        next = new Map();
                                        nextSources.set(sourceInput, next);
                                    }
                                    next.set(formatInput, parsed);
                                }
                                const descriptor = Object.assign({}, raw);
                                delete descriptor.source;
                                delete descriptor.format;
                                if (parsed.entry) requested.add(parsed.entry.key);
                                descriptor.src = parsed.entry ? parsed.entry.src : parsed.src;
                                return descriptor;
                            }
                            function resolveCanvas(raw) {
                                const state = canvases.get(raw);
                                if (!state) throw new Error('Canvas 实例无效，请使用 ui.canvas(options) 创建');
                                return Object.assign({}, raw, {
                                    src: state.src
                                });
                            }
                            const resolvers = {
                                image: resolveImage,
                                canvas: resolveCanvas
                            };
                            return {
                                canvas (options) {
                                    check();
                                    const result = (0, _canvasSurface.createCanvasSurface)(options, {
                                        check,
                                        color: host.color,
                                        submit
                                    });
                                    canvases.set(result.canvas, result.state);
                                    return result.canvas;
                                },
                                begin () {
                                    requested = new Set();
                                    nextSources = new Map();
                                },
                                resolve (raw) {
                                    return Object.prototype.hasOwnProperty.call(resolvers, raw.kind) ? resolvers[raw.kind](raw) : raw;
                                },
                                commit () {
                                    sources = nextSources;
                                    images.forEach((entry, key)=>{
                                        if (!requested.has(key)) images.delete(key);
                                    });
                                    images.forEach((entry)=>{
                                        if (entry.started) return;
                                        entry.started = true;
                                        Promise.resolve().then(()=>{
                                            if (!active || images.get(entry.key) !== entry) return;
                                            return write((0, _bitmapCodec.decodeImage)(entry.encoded, entry.format), entry.format).then((uri)=>{
                                                if (active && images.get(entry.key) === entry) {
                                                    entry.src = uri;
                                                    host.refresh();
                                                }
                                                ready(uri);
                                                collect();
                                            });
                                        }).then(null, (error)=>{
                                            if (active && images.get(entry.key) === entry) host.error(error);
                                        });
                                    });
                                    collect();
                                },
                                present (nodes) {
                                    const current = new Set();
                                    nodes.forEach((node)=>{
                                        if ('image' !== node.kind && 'canvas' !== node.kind) return;
                                        current.add(node.id);
                                        let frame = frames.get(node.id);
                                        if (!frame) {
                                            frame = {
                                                src: '',
                                                retired: ''
                                            };
                                            frames.set(node.id, frame);
                                        }
                                        if (frame.src !== node.src) {
                                            if (frame.src && !frame.retired) frame.retired = frame.src;
                                            frame.src = node.src;
                                        }
                                    });
                                    frames.forEach((frame, id)=>{
                                        if (!current.has(id)) frames.delete(id);
                                    });
                                    collect();
                                },
                                loaded (id, src) {
                                    const frame = frames.get(id);
                                    if (frame && frame.src === src) {
                                        frame.retired = '';
                                        collect();
                                    }
                                },
                                dispose () {
                                    active = false;
                                    canvases.forEach((state)=>{
                                        state.pixels = null;
                                        state.src = '';
                                    });
                                    canvases.clear();
                                    images.clear();
                                    frames.clear();
                                    requested.clear();
                                    sources.clear();
                                    nextSources.clear();
                                    collect();
                                }
                            };
                        }
                    },
                    "./src/utils/runtime/uiPublisher.js": function(__unused_webpack_module, exports) {
                        "use strict";
                        Object.defineProperty(exports, "__esModule", {
                            value: true
                        });
                        exports.createUiPublisher = createUiPublisher;
                        function copyNode(node) {
                            const copy = {};
                            for(const key in node)if ('autoLines' !== key) copy[key] = node[key];
                            return copy;
                        }
                        function patchNode(target, next, before) {
                            if (next === before) return;
                            for(const key in next)if ('autoLines' !== key && next[key] !== before[key]) target[key] = next[key];
                        }
                        function createUiPublisher() {
                            let previous = [];
                            return {
                                update (nodes, observed) {
                                    if (nodes === previous) return observed;
                                    const aligned = observed.length === previous.length;
                                    let stable = aligned && nodes.length === previous.length;
                                    if (stable) {
                                        for(let i = 0; i < nodes.length; i += 1)if (nodes[i].id !== previous[i].id || nodes[i].kind !== previous[i].kind) {
                                            stable = false;
                                            break;
                                        }
                                    }
                                    let result = observed;
                                    if (stable) {
                                        for(let i = 0; i < nodes.length; i += 1)if (nodes[i] !== previous[i]) patchNode(observed[i], nodes[i], previous[i]);
                                    } else {
                                        const retained = Object.create(null);
                                        if (aligned) {
                                            for(let i = 0; i < previous.length; i += 1)retained[previous[i].id] = i;
                                        }
                                        result = nodes.map((node)=>{
                                            const index = retained[node.id];
                                            if (void 0 !== index && previous[index].kind === node.kind) {
                                                patchNode(observed[index], node, previous[index]);
                                                return observed[index];
                                            }
                                            return copyNode(node);
                                        });
                                    }
                                    previous = nodes;
                                    return result;
                                }
                            };
                        }
                    },
                    "./src/utils/runtime/uiRuntime.js": function(__unused_webpack_module, exports, __webpack_require__) {
                        "use strict";
                        Object.defineProperty(exports, "__esModule", {
                            value: true
                        });
                        exports.createUiSession = createUiSession;
                        var _uiLayout = __webpack_require__("./src/utils/runtime/uiLayout.js");
                        var _uiMedia = __webpack_require__("./src/utils/runtime/uiMedia.js");
                        const nextTurn = Promise.resolve();
                        function node(kind, props, options) {
                            return Object.assign({}, props, options || {}, {
                                kind
                            });
                        }
                        function createUiSession(host) {
                            let active = true;
                            let queued = false;
                            let rendering = false;
                            let source = null;
                            let hasSource = false;
                            let nodes = [];
                            let cache = null;
                            let handlers = Object.create(null);
                            let forcePublish = false;
                            let visible = true;
                            let dirty = false;
                            let hasFrame = false;
                            let frameHeight = 480;
                            let frameEnd = 84;
                            const media = (0, _uiMedia.createUiMedia)({
                                files: host.files,
                                mediaReady: host.mediaReady,
                                color: _uiLayout.color,
                                rendering: ()=>rendering,
                                refresh,
                                error: (error)=>{
                                    if (active) host.error(error);
                                }
                            });
                            function flush() {
                                queued = false;
                                if (!active || !hasSource) return;
                                if (rendering) throw new Error('不要在 UI 渲染函数中更新状态');
                                rendering = true;
                                try {
                                    const view = 'function' == typeof source ? source() : source;
                                    media.begin();
                                    const result = (0, _uiLayout.compileUi)(view, host.top(), nodes, cache, media.resolve);
                                    const changed = forcePublish || nodes.length !== result.nodes.length || result.nodes.some((item, index)=>item !== nodes[index]);
                                    if (visible) host.publish(changed ? result.nodes : nodes, result.height, result.end, changed);
                                    cache = result.cache;
                                    handlers = result.handlers;
                                    if (changed) nodes = result.nodes;
                                    hasFrame = true;
                                    frameHeight = result.height;
                                    frameEnd = result.end;
                                    dirty = false;
                                    forcePublish = !visible;
                                    if (visible) media.present(result.nodes);
                                    media.commit();
                                    return true;
                                } catch (error) {
                                    forcePublish = true;
                                    host.error(error);
                                } finally{
                                    rendering = false;
                                }
                            }
                            function refresh() {
                                if (!active) return;
                                if (rendering) throw new Error('不要在 UI 渲染函数中更新状态');
                                dirty = true;
                                if (!visible) return;
                                if (queued) return;
                                queued = true;
                                nextTurn.then(()=>{
                                    if (queued && visible) flush();
                                    else queued = false;
                                });
                            }
                            const ui = {
                                version: 2,
                                getWidth () {
                                    return (0, _uiLayout.getUiWidth)();
                                },
                                render (view) {
                                    if (!active) return false;
                                    if (rendering) throw new Error('不要在 UI 渲染函数中调用 ui.render');
                                    if (host.clearError) host.clearError();
                                    const previous = {
                                        source,
                                        hasSource,
                                        nodes,
                                        cache,
                                        handlers,
                                        hasFrame,
                                        frameHeight,
                                        frameEnd,
                                        dirty,
                                        visible
                                    };
                                    source = view;
                                    hasSource = true;
                                    let success = flush();
                                    if (success && host.show) {
                                        try {
                                            success = false !== host.show();
                                        } catch (error) {
                                            host.error(error);
                                            success = false;
                                        }
                                    }
                                    if (!success) {
                                        source = previous.source;
                                        hasSource = previous.hasSource;
                                        nodes = previous.nodes;
                                        cache = previous.cache;
                                        handlers = previous.handlers;
                                        hasFrame = previous.hasFrame;
                                        frameHeight = previous.frameHeight;
                                        frameEnd = previous.frameEnd;
                                        dirty = previous.dirty;
                                        visible = previous.visible;
                                        forcePublish = true;
                                        if (visible && hasFrame) {
                                            try {
                                                host.publish(nodes, frameHeight, frameEnd, true);
                                                media.present(nodes);
                                                forcePublish = false;
                                            } catch (error) {
                                                host.error(error);
                                            }
                                        }
                                        if (dirty && visible && hasSource) refresh();
                                    }
                                    return !!success;
                                },
                                show () {
                                    if (!active || !hasFrame) return false;
                                    return host.show ? false !== host.show() : true;
                                },
                                hide () {
                                    if (active && host.hide) host.hide();
                                },
                                refresh,
                                setTitle (value) {
                                    if (active) host.title((0, _uiLayout.text)(value) || '脚本');
                                },
                                showHeader (visible) {
                                    if (active && host.header(false !== visible)) refresh();
                                },
                                scrollTo (position) {
                                    if (active) host.scroll(position);
                                },
                                scrollTop () {
                                    if (active) host.scroll('top');
                                },
                                scrollBottom () {
                                    if (active) host.scroll('bottom');
                                },
                                signal (initial) {
                                    let value = initial;
                                    const state = {
                                        get () {
                                            return value;
                                        },
                                        set (next) {
                                            if (rendering) throw new Error('不要在 UI 渲染函数中更新 signal');
                                            if (value === next || value !== value && next !== next) return value;
                                            value = next;
                                            refresh();
                                            return value;
                                        },
                                        update (updater) {
                                            return state.set('function' == typeof updater ? updater(value) : updater);
                                        }
                                    };
                                    return state;
                                },
                                heading (value, options) {
                                    return node('heading', {
                                        text: value
                                    }, options);
                                },
                                text (value, options) {
                                    return node('text', {
                                        text: value
                                    }, options);
                                },
                                button (value, onPress, options) {
                                    return node('button', {
                                        text: value,
                                        onPress
                                    }, options);
                                },
                                switch (value, checked, onChange, options) {
                                    return node('switch', {
                                        text: value,
                                        checked,
                                        onChange
                                    }, options);
                                },
                                slider (value, amount, onChange, options) {
                                    return node('slider', {
                                        text: value,
                                        value: amount,
                                        onChange
                                    }, options);
                                },
                                progress (value, percent, options) {
                                    return node('progress', {
                                        text: value,
                                        percent
                                    }, options);
                                },
                                grid (items, options) {
                                    return node('grid', {
                                        items
                                    }, options);
                                },
                                buttonRow (buttons, options) {
                                    return node('buttonRow', {
                                        buttons
                                    }, options);
                                },
                                divider (options) {
                                    return node('divider', {}, options);
                                },
                                spacer (size) {
                                    return node('spacer', {
                                        size
                                    });
                                },
                                row (children, options) {
                                    return node('row', {
                                        children
                                    }, options);
                                },
                                column (children, options) {
                                    return node('column', {
                                        children
                                    }, options);
                                },
                                stack (children, options) {
                                    return node('stack', {
                                        children
                                    }, options);
                                },
                                qrcode (value, options) {
                                    return node('qrcode', {
                                        value
                                    }, options);
                                },
                                image (source, options) {
                                    return node('image', {
                                        source
                                    }, options);
                                },
                                canvas (options) {
                                    const settings = options || {};
                                    const defaults = void 0 === settings.pixelWidth && void 0 === settings.pixelHeight ? {
                                        width: (0, _uiLayout.getUiWidth)()
                                    } : {};
                                    return media.canvas(Object.assign(defaults, settings));
                                }
                            };
                            return {
                                ui,
                                refresh,
                                imageLoaded (id, src) {
                                    if (active) media.loaded(id, src);
                                },
                                hasFrame () {
                                    return hasFrame;
                                },
                                setVisible (value) {
                                    const next = false !== value;
                                    if (!active) return false;
                                    if (visible === next && !(next && forcePublish)) return true;
                                    visible = next;
                                    if (visible && hasFrame) {
                                        forcePublish = true;
                                        if (dirty) return flush();
                                        try {
                                            host.publish(nodes, frameHeight, frameEnd, true);
                                            media.present(nodes);
                                            forcePublish = false;
                                            return true;
                                        } catch (error) {
                                            host.error(error);
                                            return false;
                                        }
                                    }
                                    return true;
                                },
                                invoke (id, value) {
                                    if (!active || !visible || 'function' != typeof handlers[id]) return false;
                                    try {
                                        if (host.clearError && host.clearError()) refresh();
                                        const result = handlers[id](value);
                                        if (result && 'function' == typeof result.then) result.then(null, (error)=>{
                                            if (active) host.error(error);
                                        });
                                    } catch (error) {
                                        if (active) host.error(error);
                                    }
                                    return true;
                                },
                                dispose () {
                                    active = false;
                                    queued = false;
                                    source = null;
                                    nodes = [];
                                    cache = null;
                                    handlers = Object.create(null);
                                    media.dispose();
                                }
                            };
                        }
                    }
                };
                var __webpack_module_cache__ = {};
                function __webpack_require__(moduleId) {
                    var cachedModule = __webpack_module_cache__[moduleId];
                    if (void 0 !== cachedModule) return cachedModule.exports;
                    var module = __webpack_module_cache__[moduleId] = {
                        exports: {}
                    };
                    __webpack_modules__[moduleId](module, module.exports, __webpack_require__);
                    return module.exports;
                }
                (()=>{
                    __webpack_require__.g = (()=>{
                        if ('object' == typeof globalThis) return globalThis;
                        try {
                            return this || new Function('return this')();
                        } catch (e) {
                            if ('object' == typeof window) return window;
                        }
                    })();
                })();
                (()=>{
                    __webpack_require__.rv = ()=>"1.4.11";
                })();
                (()=>{
                    __webpack_require__.ruid = "bundler=rspack@1.4.11";
                })();
                var __webpack_exports__ = {};
                (()=>{
                    var $app_style$ = [
                        [
                            [
                                [
                                    4,
                                    "JSLabActive"
                                ]
                            ],
                            {
                                fontface: {
                                    fontFamily: "JSLabActive",
                                    src: [
                                        "/common/fonts/active.ttf"
                                    ],
                                    fontWeight: [
                                        "normal"
                                    ],
                                    fontStyle: [
                                        "normal"
                                    ],
                                    fontName: "JSLabActive",
                                    fontSrc: [
                                        "/common/fonts/active.ttf"
                                    ]
                                }
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "ui-text"
                                ]
                            ],
                            {
                                fontFamily: "JSLabActive",
                                width: "100%",
                                flexShrink: 0,
                                textOverflow: "ellipsis"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "control-label"
                                ]
                            ],
                            {
                                fontFamily: "JSLabActive",
                                flexShrink: 0,
                                fontSize: "23px",
                                lineHeight: "28px",
                                fontWeight: "bold",
                                lines: 1,
                                textOverflow: "ellipsis"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "control-detail"
                                ]
                            ],
                            {
                                fontFamily: "JSLabActive",
                                flexShrink: 0,
                                fontSize: "20px",
                                lineHeight: "26px",
                                lines: 2,
                                textOverflow: "ellipsis"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "value-label"
                                ]
                            ],
                            {
                                fontFamily: "JSLabActive",
                                flex: 1,
                                minWidth: "0px",
                                fontSize: "23px",
                                lineHeight: "28px",
                                fontWeight: "bold",
                                lines: 1,
                                textOverflow: "ellipsis"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "value-text"
                                ]
                            ],
                            {
                                fontFamily: "JSLabActive",
                                flexShrink: 0,
                                fontSize: "21px",
                                lineHeight: "28px",
                                fontWeight: "bold",
                                marginLeft: "6px"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "title-text"
                                ]
                            ],
                            {
                                fontFamily: "JSLabActive",
                                position: "absolute",
                                left: "78px",
                                top: "35px",
                                width: "180px",
                                lineHeight: "42px",
                                color: "#ffffff",
                                fontSize: "30px",
                                fontWeight: "bold",
                                textAlign: "center"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "title-marquee"
                                ]
                            ],
                            {
                                fontFamily: "JSLabActive",
                                position: "absolute",
                                left: "78px",
                                top: "35px",
                                width: "180px",
                                lineHeight: "42px",
                                color: "#ffffff",
                                fontSize: "30px",
                                fontWeight: "bold",
                                textAlign: "center"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "console-log"
                                ]
                            ],
                            {
                                fontFamily: "JSLabActive",
                                width: "300px",
                                fontSize: "22px",
                                lineHeight: "30px",
                                color: "#0d6eff",
                                flexShrink: 0
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "console-error"
                                ]
                            ],
                            {
                                fontFamily: "JSLabActive",
                                width: "300px",
                                fontSize: "22px",
                                lineHeight: "30px",
                                color: "#f48771",
                                flexShrink: 0,
                                marginTop: "12px"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "error-text"
                                ]
                            ],
                            {
                                fontFamily: "JSLabActive",
                                color: "#f48771",
                                fontSize: "22px",
                                lineHeight: "30px",
                                marginTop: "8px"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "page"
                                ]
                            ],
                            {
                                width: "336px",
                                height: "480px",
                                overflow: "hidden",
                                backgroundColor: "#000000"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "content"
                                ]
                            ],
                            {
                                width: "336px",
                                height: "480px",
                                flexDirection: "column"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "content-inner"
                                ]
                            ],
                            {
                                width: "336px",
                                flexShrink: 0
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "node-wrap"
                                ]
                            ],
                            {
                                position: "absolute",
                                flexDirection: "column",
                                justifyContent: "center",
                                alignItems: "center",
                                overflow: "hidden"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "ui-image"
                                ]
                            ],
                            {
                                flexShrink: 0
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "node-button"
                                ]
                            ],
                            {
                                paddingTop: "0px",
                                paddingRight: "8px",
                                paddingBottom: "0px",
                                paddingLeft: "8px",
                                flexDirection: "row"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "node-switch"
                                ]
                            ],
                            {
                                paddingTop: "12px",
                                paddingRight: "16px",
                                paddingBottom: "12px",
                                paddingLeft: "16px",
                                flexDirection: "row",
                                justifyContent: "flex-start"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "node-slider"
                                ]
                            ],
                            {
                                paddingTop: "12px",
                                paddingRight: "16px",
                                paddingBottom: "12px",
                                paddingLeft: "16px",
                                alignItems: "flex-start"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "node-progress"
                                ]
                            ],
                            {
                                paddingTop: "12px",
                                paddingRight: "16px",
                                paddingBottom: "12px",
                                paddingLeft: "16px",
                                alignItems: "flex-start"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "control-copy"
                                ]
                            ],
                            {
                                flexDirection: "column",
                                flexShrink: 0
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "ui-switch"
                                ]
                            ],
                            {
                                width: "68px",
                                flexShrink: 0,
                                marginLeft: "8px"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "value-header"
                                ]
                            ],
                            {
                                height: "28px",
                                flexShrink: 0,
                                flexDirection: "row",
                                alignItems: "center"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "ui-slider"
                                ]
                            ],
                            {
                                flexShrink: 0,
                                marginTop: "8px",
                                paddingLeft: "0px",
                                paddingRight: "0px"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "ui-progress"
                                ]
                            ],
                            {
                                flexShrink: 0,
                                marginTop: "12px",
                                strokeWidth: "12px"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "empty-card"
                                ]
                            ],
                            {
                                position: "absolute",
                                left: "6px",
                                width: "324px",
                                paddingTop: "16px",
                                paddingRight: "18px",
                                paddingBottom: "16px",
                                paddingLeft: "18px",
                                borderRadius: "32px",
                                backgroundColor: "#24262a",
                                flexDirection: "column"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "error-card"
                                ]
                            ],
                            {
                                position: "absolute",
                                left: "6px",
                                width: "324px",
                                paddingTop: "16px",
                                paddingRight: "18px",
                                paddingBottom: "16px",
                                paddingLeft: "18px",
                                borderRadius: "32px",
                                backgroundColor: "#3a2020",
                                flexDirection: "column"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "empty-title"
                                ]
                            ],
                            {
                                color: "#ffffff",
                                fontSize: "28px",
                                lineHeight: "36px",
                                fontWeight: "bold"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "error-title"
                                ]
                            ],
                            {
                                color: "#f48771",
                                fontSize: "28px",
                                lineHeight: "36px",
                                fontWeight: "bold"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "empty-detail"
                                ]
                            ],
                            {
                                color: "#999999",
                                fontSize: "20px",
                                lineHeight: "28px",
                                marginTop: "6px"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "topbar-bg"
                                ]
                            ],
                            {
                                position: "absolute",
                                left: "0px",
                                top: "0px",
                                width: "336px",
                                height: "84px"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "time-text"
                                ]
                            ],
                            {
                                position: "absolute",
                                left: "78px",
                                top: "7px",
                                width: "180px",
                                lineHeight: "32px",
                                color: "#999999",
                                fontSize: "24px",
                                fontWeight: "bold",
                                textAlign: "center"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "btn"
                                ]
                            ],
                            {
                                position: "absolute",
                                width: "72px",
                                height: "72px"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "btn-left-top"
                                ]
                            ],
                            {
                                left: "6px",
                                top: "6px"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "btn-right-top"
                                ]
                            ],
                            {
                                left: "258px",
                                top: "6px"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "console-content"
                                ]
                            ],
                            {
                                position: "absolute",
                                top: "84px",
                                left: "6px",
                                width: "324px",
                                height: "396px",
                                paddingTop: "12px",
                                paddingRight: "12px",
                                paddingBottom: "24px",
                                paddingLeft: "12px",
                                flexDirection: "column"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "console-hint"
                                ]
                            ],
                            {
                                width: "300px",
                                fontSize: "20px",
                                lineHeight: "28px",
                                color: "#999999",
                                flexShrink: 0,
                                marginBottom: "12px"
                            }
                        ]
                    ];
                    var $app_script$ = function __scriptModule__(module, exports, $app_require$1) {
                        "use strict";
                        Object.defineProperty(exports, "__esModule", {
                            value: true
                        });
                        exports.default = void 0;
                        var _system = _interopRequireDefault($app_require$1("@app-module/system.file"));
                        var _system2 = _interopRequireDefault($app_require$1("@app-module/system.app"));
                        var _system3 = _interopRequireDefault($app_require$1("@app-module/system.router"));
                        var _routeManager = __webpack_require__("./src/utils/core/routeManager.js");
                        var _uiFeedback = __webpack_require__("./src/utils/core/uiFeedback.js");
                        var _time = __webpack_require__("./src/utils/core/time.js");
                        var _runtimeCompat = __webpack_require__("./src/utils/core/runtimeCompat.js");
                        var _scriptRuntimeApi = __webpack_require__("./src/utils/runtime/scriptRuntimeApi.js");
                        var _screen = __webpack_require__("./src/utils/core/screen.js");
                        var _uiRuntime = __webpack_require__("./src/utils/runtime/uiRuntime.js");
                        var _uiPublisher = __webpack_require__("./src/utils/runtime/uiPublisher.js");
                        var _consoleBuffer = __webpack_require__("./src/utils/runtime/consoleBuffer.js");
                        function _interopRequireDefault(e) {
                            return e && e.__esModule ? e : {
                                default: e
                            };
                        }
                        const runs = new WeakMap();
                        var _default = exports.default = {
                            private: {
                                screen: _screen.SCREEN,
                                nowTime: '00:00',
                                view: 'console',
                                pageTitle: '脚本',
                                showTopBar: true,
                                hasUi: false,
                                contentTopPadding: _screen.SCREEN.header,
                                uiNodes: [],
                                emptyTitle: '空界面',
                                emptyDetail: '脚本未提供显示组件',
                                error: '',
                                logText: '',
                                layoutHeight: _screen.SCREEN.height,
                                contentEnd: _screen.SCREEN.header,
                                errorTop: _screen.SCREEN.header
                            },
                            onInit () {
                                const pending = {
                                    active: true,
                                    visible: true
                                };
                                runs.set(this, pending);
                                this.$app.$def.loadPayload().then((start)=>{
                                    if (pending.active) this.startRun(start, pending.visible);
                                }, (error)=>{
                                    if (pending.active) this.error = (0, _consoleBuffer.formatError)(error);
                                });
                            },
                            startRun (start, visible) {
                                const state = {
                                    active: true,
                                    visible: visible,
                                    start: start || {
                                        name: 'untitled.js',
                                        code: ''
                                    },
                                    header: !start.options.hideTopBar,
                                    uiTitle: start.appName,
                                    publisher: (0, _uiPublisher.createUiPublisher)(),
                                    pending: null,
                                    logTimer: null,
                                    scroll: null
                                };
                                runs.set(this, state);
                                state.logs = (0, _consoleBuffer.createConsoleBuffer)(()=>this.queueLogs());
                                if (start.options.disableConsole) Object.keys(state.logs.console).forEach((key)=>{
                                    state.logs.console[key] = ()=>{};
                                });
                                this.showTopBar = state.header;
                                this.contentTopPadding = state.header ? _screen.SCREEN.header : _screen.SCREEN.topInset;
                                state.session = (0, _uiRuntime.createUiSession)({
                                    files: _system.default,
                                    mediaReady: this.$app.$def.uiMediaReady,
                                    top: ()=>state.header ? _screen.SCREEN.header : _screen.SCREEN.topInset,
                                    title: (value)=>{
                                        state.uiTitle = value;
                                        if ('ui' === this.view) this.pageTitle = value;
                                    },
                                    header: (value)=>{
                                        value = value && !state.start.options.hideTopBar;
                                        if (state.header === value) return false;
                                        state.header = value;
                                        if ('ui' === this.view) {
                                            this.showTopBar = value;
                                            this.contentTopPadding = value ? _screen.SCREEN.header : _screen.SCREEN.topInset;
                                        }
                                        return true;
                                    },
                                    show: ()=>this.showUi(),
                                    hide: ()=>this.showConsole(),
                                    scroll: (value)=>this.requestScroll(value),
                                    publish: (nodes, height, end, changed)=>this.publishUi(nodes, height, end, changed),
                                    error: (error)=>this.reportError(error),
                                    clearError: ()=>this.clearRuntimeError()
                                });
                                state.session.setVisible(false);
                                this.updateTime();
                                this.pageTitle = state.start.appName.slice(0, 80);
                                const runtime = (0, _scriptRuntimeApi.createScriptRuntimeApi)(this.$app.$def, {
                                    name: state.start.name,
                                    owner: this,
                                    isActive: ()=>state.active && !state.navigating && !state.pending,
                                    reload: ()=>this.reload(),
                                    exit: ()=>this.navigate('exit')
                                });
                                try {
                                    const execute = new Function('console', 'ui', 'dialog', "script", 'system', state.start.code);
                                    const result = execute(state.logs.console, state.session.ui, runtime.dialog, runtime.script, runtime.system);
                                    if (result && 'function' == typeof result.then) result.then(null, (error)=>this.reportError(error));
                                } catch (error) {
                                    this.reportError(error);
                                }
                                this.flushLogs();
                            },
                            onShow () {
                                (0, _time.startPageClock)(this);
                                const state = runs.get(this);
                                if (!state || !state.active) return;
                                state.visible = true;
                                this.$app.$def.deliverDialog(this);
                                if (state.pending) {
                                    const action = state.pending;
                                    state.pending = null;
                                    this.navigate(action);
                                    return;
                                }
                                if (state.session) state.session.setVisible('ui' === this.view);
                                if (state.logs && 'console' === this.view) this.flushLogs();
                                this.updateTime();
                            },
                            onHide () {
                                (0, _time.stopPageClock)(this);
                                const state = runs.get(this);
                                if (!state) return;
                                state.visible = false;
                                if (state.session) state.session.setVisible(false);
                                if (null !== state.logTimer) clearTimeout(state.logTimer);
                                state.logTimer = null;
                            },
                            onDestroy () {
                                (0, _time.stopPageClock)(this);
                                const state = runs.get(this);
                                if (!state) return;
                                state.active = false;
                                this.$app.$def.cancelOwnedDialog(this);
                                if (state.session) state.session.dispose();
                                if (state.logs) state.logs.dispose();
                                if (null !== state.logTimer) clearTimeout(state.logTimer);
                                runs.delete(this);
                            },
                            updateTime () {
                                this.nowTime = (0, _time.getCurrentClock)();
                            },
                            showUi () {
                                const state = runs.get(this);
                                if (!state || !state.active || state.navigating || state.pending || !state.session.hasFrame()) return false;
                                const previousView = this.view;
                                this.view = 'ui';
                                this.pageTitle = state.uiTitle;
                                this.showTopBar = state.header;
                                this.contentTopPadding = state.header ? _screen.SCREEN.header : _screen.SCREEN.topInset;
                                if (null !== state.logTimer) clearTimeout(state.logTimer);
                                state.logTimer = null;
                                if (state.visible && false === state.session.setVisible(true)) {
                                    if ('console' === previousView) this.showConsole();
                                    return false;
                                }
                                this.hasUi = true;
                                return true;
                            },
                            showConsole () {
                                const state = runs.get(this);
                                if (!state || !state.active || state.navigating || state.pending) return;
                                state.session.setVisible(false);
                                this.view = 'console';
                                this.showTopBar = !state.start.options.hideTopBar;
                                this.pageTitle = state.start.appName.slice(0, 80);
                                if (state.visible) this.flushLogs();
                            },
                            restoreUi () {
                                const state = runs.get(this);
                                if (state && state.session) state.session.ui.show();
                            },
                            onBack () {
                                (0, _uiFeedback.vibrate)('short');
                                const state = runs.get(this);
                                if (state && state.session) if ('ui' === this.view) this.showConsole();
                                else this.navigate('exit');
                                else _system2.default.terminate();
                            },
                            showAbout () {
                                _system3.default.push({
                                    uri: '/about'
                                });
                            },
                            onBackPress () {
                                this.onBack();
                                return true;
                            },
                            reload () {
                                this.navigate('reload');
                            },
                            navigate (action) {
                                const state = runs.get(this);
                                if (!state || !state.active || state.navigating || state.pending) return;
                                state.pending = action;
                                try {
                                    if (this.$app.$def.closeOwnedDialog(this)) return;
                                } catch (error) {
                                    state.pending = null;
                                    this.reportError(error);
                                    return;
                                }
                                state.pending = null;
                                state.navigating = true;
                                try {
                                    if ('reload' === action) (0, _routeManager.replace)('run');
                                    else _system2.default.terminate();
                                } catch (error) {
                                    state.navigating = false;
                                    this.reportError(error);
                                }
                            },
                            queueLogs () {
                                const state = runs.get(this);
                                if (!state || !state.visible || 'console' !== this.view || null !== state.logTimer) return;
                                state.logTimer = setTimeout(()=>{
                                    state.logTimer = null;
                                    this.flushLogs();
                                }, 32);
                            },
                            flushLogs () {
                                const state = runs.get(this);
                                if (state && state.logs && state.active && state.visible && 'console' === this.view) this.logText = state.logs.read();
                            },
                            reportError (error) {
                                const state = runs.get(this);
                                if (!state || !state.active) return;
                                this.error = (0, _consoleBuffer.formatError)(error);
                                state.logs.console.error(this.error);
                                this.errorTop = this.uiNodes.length ? this.contentEnd : this.contentTopPadding + 140;
                                if ('ui' === this.view) this.layoutHeight = Math.max(this.layoutHeight, this.errorTop + 64 + 30 * Math.ceil(this.error.length / 12));
                                else this.flushLogs();
                            },
                            clearRuntimeError () {
                                if (!this.error) return false;
                                this.error = '';
                                return true;
                            },
                            publishUi (nodes, height, end, changed) {
                                const state = runs.get(this);
                                if (!state || !state.active) return;
                                if (changed) {
                                    try {
                                        const next = state.publisher.update(nodes, this.uiNodes);
                                        if (next !== this.uiNodes) this.uiNodes = next;
                                    } catch (error) {
                                        state.publisher = (0, _uiPublisher.createUiPublisher)();
                                        throw error;
                                    }
                                }
                                this.contentEnd = end;
                                if (this.error) {
                                    this.errorTop = nodes.length ? end : this.contentTopPadding + 140;
                                    height = Math.max(height, this.errorTop + 64 + 30 * Math.ceil(this.error.length / 12));
                                }
                                this.layoutHeight = height;
                                if (null !== state.scroll) this.requestScroll(state.scroll);
                            },
                            requestScroll (value) {
                                const state = runs.get(this);
                                if (!state) return;
                                state.scroll = value;
                                if (!state.visible || 'ui' !== this.view) return;
                                (0, _runtimeCompat.scheduleNextTick)(this, ()=>{
                                    if (!state.active || !state.visible || 'ui' !== this.view || null === state.scroll) return;
                                    const element = (0, _runtimeCompat.getPageElement)(this, 'ui-scroll');
                                    if (!element || !element.scrollTo) return;
                                    const target = state.scroll;
                                    state.scroll = null;
                                    element.scrollTo({
                                        top: 'bottom' === target ? this.layoutHeight : 'top' === target ? 0 : Number(target) || 0,
                                        left: 0,
                                        behavior: 'smooth'
                                    });
                                });
                            },
                            onImageLoaded (id, src) {
                                const state = runs.get(this);
                                if (state && state.session) state.session.imageLoaded(id, src);
                            },
                            onImageError (id, src) {
                                this.onImageLoaded(id, src);
                                this.reportError(new Error('图片加载失败：' + id + '，请检查图片格式和地址'));
                            },
                            onNodePress (id, kind) {
                                if ('button' === kind) this.onButtonPress(id);
                            },
                            onButtonPress (id) {
                                const state = runs.get(this);
                                if (state && state.session.invoke(id)) (0, _uiFeedback.vibrate)('short');
                            },
                            onSwitchChange (id, event) {
                                const data = event && event.detail ? event.detail : event;
                                const state = runs.get(this);
                                if (state) state.session.invoke(id, !!(data && data.checked));
                            },
                            onSliderChange (id, event) {
                                const data = event && event.detail ? event.detail : event;
                                if (data && false === data.isFromUser) return;
                                const state = runs.get(this);
                                if (state) state.session.invoke(id, Number(data && data.progress) || 0);
                            }
                        };
                        const moduleOwn = exports.default || module.exports;
                        const accessors = [
                            'public',
                            'protected',
                            'private'
                        ];
                        if (moduleOwn.data && accessors.some(function(acc) {
                            return moduleOwn[acc];
                        })) throw new Error('页面VM对象中的属性data不可与"' + accessors.join(',') + '"同时存在，请使用private替换data名称');
                        if (!moduleOwn.data) {
                            moduleOwn.data = {};
                            moduleOwn._descriptor = {};
                            accessors.forEach(function(acc) {
                                const accType = typeof moduleOwn[acc];
                                if ('object' === accType) {
                                    moduleOwn.data = Object.assign(moduleOwn.data, moduleOwn[acc]);
                                    for(const name in moduleOwn[acc])moduleOwn._descriptor[name] = {
                                        access: acc
                                    };
                                } else if ('function' === accType) console.warn('页面VM对象中的属性' + acc + '的值不能是函数，请使用对象');
                            });
                        }
                    };
                    var $app_template$ = function(vm) {
                        const _vm_ = vm || this;
                        return aiot.__ce__("div", {
                            __vm__: _vm_,
                            __opts__: {
                                classList: [
                                    "page"
                                ]
                            }
                        }, [
                            aiot.__ci__({
                                __vm__: _vm_,
                                __opts__: {
                                    shown: function() {
                                        return "ui" === _vm_.view;
                                    }
                                }
                            }, function() {
                                return [
                                    aiot.__ce__("scroll", {
                                        __vm__: _vm_,
                                        __opts__: {
                                            id: "ui-scroll",
                                            classList: [
                                                "content"
                                            ],
                                            scrollY: "true",
                                            bounces: "true"
                                        }
                                    }, [
                                        aiot.__ce__("div", {
                                            __vm__: _vm_,
                                            __opts__: {
                                                classList: [
                                                    "content-inner"
                                                ],
                                                style: function() {
                                                    return __webpack_require__.g.$translateStyle$({
                                                        height: "" + _vm_.layoutHeight + "px"
                                                    });
                                                }
                                            }
                                        }, [
                                            aiot.__ci__({
                                                __vm__: _vm_,
                                                __opts__: {
                                                    shown: function() {
                                                        return 0 === _vm_.uiNodes.length;
                                                    }
                                                }
                                            }, function() {
                                                return [
                                                    aiot.__ce__("div", {
                                                        __vm__: _vm_,
                                                        __opts__: {
                                                            classList: [
                                                                "empty-card"
                                                            ],
                                                            style: function() {
                                                                return __webpack_require__.g.$translateStyle$({
                                                                    top: "" + _vm_.contentTopPadding + "px"
                                                                });
                                                            }
                                                        }
                                                    }, [
                                                        aiot.__ce__("text", {
                                                            __vm__: _vm_,
                                                            __opts__: {
                                                                classList: [
                                                                    "empty-title"
                                                                ],
                                                                value: function() {
                                                                    return _vm_.emptyTitle;
                                                                }
                                                            }
                                                        }, []),
                                                        aiot.__ce__("text", {
                                                            __vm__: _vm_,
                                                            __opts__: {
                                                                classList: [
                                                                    "empty-detail"
                                                                ],
                                                                value: function() {
                                                                    return _vm_.emptyDetail;
                                                                }
                                                            }
                                                        }, [])
                                                    ])
                                                ];
                                            }),
                                            aiot.__cf__({
                                                __vm__: _vm_,
                                                __opts__: {
                                                    exp: function() {
                                                        return {
                                                            __list__: _vm_.uiNodes,
                                                            __tid__: "id"
                                                        };
                                                    },
                                                    key: "$idx",
                                                    value: "node"
                                                }
                                            }, function($idx, node) {
                                                return [
                                                    aiot.__ce__("div", {
                                                        __vm__: _vm_,
                                                        __opts__: {
                                                            classList: function() {
                                                                const $classValue$ = "node-wrap node-" + node.kind;
                                                                if ('string' == typeof $classValue$) return $classValue$.split(' ').map((item)=>item.trim()).filter(Boolean);
                                                                return $classValue$;
                                                            },
                                                            style: function() {
                                                                return __webpack_require__.g.$translateStyle$({
                                                                    left: "" + node.x + "px",
                                                                    top: "" + node.y + "px",
                                                                    width: "" + node.width + "px",
                                                                    height: "" + node.height + "px",
                                                                    backgroundColor: "" + node.background,
                                                                    borderRadius: "" + node.radius + "px"
                                                                });
                                                            },
                                                            events: {
                                                                click: function(evt) {
                                                                    return _vm_.onNodePress(node.id, node.kind, evt);
                                                                }
                                                            }
                                                        }
                                                    }, [
                                                        aiot.__ci__({
                                                            __vm__: _vm_,
                                                            __opts__: {
                                                                shown: function() {
                                                                    return "heading" === node.kind || "text" === node.kind;
                                                                }
                                                            }
                                                        }, function() {
                                                            return [
                                                                aiot.__ce__("text", {
                                                                    __vm__: _vm_,
                                                                    __opts__: {
                                                                        classList: [
                                                                            "ui-text"
                                                                        ],
                                                                        style: function() {
                                                                            return __webpack_require__.g.$translateStyle$({
                                                                                color: "" + node.color,
                                                                                fontSize: "" + node.size + "px",
                                                                                lineHeight: "" + node.lineHeight + "px",
                                                                                fontWeight: "" + node.bold,
                                                                                textAlign: "" + node.align,
                                                                                lines: "" + node.lines
                                                                            });
                                                                        },
                                                                        value: function() {
                                                                            return node.text;
                                                                        }
                                                                    }
                                                                }, [])
                                                            ];
                                                        }),
                                                        aiot.__ci__({
                                                            __vm__: _vm_,
                                                            __opts__: {
                                                                shown: function() {
                                                                    return !("heading" === node.kind || "text" === node.kind) && "button" === node.kind;
                                                                }
                                                            }
                                                        }, function() {
                                                            return [
                                                                aiot.__ce__("text", {
                                                                    __vm__: _vm_,
                                                                    __opts__: {
                                                                        classList: [
                                                                            "ui-text"
                                                                        ],
                                                                        style: function() {
                                                                            return __webpack_require__.g.$translateStyle$({
                                                                                width: "" + (node.width > 16 ? node.width - 16 : 0) + "px",
                                                                                color: "" + node.color,
                                                                                fontSize: "" + node.size + "px",
                                                                                lineHeight: "" + node.lineHeight + "px",
                                                                                lines: "" + node.lines,
                                                                                fontWeight: "bold",
                                                                                textAlign: "center"
                                                                            });
                                                                        },
                                                                        value: function() {
                                                                            return node.text;
                                                                        }
                                                                    }
                                                                }, [])
                                                            ];
                                                        }),
                                                        aiot.__ci__({
                                                            __vm__: _vm_,
                                                            __opts__: {
                                                                shown: function() {
                                                                    return "button" !== node.kind && !("heading" === node.kind || "text" === node.kind) && "switch" === node.kind;
                                                                }
                                                            }
                                                        }, function() {
                                                            return [
                                                                aiot.__ce__("div", {
                                                                    __vm__: _vm_,
                                                                    __opts__: {
                                                                        classList: [
                                                                            "control-copy"
                                                                        ],
                                                                        style: function() {
                                                                            return __webpack_require__.g.$translateStyle$({
                                                                                width: "" + node.copyWidth + "px"
                                                                            });
                                                                        }
                                                                    }
                                                                }, [
                                                                    aiot.__ce__("text", {
                                                                        __vm__: _vm_,
                                                                        __opts__: {
                                                                            classList: [
                                                                                "control-label"
                                                                            ],
                                                                            style: function() {
                                                                                return __webpack_require__.g.$translateStyle$({
                                                                                    width: "" + node.copyWidth + "px",
                                                                                    color: "" + node.color
                                                                                });
                                                                            },
                                                                            value: function() {
                                                                                return node.text;
                                                                            }
                                                                        }
                                                                    }, []),
                                                                    aiot.__ci__({
                                                                        __vm__: _vm_,
                                                                        __opts__: {
                                                                            shown: function() {
                                                                                return node.detail;
                                                                            }
                                                                        }
                                                                    }, function() {
                                                                        return [
                                                                            aiot.__ce__("text", {
                                                                                __vm__: _vm_,
                                                                                __opts__: {
                                                                                    classList: [
                                                                                        "control-detail"
                                                                                    ],
                                                                                    style: function() {
                                                                                        return __webpack_require__.g.$translateStyle$({
                                                                                            width: "" + node.copyWidth + "px",
                                                                                            color: "" + node.detailColor
                                                                                        });
                                                                                    },
                                                                                    value: function() {
                                                                                        return node.detail;
                                                                                    }
                                                                                }
                                                                            }, [])
                                                                        ];
                                                                    })
                                                                ])
                                                            ];
                                                        }),
                                                        aiot.__ci__({
                                                            __vm__: _vm_,
                                                            __opts__: {
                                                                shown: function() {
                                                                    return "switch" !== node.kind && "button" !== node.kind && !("heading" === node.kind || "text" === node.kind) && ("slider" === node.kind || "progress" === node.kind);
                                                                }
                                                            }
                                                        }, function() {
                                                            return [
                                                                aiot.__ce__("div", {
                                                                    __vm__: _vm_,
                                                                    __opts__: {
                                                                        classList: [
                                                                            "value-header"
                                                                        ],
                                                                        style: function() {
                                                                            return __webpack_require__.g.$translateStyle$({
                                                                                width: "" + (node.width - 32) + "px"
                                                                            });
                                                                        }
                                                                    }
                                                                }, [
                                                                    aiot.__ce__("text", {
                                                                        __vm__: _vm_,
                                                                        __opts__: {
                                                                            classList: [
                                                                                "value-label"
                                                                            ],
                                                                            style: function() {
                                                                                return __webpack_require__.g.$translateStyle$({
                                                                                    color: "" + node.color
                                                                                });
                                                                            },
                                                                            value: function() {
                                                                                return node.text;
                                                                            }
                                                                        }
                                                                    }, []),
                                                                    aiot.__ce__("text", {
                                                                        __vm__: _vm_,
                                                                        __opts__: {
                                                                            classList: [
                                                                                "value-text"
                                                                            ],
                                                                            style: function() {
                                                                                return __webpack_require__.g.$translateStyle$({
                                                                                    color: "" + node.accent
                                                                                });
                                                                            },
                                                                            value: function() {
                                                                                return "progress" === node.kind ? node.percent + "%" : node.value;
                                                                            }
                                                                        }
                                                                    }, [])
                                                                ])
                                                            ];
                                                        }),
                                                        aiot.__ci__({
                                                            __vm__: _vm_,
                                                            __opts__: {
                                                                shown: function() {
                                                                    return !("slider" === node.kind || "progress" === node.kind) && "switch" !== node.kind && "button" !== node.kind && !("heading" === node.kind || "text" === node.kind) && "qrcode" === node.kind;
                                                                }
                                                            }
                                                        }, function() {
                                                            return [
                                                                aiot.__ce__("qrcode", {
                                                                    __vm__: _vm_,
                                                                    __opts__: {
                                                                        value: function() {
                                                                            return node.value;
                                                                        },
                                                                        style: function() {
                                                                            return __webpack_require__.g.$translateStyle$({
                                                                                width: "" + node.qrSize + "px",
                                                                                height: "" + node.qrSize + "px",
                                                                                color: "" + node.color,
                                                                                backgroundColor: "" + node.background
                                                                            });
                                                                        }
                                                                    }
                                                                }, [])
                                                            ];
                                                        }),
                                                        aiot.__ci__({
                                                            __vm__: _vm_,
                                                            __opts__: {
                                                                shown: function() {
                                                                    return "qrcode" !== node.kind && !("slider" === node.kind || "progress" === node.kind) && "switch" !== node.kind && "button" !== node.kind && !("heading" === node.kind || "text" === node.kind) && ("image" === node.kind || "canvas" === node.kind) && node.src;
                                                                }
                                                            }
                                                        }, function() {
                                                            return [
                                                                aiot.__ce__("image", {
                                                                    __vm__: _vm_,
                                                                    __opts__: {
                                                                        classList: [
                                                                            "ui-image"
                                                                        ],
                                                                        src: function() {
                                                                            return node.src;
                                                                        },
                                                                        style: function() {
                                                                            return __webpack_require__.g.$translateStyle$({
                                                                                width: "" + node.width + "px",
                                                                                height: "" + node.height + "px",
                                                                                objectFit: "" + node.fit
                                                                            });
                                                                        },
                                                                        events: {
                                                                            complete: function(evt) {
                                                                                return _vm_.onImageLoaded(node.id, node.src, evt);
                                                                            },
                                                                            error: function(evt) {
                                                                                return _vm_.onImageError(node.id, node.src, evt);
                                                                            }
                                                                        }
                                                                    }
                                                                }, [])
                                                            ];
                                                        }),
                                                        aiot.__ci__({
                                                            __vm__: _vm_,
                                                            __opts__: {
                                                                shown: function() {
                                                                    return "switch" === node.kind;
                                                                }
                                                            }
                                                        }, function() {
                                                            return [
                                                                aiot.__ce__("switch", {
                                                                    __vm__: _vm_,
                                                                    __opts__: {
                                                                        classList: [
                                                                            "ui-switch"
                                                                        ],
                                                                        checked: function() {
                                                                            return node.checked;
                                                                        },
                                                                        style: function() {
                                                                            return __webpack_require__.g.$translateStyle$({
                                                                                trackColor: "" + node.accent,
                                                                                thumbColor: "" + node.thumbColor
                                                                            });
                                                                        },
                                                                        events: {
                                                                            change: function(evt) {
                                                                                return _vm_.onSwitchChange(node.id, evt);
                                                                            }
                                                                        }
                                                                    }
                                                                }, [])
                                                            ];
                                                        }),
                                                        aiot.__ci__({
                                                            __vm__: _vm_,
                                                            __opts__: {
                                                                shown: function() {
                                                                    return "switch" !== node.kind && "slider" === node.kind;
                                                                }
                                                            }
                                                        }, function() {
                                                            return [
                                                                aiot.__ce__("slider", {
                                                                    __vm__: _vm_,
                                                                    __opts__: {
                                                                        classList: [
                                                                            "ui-slider"
                                                                        ],
                                                                        min: function() {
                                                                            return node.min;
                                                                        },
                                                                        max: function() {
                                                                            return node.max;
                                                                        },
                                                                        step: function() {
                                                                            return node.step;
                                                                        },
                                                                        value: function() {
                                                                            return node.value;
                                                                        },
                                                                        style: function() {
                                                                            return __webpack_require__.g.$translateStyle$({
                                                                                width: "" + (node.width - 32) + "px",
                                                                                height: "" + (node.height - 60) + "px",
                                                                                color: "" + node.trackColor,
                                                                                selectedColor: "" + node.accent,
                                                                                blockColor: "" + node.thumbColor
                                                                            });
                                                                        },
                                                                        events: {
                                                                            change: function(evt) {
                                                                                return _vm_.onSliderChange(node.id, evt);
                                                                            }
                                                                        }
                                                                    }
                                                                }, [])
                                                            ];
                                                        }),
                                                        aiot.__ci__({
                                                            __vm__: _vm_,
                                                            __opts__: {
                                                                shown: function() {
                                                                    return "slider" !== node.kind && "switch" !== node.kind && "progress" === node.kind;
                                                                }
                                                            }
                                                        }, function() {
                                                            return [
                                                                aiot.__ce__("progress", {
                                                                    __vm__: _vm_,
                                                                    __opts__: {
                                                                        classList: [
                                                                            "ui-progress"
                                                                        ],
                                                                        percent: function() {
                                                                            return node.percent;
                                                                        },
                                                                        style: function() {
                                                                            return __webpack_require__.g.$translateStyle$({
                                                                                width: "" + (node.width - 32) + "px",
                                                                                color: "" + node.accent,
                                                                                layerColor: "" + node.trackColor
                                                                            });
                                                                        }
                                                                    }
                                                                }, [])
                                                            ];
                                                        })
                                                    ])
                                                ];
                                            }),
                                            aiot.__ci__({
                                                __vm__: _vm_,
                                                __opts__: {
                                                    shown: function() {
                                                        return _vm_.error;
                                                    }
                                                }
                                            }, function() {
                                                return [
                                                    aiot.__ce__("div", {
                                                        __vm__: _vm_,
                                                        __opts__: {
                                                            classList: [
                                                                "error-card"
                                                            ],
                                                            style: function() {
                                                                return __webpack_require__.g.$translateStyle$({
                                                                    top: "" + _vm_.errorTop + "px"
                                                                });
                                                            }
                                                        }
                                                    }, [
                                                        aiot.__ce__("text", {
                                                            __vm__: _vm_,
                                                            __opts__: {
                                                                classList: [
                                                                    "error-title"
                                                                ],
                                                                value: "运行错误"
                                                            }
                                                        }, []),
                                                        aiot.__ce__("text", {
                                                            __vm__: _vm_,
                                                            __opts__: {
                                                                classList: [
                                                                    "error-text"
                                                                ],
                                                                value: function() {
                                                                    return _vm_.error;
                                                                }
                                                            }
                                                        }, [])
                                                    ])
                                                ];
                                            })
                                        ])
                                    ])
                                ];
                            }),
                            aiot.__ci__({
                                __vm__: _vm_,
                                __opts__: {
                                    shown: function() {
                                        return "console" === _vm_.view;
                                    }
                                }
                            }, function() {
                                return [
                                    aiot.__ce__("scroll", {
                                        __vm__: _vm_,
                                        __opts__: {
                                            classList: [
                                                "console-content"
                                            ],
                                            style: function() {
                                                return __webpack_require__.g.$translateStyle$({
                                                    top: "" + (_vm_.showTopBar ? _vm_.screen.header : _vm_.screen.topInset) + "px",
                                                    height: "" + (_vm_.screen.height - (_vm_.showTopBar ? _vm_.screen.header : _vm_.screen.topInset)) + "px"
                                                });
                                            },
                                            scrollY: "true",
                                            events: {
                                                click: function(evt) {
                                                    return _vm_.restoreUi(evt);
                                                }
                                            }
                                        }
                                    }, [
                                        aiot.__ci__({
                                            __vm__: _vm_,
                                            __opts__: {
                                                shown: function() {
                                                    return _vm_.hasUi;
                                                }
                                            }
                                        }, function() {
                                            return [
                                                aiot.__ce__("text", {
                                                    __vm__: _vm_,
                                                    __opts__: {
                                                        classList: [
                                                            "console-hint"
                                                        ],
                                                        value: "轻点日志返回界面"
                                                    }
                                                }, [])
                                            ];
                                        }),
                                        aiot.__ci__({
                                            __vm__: _vm_,
                                            __opts__: {
                                                shown: function() {
                                                    return !_vm_.logText && !_vm_.error;
                                                }
                                            }
                                        }, function() {
                                            return [
                                                aiot.__ce__("text", {
                                                    __vm__: _vm_,
                                                    __opts__: {
                                                        classList: [
                                                            "console-hint"
                                                        ],
                                                        value: "暂无日志"
                                                    }
                                                }, [])
                                            ];
                                        }),
                                        aiot.__ce__("text", {
                                            __vm__: _vm_,
                                            __opts__: {
                                                classList: [
                                                    "console-log"
                                                ],
                                                value: function() {
                                                    return _vm_.logText;
                                                }
                                            }
                                        }, []),
                                        aiot.__ci__({
                                            __vm__: _vm_,
                                            __opts__: {
                                                shown: function() {
                                                    return _vm_.error;
                                                }
                                            }
                                        }, function() {
                                            return [
                                                aiot.__ce__("text", {
                                                    __vm__: _vm_,
                                                    __opts__: {
                                                        classList: [
                                                            "console-error"
                                                        ],
                                                        value: function() {
                                                            return _vm_.error;
                                                        }
                                                    }
                                                }, [])
                                            ];
                                        })
                                    ])
                                ];
                            }),
                            aiot.__ci__({
                                __vm__: _vm_,
                                __opts__: {
                                    shown: function() {
                                        return _vm_.showTopBar;
                                    }
                                }
                            }, function() {
                                return [
                                    aiot.__ce__("image", {
                                        __vm__: _vm_,
                                        __opts__: {
                                            src: "/common/images/hd.png",
                                            classList: [
                                                "topbar-bg"
                                            ]
                                        }
                                    }, [])
                                ];
                            }),
                            aiot.__ci__({
                                __vm__: _vm_,
                                __opts__: {
                                    shown: function() {
                                        return _vm_.showTopBar;
                                    }
                                }
                            }, function() {
                                return [
                                    aiot.__ce__("text", {
                                        __vm__: _vm_,
                                        __opts__: {
                                            classList: [
                                                "time-text"
                                            ],
                                            value: function() {
                                                return _vm_.nowTime;
                                            }
                                        }
                                    }, [])
                                ];
                            }),
                            aiot.__ci__({
                                __vm__: _vm_,
                                __opts__: {
                                    shown: function() {
                                        return _vm_.showTopBar && _vm_.pageTitle.length <= 5;
                                    }
                                }
                            }, function() {
                                return [
                                    aiot.__ce__("text", {
                                        __vm__: _vm_,
                                        __opts__: {
                                            classList: [
                                                "title-text"
                                            ],
                                            value: function() {
                                                return _vm_.pageTitle;
                                            }
                                        }
                                    }, [])
                                ];
                            }),
                            aiot.__ci__({
                                __vm__: _vm_,
                                __opts__: {
                                    shown: function() {
                                        return _vm_.showTopBar && _vm_.pageTitle.length > 5;
                                    }
                                }
                            }, function() {
                                return [
                                    aiot.__ce__("marquee", {
                                        __vm__: _vm_,
                                        __opts__: {
                                            classList: [
                                                "title-marquee"
                                            ],
                                            scrollamount: "4",
                                            loop: "-1",
                                            value: function() {
                                                return _vm_.pageTitle;
                                            }
                                        }
                                    }, [])
                                ];
                            }),
                            aiot.__ci__({
                                __vm__: _vm_,
                                __opts__: {
                                    shown: function() {
                                        return _vm_.showTopBar;
                                    }
                                }
                            }, function() {
                                return [
                                    aiot.__ce__("image", {
                                        __vm__: _vm_,
                                        __opts__: {
                                            src: "/common/images/back.png",
                                            classList: [
                                                "btn",
                                                "btn-left-top"
                                            ],
                                            events: {
                                                click: function(evt) {
                                                    return _vm_.onBack(evt);
                                                }
                                            }
                                        }
                                    }, [])
                                ];
                            }),
                            aiot.__ci__({
                                __vm__: _vm_,
                                __opts__: {
                                    shown: function() {
                                        return _vm_.showTopBar;
                                    }
                                }
                            }, function() {
                                return [
                                    aiot.__ce__("image", {
                                        __vm__: _vm_,
                                        __opts__: {
                                            src: "/common/images/info.png",
                                            classList: [
                                                "btn",
                                                "btn-right-top"
                                            ],
                                            events: {
                                                click: function(evt) {
                                                    return _vm_.showAbout(evt);
                                                }
                                            }
                                        }
                                    }, [])
                                ];
                            })
                        ]);
                    };
                    $app_exports$['entry'] = function($app_exports$) {
                        $app_script$({}, $app_exports$, $app_require$1);
                        $app_exports$.default.template = $app_template$;
                        $app_exports$.default.style = $app_style$;
                    };
                })();
            })();
        };
        return createPageHandler();
    })(global, globalThis, window, $app_exports$, $app_evaluate$);
}
