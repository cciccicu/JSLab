export default function(global, globalThis, window, $app_exports$, $app_evaluate$) {
    var org_app_require = $app_require$;
    (function(global, globalThis, window, $app_exports$, $app_evaluate$) {
        var setTimeout = global.setTimeout;
        var setInterval = global.setInterval;
        var clearTimeout = global.clearTimeout;
        var clearInterval = global.clearInterval;
        var $app_require$1 = global.$app_require$ || org_app_require;
        var createPageHandler = function() {
            return (()=>{
                var __webpack_modules__ = {
                    "./src/utils/core/time.js": function(__unused_webpack_module, exports) {
                        "use strict";
                        Object.defineProperty(exports, "__esModule", {
                            value: true
                        });
                        exports.formatClock = formatClock;
                        exports.getCurrentClock = getCurrentClock;
                        exports.startPageClock = startPageClock;
                        exports.stopPageClock = stopPageClock;
                        function formatClock(date) {
                            const hours = date.getHours();
                            const minutes = date.getMinutes();
                            const hourText = hours < 10 ? '0' + hours : String(hours);
                            const minuteText = minutes < 10 ? '0' + minutes : String(minutes);
                            return hourText + ':' + minuteText;
                        }
                        function getCurrentClock() {
                            return formatClock(new Date());
                        }
                        const pageClocks = new WeakMap();
                        function stopPageClock(page) {
                            if (!pageClocks.has(page)) return;
                            clearTimeout(pageClocks.get(page));
                            pageClocks.delete(page);
                        }
                        function startPageClock(page) {
                            stopPageClock(page);
                            const tick = ()=>{
                                const date = new Date();
                                const value = formatClock(date);
                                if (page.nowTime !== value) page.nowTime = value;
                                pageClocks.set(page, setTimeout(tick, 60000 - (1000 * date.getSeconds() + date.getMilliseconds())));
                            };
                            tick();
                        }
                    },
                    "./src/utils/core/uiFeedback.js": function(__unused_webpack_module, exports) {
                        "use strict";
                        Object.defineProperty(exports, "__esModule", {
                            value: true
                        });
                        exports.showToast = showToast;
                        exports.vibrate = vibrate;
                        var _system = _interopRequireDefault($app_require$1("@app-module/system.prompt"));
                        var _system2 = _interopRequireDefault($app_require$1("@app-module/system.vibrator"));
                        function _interopRequireDefault(e) {
                            return e && e.__esModule ? e : {
                                default: e
                            };
                        }
                        function vibrate(mode) {
                            if (mode) _system2.default.vibrate({
                                mode
                            });
                        }
                        function showToast(message, duration) {
                            const milliseconds = Number(duration);
                            _system.default.showToast({
                                message: String(null == message ? '' : message),
                                duration: isFinite(milliseconds) ? Math.min(10000, Math.max(1500, milliseconds)) : 1500
                            });
                        }
                    }
                };
                var __webpack_module_cache__ = {};
                function __webpack_require__(moduleId) {
                    var cachedModule = __webpack_module_cache__[moduleId];
                    if (void 0 !== cachedModule) return cachedModule.exports;
                    var module = __webpack_module_cache__[moduleId] = {
                        exports: {}
                    };
                    __webpack_modules__[moduleId](module, module.exports, __webpack_require__);
                    return module.exports;
                }
                (()=>{
                    __webpack_require__.rv = ()=>"1.4.11";
                })();
                (()=>{
                    __webpack_require__.ruid = "bundler=rspack@1.4.11";
                })();
                var __webpack_exports__ = {};
                (()=>{
                    var $app_style$ = [
                        [
                            [
                                [
                                    0,
                                    "page"
                                ]
                            ],
                            {
                                width: "336px",
                                height: "480px",
                                backgroundColor: "#000000",
                                overflow: "hidden"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "scroll"
                                ]
                            ],
                            {
                                position: "absolute",
                                left: "0px",
                                top: "0px",
                                width: "336px",
                                height: "480px",
                                flexDirection: "column",
                                paddingTop: "84px",
                                paddingRight: "6px",
                                paddingBottom: "24px",
                                paddingLeft: "6px"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "app-card"
                                ]
                            ],
                            {
                                width: "324px",
                                minHeight: "128px",
                                paddingTop: "14px",
                                paddingRight: "20px",
                                paddingBottom: "14px",
                                paddingLeft: "20px",
                                marginBottom: "8px",
                                borderRadius: "36px",
                                backgroundColor: "#262626",
                                flexDirection: "row",
                                flexShrink: 0,
                                alignItems: "center"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "logo"
                                ]
                            ],
                            {
                                width: "76px",
                                height: "76px",
                                flexShrink: 0
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "app-text-group"
                                ]
                            ],
                            {
                                width: "194px",
                                marginLeft: "14px",
                                flexDirection: "column",
                                flexShrink: 0
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "app-name"
                                ]
                            ],
                            {
                                width: "194px",
                                fontSize: "32px",
                                lineHeight: "40px",
                                fontWeight: "bold",
                                color: "#ffffff",
                                lines: 2,
                                textOverflow: "ellipsis",
                                flexShrink: 0
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "app-version"
                                ]
                            ],
                            {
                                width: "194px",
                                marginTop: "4px",
                                fontSize: "22px",
                                lineHeight: "30px",
                                color: "rgba(255, 255, 255, 0.6)",
                                lines: -1,
                                flexShrink: 0
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "section-title"
                                ]
                            ],
                            {
                                width: "324px",
                                marginTop: "10px",
                                marginRight: "0px",
                                marginBottom: "4px",
                                marginLeft: "0px",
                                fontSize: "21px",
                                lineHeight: "29px",
                                fontWeight: "bold",
                                color: "rgba(255, 255, 255, 0.6)",
                                flexShrink: 0
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "info-card"
                                ]
                            ],
                            {
                                width: "324px",
                                minHeight: "96px",
                                paddingTop: "14px",
                                paddingRight: "20px",
                                paddingBottom: "14px",
                                paddingLeft: "20px",
                                marginBottom: "8px",
                                borderRadius: "36px",
                                backgroundColor: "#262626",
                                flexDirection: "column",
                                flexShrink: 0,
                                justifyContent: "center"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "card-label"
                                ]
                            ],
                            {
                                width: "284px",
                                fontSize: "20px",
                                lineHeight: "28px",
                                color: "rgba(255, 255, 255, 0.6)",
                                flexShrink: 0
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "card-value"
                                ]
                            ],
                            {
                                width: "284px",
                                fontSize: "27px",
                                lineHeight: "35px",
                                fontWeight: "bold",
                                color: "#ffffff",
                                lines: -1,
                                flexShrink: 0,
                                marginTop: "3px"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "card-title"
                                ]
                            ],
                            {
                                width: "284px",
                                fontSize: "27px",
                                lineHeight: "35px",
                                fontWeight: "bold",
                                color: "#ffffff",
                                lines: -1,
                                flexShrink: 0
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "small-value"
                                ]
                            ],
                            {
                                width: "284px",
                                marginTop: "3px",
                                fontSize: "22px",
                                lineHeight: "30px",
                                color: "#ffffff",
                                lines: -1,
                                flexShrink: 0
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "card-description"
                                ]
                            ],
                            {
                                width: "284px",
                                marginTop: "3px",
                                fontSize: "20px",
                                lineHeight: "28px",
                                color: "rgba(255, 255, 255, 0.6)",
                                lines: -1,
                                flexShrink: 0
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "option-text"
                                ]
                            ],
                            {
                                width: "284px",
                                fontSize: "22px",
                                lineHeight: "32px",
                                color: "#ffffff",
                                flexShrink: 0
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "promo-card"
                                ]
                            ],
                            {
                                paddingTop: "20px",
                                paddingRight: "20px",
                                paddingBottom: "20px",
                                paddingLeft: "20px"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "promo-brand"
                                ]
                            ],
                            {
                                width: "284px",
                                marginBottom: "8px",
                                fontSize: "29px",
                                lineHeight: "37px",
                                fontWeight: "bold",
                                color: "#ff5b5b",
                                flexShrink: 0
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "promo-title"
                                ]
                            ],
                            {
                                width: "284px",
                                fontSize: "23px",
                                lineHeight: "31px",
                                fontWeight: "bold",
                                color: "#ffffff",
                                lines: -1,
                                flexShrink: 0
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "qrcode-card"
                                ]
                            ],
                            {
                                width: "324px",
                                paddingTop: "20px",
                                paddingRight: "20px",
                                paddingBottom: "20px",
                                paddingLeft: "20px",
                                marginTop: "0px",
                                marginRight: "0px",
                                marginBottom: "16px",
                                marginLeft: "0px",
                                backgroundColor: "#262626",
                                borderRadius: "36px",
                                alignItems: "center",
                                flexDirection: "column",
                                flexShrink: 0
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "centered"
                                ]
                            ],
                            {
                                textAlign: "center"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "cloud-qrcode"
                                ]
                            ],
                            {
                                width: "184px",
                                height: "184px",
                                marginTop: "16px",
                                color: "#000000",
                                backgroundColor: "#ffffff",
                                flexShrink: 0
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "site-address"
                                ]
                            ],
                            {
                                width: "284px",
                                marginTop: "12px",
                                fontSize: "20px",
                                lineHeight: "28px",
                                color: "rgba(255, 255, 255, 0.6)",
                                textAlign: "center",
                                flexShrink: 0
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "topbar-bg"
                                ]
                            ],
                            {
                                position: "absolute",
                                left: "0px",
                                top: "0px",
                                width: "336px",
                                height: "84px"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "back-button"
                                ]
                            ],
                            {
                                position: "absolute",
                                left: "6px",
                                top: "6px",
                                width: "72px",
                                height: "72px"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "time-text"
                                ]
                            ],
                            {
                                position: "absolute",
                                left: "78px",
                                top: "7px",
                                width: "180px",
                                lineHeight: "32px",
                                fontSize: "24px",
                                fontWeight: "bold",
                                color: "rgba(255, 255, 255, 0.6)",
                                textAlign: "center"
                            }
                        ],
                        [
                            [
                                [
                                    0,
                                    "title-text"
                                ]
                            ],
                            {
                                position: "absolute",
                                left: "78px",
                                top: "35px",
                                width: "180px",
                                lineHeight: "42px",
                                fontSize: "32px",
                                fontWeight: "bold",
                                color: "#ffffff",
                                textAlign: "center"
                            }
                        ]
                    ];
                    var $app_script$ = function __scriptModule__(module, exports, $app_require$1) {
                        "use strict";
                        Object.defineProperty(exports, "__esModule", {
                            value: true
                        });
                        exports.default = void 0;
                        var _system = _interopRequireDefault($app_require$1("@app-module/system.app"));
                        var _system2 = _interopRequireDefault($app_require$1("@app-module/system.router"));
                        var _uiFeedback = __webpack_require__("./src/utils/core/uiFeedback.js");
                        var _time = __webpack_require__("./src/utils/core/time.js");
                        function _interopRequireDefault(e) {
                            return e && e.__esModule ? e : {
                                default: e
                            };
                        }
                        const owners = new WeakMap();
                        var _default = exports.default = {
                            private: {
                                nowTime: '00:00',
                                name: '独立应用',
                                version: '',
                                icon: '/common/logo.png',
                                author: '未填写',
                                packageName: '',
                                versionCode: '',
                                scriptName: '',
                                consoleLabel: '',
                                headerLabel: ''
                            },
                            onInit () {
                                owners.set(this, true);
                                this.updateTime();
                                const info = _system.default.getInfo();
                                this.name = info.name;
                                this.version = info.versionName;
                                this.packageName = info.packageName;
                                this.versionCode = String(info.versionCode);
                                this.icon = info.icon || '/common/logo.png';
                                this.$app.$def.loadPayload().then((data)=>{
                                    if (!owners.has(this)) return;
                                    this.name = data.appName;
                                    this.version = data.versionName;
                                    this.author = data.author || '未填写';
                                    this.scriptName = data.name;
                                    this.consoleLabel = data.options.disableConsole ? '日志输出：已关闭' : '日志输出：已开启';
                                    this.headerLabel = data.options.hideTopBar ? '运行顶栏：已隐藏' : '运行顶栏：已显示';
                                }, ()=>{});
                            },
                            onShow () {
                                (0, _time.startPageClock)(this);
                            },
                            onHide () {
                                (0, _time.stopPageClock)(this);
                            },
                            onDestroy () {
                                owners.delete(this);
                                (0, _time.stopPageClock)(this);
                            },
                            updateTime () {
                                this.nowTime = (0, _time.getCurrentClock)();
                            },
                            goBack () {
                                (0, _uiFeedback.vibrate)('short');
                                _system2.default.back();
                            },
                            onBackPress () {
                                this.goBack();
                                return true;
                            }
                        };
                        const moduleOwn = exports.default || module.exports;
                        const accessors = [
                            'public',
                            'protected',
                            'private'
                        ];
                        if (moduleOwn.data && accessors.some(function(acc) {
                            return moduleOwn[acc];
                        })) throw new Error('页面VM对象中的属性data不可与"' + accessors.join(',') + '"同时存在，请使用private替换data名称');
                        if (!moduleOwn.data) {
                            moduleOwn.data = {};
                            moduleOwn._descriptor = {};
                            accessors.forEach(function(acc) {
                                const accType = typeof moduleOwn[acc];
                                if ('object' === accType) {
                                    moduleOwn.data = Object.assign(moduleOwn.data, moduleOwn[acc]);
                                    for(const name in moduleOwn[acc])moduleOwn._descriptor[name] = {
                                        access: acc
                                    };
                                } else if ('function' === accType) console.warn('页面VM对象中的属性' + acc + '的值不能是函数，请使用对象');
                            });
                        }
                    };
                    var $app_template$ = function(vm) {
                        const _vm_ = vm || this;
                        return aiot.__ce__("div", {
                            __vm__: _vm_,
                            __opts__: {
                                classList: [
                                    "page"
                                ]
                            }
                        }, [
                            aiot.__ce__("scroll", {
                                __vm__: _vm_,
                                __opts__: {
                                    classList: [
                                        "scroll"
                                    ],
                                    scrollY: "true",
                                    bounces: "true"
                                }
                            }, [
                                aiot.__ce__("div", {
                                    __vm__: _vm_,
                                    __opts__: {
                                        classList: [
                                            "app-card"
                                        ]
                                    }
                                }, [
                                    aiot.__ce__("image", {
                                        __vm__: _vm_,
                                        __opts__: {
                                            src: function() {
                                                return _vm_.icon;
                                            },
                                            classList: [
                                                "logo"
                                            ]
                                        }
                                    }, []),
                                    aiot.__ce__("div", {
                                        __vm__: _vm_,
                                        __opts__: {
                                            classList: [
                                                "app-text-group"
                                            ]
                                        }
                                    }, [
                                        aiot.__ce__("text", {
                                            __vm__: _vm_,
                                            __opts__: {
                                                classList: [
                                                    "app-name"
                                                ],
                                                value: function() {
                                                    return _vm_.name;
                                                }
                                            }
                                        }, []),
                                        aiot.__ce__("text", {
                                            __vm__: _vm_,
                                            __opts__: {
                                                classList: [
                                                    "app-version"
                                                ],
                                                value: function() {
                                                    return "版本 " + _vm_.version;
                                                }
                                            }
                                        }, [])
                                    ])
                                ]),
                                aiot.__ce__("text", {
                                    __vm__: _vm_,
                                    __opts__: {
                                        classList: [
                                            "section-title"
                                        ],
                                        value: "应用信息"
                                    }
                                }, []),
                                aiot.__ce__("div", {
                                    __vm__: _vm_,
                                    __opts__: {
                                        classList: [
                                            "info-card"
                                        ]
                                    }
                                }, [
                                    aiot.__ce__("text", {
                                        __vm__: _vm_,
                                        __opts__: {
                                            classList: [
                                                "card-label"
                                            ],
                                            value: "作者"
                                        }
                                    }, []),
                                    aiot.__ce__("text", {
                                        __vm__: _vm_,
                                        __opts__: {
                                            classList: [
                                                "card-value"
                                            ],
                                            value: function() {
                                                return _vm_.author;
                                            }
                                        }
                                    }, [])
                                ]),
                                aiot.__ce__("div", {
                                    __vm__: _vm_,
                                    __opts__: {
                                        classList: [
                                            "info-card"
                                        ]
                                    }
                                }, [
                                    aiot.__ce__("text", {
                                        __vm__: _vm_,
                                        __opts__: {
                                            classList: [
                                                "card-label"
                                            ],
                                            value: "包名"
                                        }
                                    }, []),
                                    aiot.__ce__("text", {
                                        __vm__: _vm_,
                                        __opts__: {
                                            classList: [
                                                "small-value"
                                            ],
                                            value: function() {
                                                return _vm_.packageName;
                                            }
                                        }
                                    }, []),
                                    aiot.__ce__("text", {
                                        __vm__: _vm_,
                                        __opts__: {
                                            classList: [
                                                "card-description"
                                            ],
                                            value: function() {
                                                return "版本代码 " + _vm_.versionCode;
                                            }
                                        }
                                    }, [])
                                ]),
                                aiot.__ce__("div", {
                                    __vm__: _vm_,
                                    __opts__: {
                                        classList: [
                                            "info-card"
                                        ]
                                    }
                                }, [
                                    aiot.__ce__("text", {
                                        __vm__: _vm_,
                                        __opts__: {
                                            classList: [
                                                "card-label"
                                            ],
                                            value: "脚本"
                                        }
                                    }, []),
                                    aiot.__ce__("text", {
                                        __vm__: _vm_,
                                        __opts__: {
                                            classList: [
                                                "small-value"
                                            ],
                                            value: function() {
                                                return _vm_.scriptName;
                                            }
                                        }
                                    }, [])
                                ]),
                                aiot.__ce__("text", {
                                    __vm__: _vm_,
                                    __opts__: {
                                        classList: [
                                            "section-title"
                                        ],
                                        value: "运行选项"
                                    }
                                }, []),
                                aiot.__ce__("div", {
                                    __vm__: _vm_,
                                    __opts__: {
                                        classList: [
                                            "info-card"
                                        ]
                                    }
                                }, [
                                    aiot.__ce__("text", {
                                        __vm__: _vm_,
                                        __opts__: {
                                            classList: [
                                                "option-text"
                                            ],
                                            value: function() {
                                                return _vm_.consoleLabel;
                                            }
                                        }
                                    }, []),
                                    aiot.__ce__("text", {
                                        __vm__: _vm_,
                                        __opts__: {
                                            classList: [
                                                "option-text"
                                            ],
                                            value: function() {
                                                return _vm_.headerLabel;
                                            }
                                        }
                                    }, [])
                                ]),
                                aiot.__ce__("text", {
                                    __vm__: _vm_,
                                    __opts__: {
                                        classList: [
                                            "section-title"
                                        ],
                                        value: "由 JSLab 提供支持"
                                    }
                                }, []),
                                aiot.__ce__("div", {
                                    __vm__: _vm_,
                                    __opts__: {
                                        classList: [
                                            "info-card",
                                            "promo-card"
                                        ]
                                    }
                                }, [
                                    aiot.__ce__("text", {
                                        __vm__: _vm_,
                                        __opts__: {
                                            classList: [
                                                "promo-brand"
                                            ],
                                            value: "JSLab Cloud"
                                        }
                                    }, []),
                                    aiot.__ce__("text", {
                                        __vm__: _vm_,
                                        __opts__: {
                                            classList: [
                                                "promo-title"
                                            ],
                                            value: "由 JSLab Cloud 生成"
                                        }
                                    }, []),
                                    aiot.__ce__("text", {
                                        __vm__: _vm_,
                                        __opts__: {
                                            classList: [
                                                "card-description"
                                            ],
                                            value: "从云空间到独立快应用，让你的脚本随身可用。"
                                        }
                                    }, [])
                                ]),
                                aiot.__ce__("div", {
                                    __vm__: _vm_,
                                    __opts__: {
                                        classList: [
                                            "info-card",
                                            "promo-card"
                                        ]
                                    }
                                }, [
                                    aiot.__ce__("text", {
                                        __vm__: _vm_,
                                        __opts__: {
                                            classList: [
                                                "promo-brand"
                                            ],
                                            value: "JSLab 脚本引擎"
                                        }
                                    }, []),
                                    aiot.__ce__("text", {
                                        __vm__: _vm_,
                                        __opts__: {
                                            classList: [
                                                "promo-title"
                                            ],
                                            value: "使用 JSLab 脚本引擎运行"
                                        }
                                    }, []),
                                    aiot.__ce__("text", {
                                        __vm__: _vm_,
                                        __opts__: {
                                            classList: [
                                                "card-description"
                                            ],
                                            value: "用 JavaScript 构建界面，让手腕上的创意成为日常工具。"
                                        }
                                    }, [])
                                ]),
                                aiot.__ce__("div", {
                                    __vm__: _vm_,
                                    __opts__: {
                                        classList: [
                                            "qrcode-card"
                                        ]
                                    }
                                }, [
                                    aiot.__ce__("text", {
                                        __vm__: _vm_,
                                        __opts__: {
                                            classList: [
                                                "card-title",
                                                "centered"
                                            ],
                                            value: "发现更多脚本"
                                        }
                                    }, []),
                                    aiot.__ce__("text", {
                                        __vm__: _vm_,
                                        __opts__: {
                                            classList: [
                                                "card-description",
                                                "centered"
                                            ],
                                            value: "扫码访问 JSLab Cloud"
                                        }
                                    }, []),
                                    aiot.__ce__("qrcode", {
                                        __vm__: _vm_,
                                        __opts__: {
                                            value: "https://ccicc.icu/jslab-cloud",
                                            classList: [
                                                "cloud-qrcode"
                                            ]
                                        }
                                    }, []),
                                    aiot.__ce__("text", {
                                        __vm__: _vm_,
                                        __opts__: {
                                            classList: [
                                                "site-address"
                                            ],
                                            value: "ccicc.icu/jslab-cloud"
                                        }
                                    }, [])
                                ])
                            ]),
                            aiot.__ce__("image", {
                                __vm__: _vm_,
                                __opts__: {
                                    src: "/common/images/hd.png",
                                    classList: [
                                        "topbar-bg"
                                    ]
                                }
                            }, []),
                            aiot.__ce__("text", {
                                __vm__: _vm_,
                                __opts__: {
                                    classList: [
                                        "time-text"
                                    ],
                                    value: function() {
                                        return _vm_.nowTime;
                                    }
                                }
                            }, []),
                            aiot.__ce__("text", {
                                __vm__: _vm_,
                                __opts__: {
                                    classList: [
                                        "title-text"
                                    ],
                                    value: "关于"
                                }
                            }, []),
                            aiot.__ce__("image", {
                                __vm__: _vm_,
                                __opts__: {
                                    src: "/common/images/back.png",
                                    classList: [
                                        "back-button"
                                    ],
                                    events: {
                                        click: function(evt) {
                                            return _vm_.goBack(evt);
                                        }
                                    }
                                }
                            }, [])
                        ]);
                    };
                    $app_exports$['entry'] = function($app_exports$) {
                        $app_script$({}, $app_exports$, $app_require$1);
                        $app_exports$.default.template = $app_template$;
                        $app_exports$.default.style = $app_style$;
                    };
                })();
            })();
        };
        return createPageHandler();
    })(global, globalThis, window, $app_exports$, $app_evaluate$);
}
